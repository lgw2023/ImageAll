"""OpenMontage tool contract for deterministic StoryRenderPackage rendering."""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any

from lib.story_render_adapter import (
    inspect_story_run,
    prepare_story_run,
    render_story_run,
    validate_story_package,
    validation_report,
    verify_prepared_story_run_consistency,
)
from tools.base_tool import (
    BaseTool,
    Determinism,
    ExecutionMode,
    ResourceProfile,
    ResumeSupport,
    ToolResult,
    ToolRuntime,
    ToolStability,
    ToolTier,
)


REPOSITORY_ROOT = Path(__file__).resolve().parent.parent.parent
PROJECTS_ROOT = REPOSITORY_ROOT / "projects"


def _safe_project_dir(value: str | Path, output_root: str | Path | None = None) -> Path:
    project_dir = Path(value).resolve()
    root = Path(output_root).resolve() if output_root else PROJECTS_ROOT.resolve()
    try:
        project_dir.relative_to(root)
    except ValueError as exc:
        raise ValueError(f"project_dir must be below the selected output root: {root}") from exc
    return project_dir


class StoryRender(BaseTool):
    name = "story_render"
    version = "0.2.0"
    tier = ToolTier.CORE
    capability = "video_post"
    provider = "openmontage"
    runtime = ToolRuntime.LOCAL
    stability = ToolStability.EXPERIMENTAL
    execution_mode = ExecutionMode.SYNC
    determinism = Determinism.DETERMINISTIC
    dependencies = ["cmd:ffmpeg", "cmd:ffprobe", "cmd:npx"]
    install_instructions = (
        "Install Python requirements, FFmpeg, Node.js, then run "
        "`cd remotion-composer && npm ci`. Rendering is local and requires no API key."
    )
    agent_skills = ["remotion", "remotion-best-practices", "ffmpeg"]
    capabilities = [
        "validate_story_render_package_v0_1",
        "prepare_story_render_run",
        "render_photo_story_remotion",
        "inspect_story_render_result",
        "verify_input_to_artifact_consistency",
    ]
    best_for = [
        "Rendering an already-authored local photo story package",
        "Frame-exact landscape and portrait family photo videos",
        "Offline deterministic rerenders after asset, caption, or layout changes",
    ]
    not_good_for = [
        "Photo search, selection, story ordering, or identity inference",
        "HEIC, RAW, Apple Photos identifiers, or remote URLs",
        "Generative image/video or TTS production",
    ]
    resource_profile = ResourceProfile(
        cpu_cores=4,
        ram_mb=4096,
        vram_mb=0,
        disk_mb=10000,
        network_required=False,
    )
    resume_support = ResumeSupport.FROM_START
    side_effects = ["writes a unique run directory below the selected output_root for prepare/render"]
    input_schema = {
        "type": "object",
        "required": ["operation"],
        "properties": {
            "operation": {
                "type": "string",
                "enum": ["validate", "prepare", "compare", "render", "inspect"],
            },
            "package_path": {"type": "string"},
            "project_dir": {"type": "string"},
            "output_root": {"type": "string"},
            "run_suffix": {"type": "string"},
        },
    }
    progress_schema = {
        "type": "object",
        "required": ["state", "stage", "progress"],
        "properties": {
            "state": {"type": "string"},
            "stage": {
                "type": "string",
                "enum": ["validation", "preparation", "rendering", "audio_processing", "verification"],
            },
            "progress": {"type": "number", "minimum": 0, "maximum": 1},
        },
    }

    def get_info(self) -> dict[str, Any]:
        info = super().get_info()
        composer = Path(__file__).resolve().parent.parent.parent / "remotion-composer"
        info["remotion_ready"] = bool(
            (composer / "package.json").is_file() and (composer / "node_modules").is_dir()
        )
        info["schema_version"] = "0.1"
        info["network_required_for_render"] = False
        return info

    def execute(self, inputs: dict[str, Any]) -> ToolResult:
        operation = inputs.get("operation")
        started = time.monotonic()
        try:
            if operation == "validate":
                report = validation_report(inputs["package_path"])
                return ToolResult(
                    success=bool(report["valid"]),
                    data=report,
                    error=None if report["valid"] else "StoryRenderPackage validation failed",
                    duration_seconds=round(time.monotonic() - started, 3),
                )
            if operation == "prepare":
                validated = validate_story_package(inputs["package_path"])
                prepared = prepare_story_run(
                    validated,
                    projects_root=inputs.get("output_root"),
                    run_suffix=inputs.get("run_suffix"),
                )
                return ToolResult(
                    success=True,
                    data={
                        "project_id": prepared.project_id,
                        "project_dir": str(prepared.project_dir),
                        "asset_manifest": prepared.asset_manifest,
                        "edit_decisions": prepared.edit_decisions,
                    },
                    artifacts=[
                        str(prepared.project_dir / "artifacts" / "asset_manifest.json"),
                        str(prepared.project_dir / "artifacts" / "edit_decisions.json"),
                    ],
                    duration_seconds=round(time.monotonic() - started, 3),
                )
            if operation == "render":
                if inputs.get("project_dir"):
                    project_dir = _safe_project_dir(inputs["project_dir"], inputs.get("output_root"))
                else:
                    validated = validate_story_package(inputs["package_path"])
                    project_dir = prepare_story_run(
                        validated,
                        projects_root=inputs.get("output_root"),
                        run_suffix=inputs.get("run_suffix"),
                    ).project_dir
                result = render_story_run(project_dir)
                return ToolResult(
                    success=True,
                    data=result,
                    artifacts=[result["output"], result["renderReport"], result["verificationReport"]],
                    duration_seconds=round(time.monotonic() - started, 3),
                )
            if operation == "compare":
                project_dir = _safe_project_dir(
                    inputs["project_dir"], inputs.get("output_root")
                )
                report = verify_prepared_story_run_consistency(
                    project_dir,
                    external_package_path=inputs.get("package_path"),
                )
                return ToolResult(
                    success=report["status"] == "pass",
                    data=report,
                    error=None if report["status"] == "pass" else "Story artifact consistency failed",
                    artifacts=[str(project_dir / "reports" / "consistency_report.json")],
                    duration_seconds=round(time.monotonic() - started, 3),
                )
            if operation == "inspect":
                data = inspect_story_run(
                    _safe_project_dir(inputs["project_dir"], inputs.get("output_root"))
                )
                return ToolResult(
                    success=True,
                    data=data,
                    duration_seconds=round(time.monotonic() - started, 3),
                )
            return ToolResult(success=False, error=f"Unknown operation: {operation}")
        except Exception as exc:
            return ToolResult(
                success=False,
                error=str(exc),
                duration_seconds=round(time.monotonic() - started, 3),
            )
