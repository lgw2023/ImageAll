"""Character animation tools."""

