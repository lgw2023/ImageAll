"""File-based ImageAll creative exchange; Agent skills own all creative decisions."""
from pathlib import Path
from tools.base_tool import BaseTool, ToolResult, ToolRuntime, ToolStability, ToolStatus, ToolTier
from lib.story_creative_plugin import CreativeError, capabilities, prepare, complete

class StoryCreativeExchange(BaseTool):
    name = 'story_creative_exchange'
    version = '1.0.0'
    capability = 'analysis'
    provider = 'local'
    tier = ToolTier.ANALYZE
    stability = ToolStability.BETA
    runtime = ToolRuntime.LOCAL
    supports = {'automatic_planning': False, 'bounded_scope': True, 'resume': True}
    best_for = ['validating and exchanging Agent-authored editable photo plans with ImageAll']
    not_good_for = ['unattended direction', 'cloud upload', 'executing supplied scripts']
    input_schema = {'type': 'object', 'required': ['operation', 'task_root'], 'properties': {
        'operation': {'enum': ['capabilities', 'prepare', 'complete']},
        'task_root': {'type': 'string'}, 'request_id': {'type': ['string', 'null']},
        'plan': {'type': ['string', 'null']}}, 'additionalProperties': False}
    def get_status(self):
        return ToolStatus.AVAILABLE
    def execute(self, inputs):
        try:
            import jsonschema
            jsonschema.validate(inputs, self.input_schema)
            root = Path(inputs['task_root']).absolute()
            if inputs['operation'] == 'capabilities':
                data = capabilities(root)
            elif inputs['operation'] == 'prepare':
                data = prepare(root, inputs.get('request_id') or '')
            else:
                data = complete(root, inputs.get('request_id') or '', inputs.get('plan') or '')
            return ToolResult(success=True, data=data, cost_usd=0.0)
        except CreativeError as exc:
            return ToolResult(success=False, error=str(exc), cost_usd=0.0)
        except Exception as exc:
            return ToolResult(success=False, error=f'CREATIVE_EXCHANGE_FAILED ({type(exc).__name__})', cost_usd=0.0)
