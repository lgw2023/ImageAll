#!/usr/bin/env python3
"""Verify the byte-frozen StoryRenderPackage v0.1 Schema contract."""

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path
from typing import Any


REPOSITORY_ROOT = Path(__file__).resolve().parent.parent
LOCK_PATH = REPOSITORY_ROOT / "schemas/integrations/story_render_package_v0_1.lock.json"


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def verify_contract() -> dict[str, Any]:
    lock = json.loads(LOCK_PATH.read_text(encoding="utf-8"))
    schema_path = REPOSITORY_ROOT / lock["schemaPath"]
    current = schema_path.read_bytes()
    committed = subprocess.run(
        ["git", "show", f"{lock['introducedInCommit']}:{lock['schemaPath']}"],
        cwd=REPOSITORY_ROOT,
        capture_output=True,
        check=False,
    )
    checks = [
        {
            "name": "working_tree_sha256",
            "passed": _sha256(current) == lock["sha256"],
            "expected": lock["sha256"],
            "actual": _sha256(current),
        },
        {
            "name": "byte_length",
            "passed": len(current) == lock["byteLength"],
            "expected": lock["byteLength"],
            "actual": len(current),
        },
        {
            "name": "line_count",
            "passed": current.count(b"\n") == lock["lineCount"],
            "expected": lock["lineCount"],
            "actual": current.count(b"\n"),
        },
        {
            "name": "line_format",
            "passed": (
                b"\r\n" not in current
                and current.endswith(b"\n") is lock["finalNewline"]
                and current.startswith(b"\xef\xbb\xbf") is lock["utf8BOM"]
            ),
            "expected": {
                "lineEnding": lock["lineEnding"],
                "finalNewline": lock["finalNewline"],
                "utf8BOM": lock["utf8BOM"],
            },
            "actual": {
                "lineEnding": "CRLF" if b"\r\n" in current else "LF",
                "finalNewline": current.endswith(b"\n"),
                "utf8BOM": current.startswith(b"\xef\xbb\xbf"),
            },
        },
        {
            "name": "introduced_commit_bytes",
            "passed": committed.returncode == 0 and committed.stdout == current,
            "expected": "working tree bytes equal the file introduced in the pinned commit",
            "actual": (
                "equal"
                if committed.returncode == 0 and committed.stdout == current
                else "different_or_commit_unavailable"
            ),
        },
        {
            "name": "introduced_commit_sha256",
            "passed": committed.returncode == 0 and _sha256(committed.stdout) == lock["sha256"],
            "expected": lock["sha256"],
            "actual": _sha256(committed.stdout) if committed.returncode == 0 else None,
        },
    ]
    return {
        "version": "1.0",
        "status": "pass" if all(check["passed"] for check in checks) else "fail",
        "schemaVersion": lock["schemaVersion"],
        "schemaPath": lock["schemaPath"],
        "introducedInCommit": lock["introducedInCommit"],
        "gitBlobSHA1": lock["gitBlobSHA1"],
        "sha256": lock["sha256"],
        "checks": checks,
    }


def main() -> int:
    report = verify_contract()
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] == "pass" else 1


if __name__ == "__main__":
    sys.exit(main())
