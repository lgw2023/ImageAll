#!/usr/bin/env python3
"""Validate, render, inspect, or cancel a StoryRenderPackage v0.1 run."""

from __future__ import annotations

import argparse
import json
import os
import signal
import subprocess
import sys
import time
import uuid
from pathlib import Path
from typing import Any

REPOSITORY_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPOSITORY_ROOT))

from lib.story_render_adapter import (  # noqa: E402
    StoryPackageValidationError,
    inspect_story_run,
    install_worker_signal_handlers,
    prepare_story_run,
    render_story_run,
    validate_story_package,
    validation_report,
    verify_prepared_story_run_consistency,
)

PROJECTS_ROOT = REPOSITORY_ROOT / "projects"


def _emit(data: dict[str, Any]) -> None:
    print(json.dumps(data, ensure_ascii=False), flush=True)


def _output_root(value: str | Path | None) -> Path:
    return Path(value).resolve() if value else PROJECTS_ROOT.resolve()


def _safe_task_dir(value: str | Path, output_root: str | Path | None = None) -> Path:
    task_dir = Path(value).resolve()
    root = _output_root(output_root)
    try:
        task_dir.relative_to(root)
    except ValueError as exc:
        raise ValueError(f"task directory must be below the selected output root: {root}") from exc
    if not task_dir.is_dir():
        raise FileNotFoundError("task directory does not exist")
    return task_dir


def _worker_metadata(task_dir: Path, pid: int) -> dict[str, Any]:
    return {
        "version": "0.1",
        "pid": pid,
        "processGroupID": pid,
        "token": uuid.uuid4().hex,
        "projectID": task_dir.name,
        "startedAt": time.time(),
    }


def _write_json(path: Path, data: dict[str, Any]) -> None:
    temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def command_validate(args: argparse.Namespace) -> int:
    report = validation_report(args.package)
    _emit(report)
    return 0 if report["valid"] else 2


def _poll_worker(task_dir: Path, process: subprocess.Popen[str]) -> int:
    last_status = ""
    try:
        while process.poll() is None:
            status_path = task_dir / "status.json"
            if status_path.is_file():
                current = status_path.read_text(encoding="utf-8")
                if current != last_status:
                    _emit({"event": "progress", **json.loads(current)})
                    last_status = current
            time.sleep(0.5)
    except KeyboardInterrupt:
        os.killpg(process.pid, signal.SIGTERM)
        process.wait(timeout=20)
        _emit({"event": "cancelled", "projectID": task_dir.name, "reason": "keyboard_interrupt"})
        return 130
    stdout, stderr = process.communicate()
    if stdout.strip():
        for line in stdout.splitlines():
            print(line, flush=True)
    if process.returncode != 0:
        status = inspect_story_run(task_dir)["status"]
        _emit({"event": "worker_exit", "projectID": task_dir.name, "returnCode": process.returncode, "status": status})
    return process.returncode or 0


def command_render(args: argparse.Namespace) -> int:
    try:
        validated = validate_story_package(args.package)
    except StoryPackageValidationError as exc:
        _emit({"event": "validation_failed", "errors": [issue.to_dict() for issue in exc.issues]})
        return 2
    _emit({"event": "validated", **validation_report(args.package)})
    try:
        prepared = prepare_story_run(
            validated,
            projects_root=_output_root(args.output_root),
            run_suffix=args.run_suffix,
        )
    except FileExistsError:
        _emit({"event": "preparation_failed", "code": "TASK_ALREADY_EXISTS"})
        return 3
    except Exception as exc:
        _emit(
            {
                "event": "preparation_failed",
                "code": "PREPARATION_FAILED",
                "errorType": type(exc).__name__,
            }
        )
        return 4
    task_dir = prepared.project_dir
    _emit(
        {
            "event": "prepared",
            "projectID": prepared.project_id,
            "projectDir": str(task_dir),
        }
    )
    stdout_handle = None
    stderr_handle = None
    if args.detach:
        stdout_handle = (task_dir / "control" / "worker.stdout.log").open("w", encoding="utf-8")
        stderr_handle = (task_dir / "control" / "worker.stderr.log").open("w", encoding="utf-8")
    process = subprocess.Popen(
        [
            sys.executable,
            str(Path(__file__).resolve()),
            "_worker",
            "--project-dir",
            str(task_dir),
            "--output-root",
            str(_output_root(args.output_root)),
        ],
        cwd=REPOSITORY_ROOT,
        stdout=stdout_handle or subprocess.PIPE,
        stderr=stderr_handle or subprocess.PIPE,
        text=True,
        start_new_session=True,
    )
    _write_json(task_dir / "control" / "worker.json", _worker_metadata(task_dir, process.pid))
    if args.detach:
        assert stdout_handle is not None and stderr_handle is not None
        stdout_handle.close()
        stderr_handle.close()
        _emit({"event": "started", "projectID": prepared.project_id, "pid": process.pid})
        return 0
    return _poll_worker(task_dir, process)


def command_inspect(args: argparse.Namespace) -> int:
    task_dir = _safe_task_dir(args.project_dir, args.output_root)
    _emit(inspect_story_run(task_dir))
    return 0


def command_compare(args: argparse.Namespace) -> int:
    task_dir = _safe_task_dir(args.project_dir, args.output_root)
    report = verify_prepared_story_run_consistency(
        task_dir,
        external_package_path=args.package,
    )
    _emit(report)
    return 0 if report["status"] == "pass" else 2


def command_cancel(args: argparse.Namespace) -> int:
    task_dir = _safe_task_dir(args.project_dir, args.output_root)
    worker_path = task_dir / "control" / "worker.json"
    if not worker_path.is_file():
        _emit({"success": False, "code": "WORKER_NOT_FOUND", "projectID": task_dir.name})
        return 5
    worker = json.loads(worker_path.read_text(encoding="utf-8"))
    pid = int(worker["pid"])
    check = subprocess.run(
        ["ps", "-p", str(pid), "-o", "command="],
        capture_output=True,
        text=True,
        check=False,
    )
    command = check.stdout
    if check.returncode != 0 or "story_render.py _worker" not in command or str(task_dir) not in command:
        _emit({"success": False, "code": "STALE_WORKER", "projectID": task_dir.name})
        return 5
    _write_json(
        task_dir / "control" / "cancel-request.json",
        {"version": "0.1", "requestedAt": time.time(), "projectID": task_dir.name},
    )
    try:
        os.killpg(int(worker.get("processGroupID", pid)), signal.SIGTERM)
    except ProcessLookupError:
        _emit({"success": False, "code": "WORKER_NOT_RUNNING", "projectID": task_dir.name})
        return 5
    _emit({"success": True, "state": "cancellation_requested", "projectID": task_dir.name})
    return 0


def command_worker(args: argparse.Namespace) -> int:
    task_dir = _safe_task_dir(args.project_dir, args.output_root)
    install_worker_signal_handlers(task_dir)
    try:
        result = render_story_run(task_dir)
        _emit(result)
        return 0
    except SystemExit as exc:
        return int(exc.code or 130)
    except BaseException as exc:
        _emit({"success": False, "projectID": task_dir.name, "error": type(exc).__name__})
        return 4


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subcommands = parser.add_subparsers(dest="command", required=True)

    validate = subcommands.add_parser("validate", help="Validate a package and its local assets")
    validate.add_argument("package", type=Path)
    validate.set_defaults(handler=command_validate)

    render = subcommands.add_parser("render", help="Prepare and render a package in a unique run directory")
    render.add_argument("package", type=Path)
    render.add_argument("--run-suffix", help="Optional caller correlation suffix; a random suffix is used by default")
    render.add_argument(
        "--output-root",
        type=Path,
        help="Run-directory parent; defaults to the repository projects/ directory",
    )
    render.add_argument("--detach", action="store_true", help="Return after starting the isolated render worker")
    render.set_defaults(handler=command_render)

    inspect = subcommands.add_parser("inspect", help="Read machine-readable task status and reports")
    inspect.add_argument("project_dir", type=Path)
    inspect.add_argument("--output-root", type=Path, help="Expected run-directory parent")
    inspect.set_defaults(handler=command_inspect)

    compare = subcommands.add_parser(
        "compare",
        help="Recompute machine-readable input-to-artifact consistency for a prepared run",
    )
    compare.add_argument("package", type=Path)
    compare.add_argument("project_dir", type=Path)
    compare.add_argument("--output-root", type=Path, help="Expected run-directory parent")
    compare.set_defaults(handler=command_compare)

    cancel = subcommands.add_parser("cancel", help="Cancel only the worker process group recorded for this task")
    cancel.add_argument("project_dir", type=Path)
    cancel.add_argument("--output-root", type=Path, help="Expected run-directory parent")
    cancel.set_defaults(handler=command_cancel)

    worker = subcommands.add_parser("_worker", help=argparse.SUPPRESS)
    worker.add_argument("--project-dir", required=True, type=Path)
    worker.add_argument("--output-root", required=True, type=Path)
    worker.set_defaults(handler=command_worker)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return int(args.handler(args))
    except FileNotFoundError:
        _emit({"success": False, "code": "TASK_NOT_FOUND"})
        return 3
    except ValueError as exc:
        _emit({"success": False, "code": "INVALID_ARGUMENT", "message": str(exc)})
        return 3


if __name__ == "__main__":
    raise SystemExit(main())
