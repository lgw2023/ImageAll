#!/usr/bin/env python3
"""Generate deterministic synthetic StoryRenderPackage v0.1 examples."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

REPOSITORY_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_OUTPUT = REPOSITORY_ROOT / "examples" / "story-render-package-v0.1"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def draw_fixture(path: Path, size: tuple[int, int], label: str, color: str) -> None:
    width, height = size
    image = Image.new("RGB", size, color)
    draw = ImageDraw.Draw(image)
    edge = max(18, min(width, height) // 35)
    draw.rectangle((0, 0, width - 1, edge), fill="#EF4444")
    draw.rectangle((width - edge, 0, width - 1, height - 1), fill="#22C55E")
    draw.rectangle((0, height - edge, width - 1, height - 1), fill="#3B82F6")
    draw.rectangle((0, 0, edge, height - 1), fill="#FACC15")
    center = (width // 2, height // 2)
    radius = min(width, height) // 5
    draw.ellipse(
        (center[0] - radius, center[1] - radius, center[0] + radius, center[1] + radius),
        fill="#F8FAFC",
        outline="#111827",
        width=max(5, edge // 3),
    )
    font = ImageFont.load_default(size=max(18, min(width, height) // 18))
    text_box = draw.textbbox((0, 0), label, font=font)
    text_width = text_box[2] - text_box[0]
    text_height = text_box[3] - text_box[1]
    draw.rounded_rectangle(
        (
            center[0] - text_width // 2 - edge,
            center[1] - text_height // 2 - edge,
            center[0] + text_width // 2 + edge,
            center[1] + text_height // 2 + edge,
        ),
        radius=edge,
        fill="#FFFFFFDD",
    )
    draw.text(
        (center[0] - text_width // 2, center[1] - text_height // 2),
        label,
        font=font,
        fill="#111827",
    )
    image.save(path, format="PNG", optimize=False)


def asset(asset_id: str, relative_path: str, root: Path, source_version: str) -> dict:
    path = root / relative_path
    media_type = "audio/mpeg" if path.suffix.lower() == ".mp3" else "image/png"
    return {
        "assetID": asset_id,
        "relativePath": relative_path,
        "mediaType": media_type,
        "sourceContentVersion": source_version,
        "renderFileSHA256": sha256(path),
    }


def transition(kind: str = "fade", frames: int = 30) -> dict:
    return {"type": kind, "durationFrames": frames}


def photo_shot(
    shot_id: str,
    sequence: int,
    asset_id: str,
    start: int,
    duration: int,
    caption: dict,
    motion: str = "subtle-push",
    transition_frames: int = 30,
) -> dict:
    return {
        "shotID": shot_id,
        "sequenceIndex": sequence,
        "kind": "photo",
        "assetID": asset_id,
        "startFrame": start,
        "durationFrames": duration,
        "caption": caption,
        "fit": {"mode": "contain", "allowCrop": False},
        "motion": {"type": motion},
        "transitionIn": transition("fade", transition_frames),
        "trace": {"originalShotID": f"synthetic-{shot_id}", "upstreamStrategyVersion": "fixture-v1"},
    }


def text_shot(
    shot_id: str,
    sequence: int,
    kind: str,
    start: int,
    duration: int,
    title: str,
    first: bool = False,
    transition_frames: int = 30,
) -> dict:
    return {
        "shotID": shot_id,
        "sequenceIndex": sequence,
        "kind": kind,
        "startFrame": start,
        "durationFrames": duration,
        "title": title,
        "transitionIn": transition("cut", 0) if first else transition("fade", transition_frames),
        "trace": {"originalShotID": f"synthetic-{shot_id}", "upstreamStrategyVersion": "fixture-v1"},
    }


def template(title: str) -> dict:
    return {
        "name": "family-photo-story",
        "version": "0.1",
        "title": title,
        "subtitle": "完全由合成素材构成，不代表任何真实人物",
        "closingText": "合成测试故事 · 完",
        "fontFamily": "Hiragino Sans GB",
        "textColor": "#FFFFFF",
        "accentColor": "#F2C879",
        "safeMarginRatio": 0.07,
    }


def write_json(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def build_minimal(root: Path) -> None:
    assets_dir = root / "assets"
    assets_dir.mkdir(parents=True, exist_ok=True)
    draw_fixture(assets_dir / "minimal.png", (960, 540), "SYNTHETIC MINIMAL", "#28536B")
    package = {
        "schemaVersion": "0.1",
        "projectID": "synthetic-minimal-story",
        "projectRevision": "v1",
        "export": {
            "width": 1920,
            "height": 1080,
            "fps": 30,
            "totalFrames": 210,
            "background": {"color": "#111827", "mode": "blurred-photo", "blurPixels": 24, "dimOpacity": 0.4},
            "template": template("最小有效合成故事包"),
        },
        "assets": [asset("minimal-photo", "assets/minimal.png", root, "fixture-minimal-v1")],
        "chapters": [
            {
                "chapterID": "minimal-chapter",
                "sequenceIndex": 0,
                "title": "最小章节",
                "trace": {"sourceChapterID": "minimal", "upstreamStrategyVersion": "fixture-v1"},
                "shots": [
                    text_shot("minimal-title", 0, "title", 0, 60, "最小有效合成故事包", first=True),
                    photo_shot(
                        "minimal-photo-shot",
                        1,
                        "minimal-photo",
                        45,
                        120,
                        {"timeText": "合成时间", "body": "四侧彩色边缘必须完整可见"},
                        transition_frames=15,
                    ),
                    text_shot("minimal-outro", 2, "outro", 150, 60, "短片验证完成", transition_frames=15),
                ],
            }
        ],
        "trace": {"upstreamPolicyVersion": "synthetic-policy-v1", "exporterVersion": "fixture-generator-v1"},
    }
    write_json(root / "story.json", package)


def build_full(root: Path) -> None:
    assets_dir = root / "assets"
    assets_dir.mkdir(parents=True, exist_ok=True)
    definitions = [
        ("photo-a1", "a1-landscape.png", (1920, 1080), "A1 LANDSCAPE", "#345B63"),
        ("photo-b1", "b1-portrait.png", (1080, 1920), "B1 PORTRAIT", "#6D597A"),
        ("photo-b2", "b2-square.png", (1200, 1200), "B2 SQUARE", "#8A5A44"),
        ("photo-a2", "a2-landscape.png", (1600, 900), "A2 RETURN", "#386641"),
        ("photo-a3", "a3-portrait.png", (900, 1600), "A3 PORTRAIT", "#5F0F40"),
        ("photo-a4", "a4-ultrawide.png", (2400, 800), "A4 ULTRAWIDE", "#1D3557"),
        ("photo-a1", "a1-replacement.png", (1920, 1080), "A1 REPLACED", "#A44A3F"),
    ]
    for _asset_id, filename, size, label, color in definitions:
        draw_fixture(assets_dir / filename, size, label, color)
    audio_path = assets_dir / "synthetic-bed.mp3"
    subprocess.run(
        [
            "ffmpeg",
            "-v",
            "error",
            "-y",
            "-f",
            "lavfi",
            "-i",
            "sine=frequency=220:duration=60:sample_rate=44100",
            "-filter:a",
            "volume=0.08",
            "-ac",
            "2",
            "-b:a",
            "32k",
            str(audio_path),
        ],
        check=True,
    )

    common_assets = [
        asset(asset_id, f"assets/{filename}", root, f"fixture-{asset_id}-v1")
        for asset_id, filename, _size, _label, _color in definitions[:6]
    ]
    common_assets.append(asset("music-bed", "assets/synthetic-bed.mp3", root, "fixture-audio-v1"))
    chapters = [
        {
            "chapterID": "chapter-a-1",
            "sequenceIndex": 0,
            "title": "时期 A · 初见",
            "trace": {"sourceChapterID": "A", "upstreamStrategyVersion": "fixture-v1"},
            "shots": [
                text_shot("story-title", 0, "title", 0, 120, "合成时光故事：从 A 到 B，再回到 A", first=True),
                photo_shot("a1", 1, "photo-a1", 90, 240, {"timeText": "合成时期 A", "locationText": "测试地点一号（非真实地点）", "body": "横图完整展示，四侧边缘均可见"}),
            ],
        },
        {
            "chapterID": "chapter-b",
            "sequenceIndex": 1,
            "title": "时期 B · 另一段旅程",
            "trace": {"sourceChapterID": "B", "upstreamStrategyVersion": "fixture-v1"},
            "shots": [
                text_shot("chapter-b-title", 0, "chapter-title", 300, 90, "时期 B · 另一段旅程"),
                photo_shot("b1", 1, "photo-b1", 360, 270, {"timeText": "合成时期 B", "body": "竖图在横屏中不得裁掉顶部或底部"}),
                photo_shot("b2", 2, "photo-b2", 600, 270, {"locationText": "这是一个很长很长的合成地点名称，用于验证字幕换行和安全边距", "body": "此镜头故意缺少时间字幕"}),
            ],
        },
        {
            "chapterID": "chapter-a-2",
            "sequenceIndex": 2,
            "title": "时期 A · 再访",
            "trace": {"sourceChapterID": "A", "upstreamStrategyVersion": "fixture-v1"},
            "shots": [
                text_shot("chapter-a-return-title", 0, "chapter-title", 840, 90, "时期 A · 再访（章节顺序 A → B → A）"),
                photo_shot("a2", 1, "photo-a2", 900, 270, {"timeText": "合成时期 A · 再访", "locationText": "测试地点二号", "body": "同一来源章节再次出现，但镜头 ID 保持唯一"}),
                photo_shot("a3", 2, "photo-a3", 1140, 270, {"body": "缺少时间与地点时，渲染器不得自动补写"}, motion="static"),
                photo_shot("a4", 3, "photo-a4", 1380, 270, {"timeText": "合成时期 A", "body": "超宽图完整展示，左右红黄绿蓝边缘标记用于检查裁切"}),
                text_shot("story-outro", 4, "outro", 1620, 180, "合成测试故事 · 完"),
            ],
        },
    ]

    def package(width: int, height: int, revision: str) -> dict:
        return {
            "schemaVersion": "0.1",
            "projectID": "synthetic-full-story",
            "projectRevision": revision,
            "export": {
                "width": width,
                "height": height,
                "fps": 30,
                "totalFrames": 1800,
                "background": {"color": "#101722", "mode": "blurred-photo", "blurPixels": 28, "dimOpacity": 0.42},
                "template": template("合成时光故事：从 A 到 B，再回到 A"),
            },
            "assets": common_assets,
            "chapters": chapters,
            "audio": {"assetID": "music-bed", "offsetFrame": 0, "volume": 0.22, "fadeInFrames": 60, "fadeOutFrames": 90, "loop": False},
            "trace": {"upstreamPolicyVersion": "synthetic-policy-v1", "exporterVersion": "fixture-generator-v1"},
        }

    landscape = package(1920, 1080, "full-v1-landscape")
    portrait = package(1080, 1920, "full-v1-portrait")
    modified = json.loads(json.dumps(landscape))
    modified["projectRevision"] = "full-v2-modified"
    replacement = asset("photo-a1", "assets/a1-replacement.png", root, "fixture-photo-a1-v2")
    modified["assets"][0] = replacement
    modified["chapters"][0]["shots"][1]["caption"]["body"] = "这条字幕已修改；镜头顺序和时长保持不变"
    write_json(root / "story-landscape.json", landscape)
    write_json(root / "story-portrait.json", portrait)
    write_json(root / "story-modified.json", modified)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    output = args.output.resolve()
    if output.exists():
        if not args.force:
            raise SystemExit(f"output already exists: {output}; pass --force to replace generated fixtures")
        shutil.rmtree(output)
    build_minimal(output / "minimal")
    build_full(output / "full")
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
