"""CLI for the registered OpenMontage private_photo_vision tool (pipeline use)."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", required=True)
    parser.add_argument("--phase", choices=["initial", "verify"])
    parser.add_argument("--asset-id", action="append")
    parser.add_argument("--key-env", default="DASHSCOPE_API_KEY")
    parser.add_argument("--scope-digest", required=True)
    parser.add_argument("--validate-saved", help="Project-relative observation to validate offline")
    parser.add_argument("--acknowledge-external-send", action="store_true")
    args = parser.parse_args()
    from tools.tool_registry import registry
    registry.discover()
    params = {"project_dir": args.project, "expected_scope": args.scope_digest}
    if args.validate_saved:
        params.update(operation="validate_saved", observation_path=args.validate_saved)
    else:
        params.update(operation="review", phase=args.phase, asset_ids=args.asset_id,
                      key_env=args.key_env, acknowledged_external_send=args.acknowledge_external_send)
    result = registry.get("private_photo_vision").execute(params)
    print(json.dumps({"success": result.success, "error": result.error, "data": result.data}, ensure_ascii=False))
    if not result.success:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
