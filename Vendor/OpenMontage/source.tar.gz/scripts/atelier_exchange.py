"""ImageAll Atelier project exchange; creative work remains Agent-directed."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from lib import atelier_exchange as exchange


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["capabilities", "prepare", "freeze", "render", "verify"])
    parser.add_argument("--task-root", type=Path, required=True)
    parser.add_argument("--request-id")
    parser.add_argument("--summary", type=Path, help="Local private JSON with entryPoint, propsPath, compositionID, runtimeVersion, totalFrames, title, summary")
    args = parser.parse_args()
    root = args.task_root.resolve()
    if args.action == "capabilities":
        result = exchange.capabilities(root)
    else:
        if not args.request_id:
            parser.error("--request-id is required")
        if args.action == "prepare":
            result = exchange.prepare(root, args.request_id)
        elif args.action == "freeze":
            if not args.summary:
                parser.error("--summary is required")
            result = exchange.freeze(root, args.request_id, json.loads(args.summary.read_text()))
        elif args.action == "render":
            result = exchange.render(root, args.request_id)
        else:
            directory = exchange.request_dir(root, args.request_id)
            result = {"revision": str(exchange.verify_revision(directory, exchange._read(directory / "proposal.json")))}
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
