#!/usr/bin/env python3
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from lib.story_style_templates import run
if __name__ == '__main__': run(Path(sys.argv[1]))
