"""Validate and deterministically rerender an already-directed private-photo Atelier plan.

This command never selects a photo or reads a source library. Its only media inputs
are normalized files in the explicitly supplied private project directory.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def _json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _inside(project: Path, relative: str) -> Path:
    path = Path(relative)
    if path.is_absolute() or not relative or ".." in path.parts:
        raise ValueError(f"unsafe project-relative path: {relative!r}")
    resolved = (project / path).resolve()
    if not resolved.is_relative_to(project.resolve()):
        raise ValueError(f"path leaves private project: {relative!r}")
    return resolved


def validate(project: Path, plan_name: str) -> tuple[dict, dict]:
    """Check exact exported bytes, bounded references, time facts and frozen edit."""
    project = project.resolve()
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]*", plan_name):
        raise ValueError("plan name must be lowercase kebab-case")
    if not (project / "project.json").is_file():
        raise ValueError("missing OpenMontage project.json")
    manifest = _json(project / "artifacts/source-assets.json")
    plan = _json(project / "artifacts/plans" / f"{plan_name}.json")
    if manifest.get("version") != "1.0" or not manifest.get("scopeDigestSHA256"):
        raise ValueError("missing bounded source manifest or scope digest")
    if plan.get("scopeDigestSHA256") != manifest["scopeDigestSHA256"]:
        raise ValueError("plan was not frozen against this source scope")
    if plan.get("version") != "1.0" or plan.get("fps") != 30:
        raise ValueError("plan must be version 1.0 at 30 fps")
    if plan.get("audio") != "none":
        raise ValueError("this entry supports the explicitly silent private-photo cut only")
    if plan.get("width") != 1920 or plan.get("height") != 1080:
        raise ValueError("this project's review canvas must be 1920x1080")

    assets: dict[str, dict] = {}
    for asset in manifest.get("assets", []):
        asset_id = asset.get("assetID")
        if not isinstance(asset_id, str) or asset_id in assets:
            raise ValueError("duplicate or invalid asset ID")
        file = _inside(project, asset.get("relativePath", ""))
        if not file.is_file() or not file.is_relative_to((project / "public").resolve()):
            raise ValueError(f"missing or non-public normalized asset {asset_id}")
        if hashlib.sha256(file.read_bytes()).hexdigest() != asset.get("sha256"):
            raise ValueError(f"exported asset hash changed: {asset_id}")
        if not asset.get("sourceContentVersion") or not asset.get("captureDate"):
            raise ValueError(f"missing version or capture date: {asset_id}")
        assets[asset_id] = asset

    inventory = _json(project / "artifacts/asset_manifest.json")
    inv_by_id = {a.get("id"): a for a in inventory.get("assets", [])}
    if len(inv_by_id) != len(assets) or set(inv_by_id) != set(assets):
        raise ValueError("asset_manifest and bounded source manifest differ")
    for asset_id, asset in assets.items():
        entry = inv_by_id[asset_id]
        if (entry.get("path") != asset["relativePath"] or
                entry.get("sha256") != asset["sha256"] or
                entry.get("source_content_version") != asset["sourceContentVersion"]):
            raise ValueError(f"asset_manifest disagrees with source manifest: {asset_id}")

    cursor = 0
    previous_date = ""
    for shot in plan.get("shots", []):
        ids = shot.get("assetIDs", [])
        if not ids or not isinstance(ids, list) or any(i not in assets for i in ids):
            raise ValueError(f"unlisted asset in shot {shot.get('id')}")
        if shot.get("startFrame") != cursor or not isinstance(shot.get("durationFrames"), int) or shot["durationFrames"] < 30:
            raise ValueError(f"noncontiguous or too-short shot {shot.get('id')}")
        if shot.get("layout") == "pair" and len(ids) != 2:
            raise ValueError("pair layout requires two explicit asset IDs")
        if shot.get("layout") != "pair" and len(ids) != 1:
            raise ValueError("single layout requires one explicit asset ID")
        if shot.get("fit", "contain") != "contain":
            raise ValueError("uncertified crop; use contain until a safe region is recorded")
        if shot.get("motion", "still") not in {"still", "gentle-zoom", "drift-left", "drift-right"}:
            raise ValueError(f"unknown per-shot motion at {shot.get('id')}")
        dates = [assets[i]["captureDate"] for i in ids]
        labels = shot.get("dateLabels", {})
        if set(labels) != set(ids) or any(labels[i] != assets[i]["captureDate"] for i in ids):
            raise ValueError(f"date label disagrees with ImageAll fact: {shot.get('id')}")
        if shot.get("layout") == "pair":
            if not labels or shot.get("role") != "cross-period-comparison":
                raise ValueError("cross-period pair requires both exact dates and an explicit role")
        elif dates[0] < previous_date:
            raise ValueError(f"capture-date order regressed at {shot.get('id')}")
        if shot.get("layout") != "pair":
            previous_date = dates[0]
        cursor += shot["durationFrames"]
    if not plan.get("shots") or cursor != plan.get("totalFrames"):
        raise ValueError("timeline frame total does not match shot durations")
    return manifest, plan


def render(project: Path, name: str, output: Path) -> None:
    from tools.video.video_compose import VideoCompose

    manifest, plan = validate(project, name)
    project = project.resolve()
    output = output.resolve()
    if not output.is_relative_to((project / "renders").resolve()):
        raise ValueError("render output must stay inside this project's renders directory")
    output.parent.mkdir(parents=True, exist_ok=True)
    entry = project / "index.tsx"
    if not entry.is_file() or not (project / "art-direction.md").is_file():
        raise ValueError("missing project-local Atelier source or art direction")
    plan_path = project / "artifacts/plans" / f"{name}.json"
    edit = {
        "version": "1.0",
        "render_runtime": "remotion",
        "composition_mode": "atelier",
        "renderer_family": "photo-story",
        "cuts": [
            {"id": shot["id"], "source": shot["assetIDs"][0], "in_seconds": 0,
             "out_seconds": shot["durationFrames"] / 30, "reason": shot["role"]}
            for shot in plan["shots"]
        ],
        "bespoke": {
            "entry": str(entry), "composition_id": "ChestnutStory",
            "props_path": str(plan_path), "public_dir": str(project / "public"),
            "art_direction": str(project / "art-direction.md"),
            "scale": float(plan.get("renderScale", 1.0)), "crf": 18, "concurrency": 4,
        },
        "metadata": {"scopeDigestSHA256": manifest["scopeDigestSHA256"], "plan": name},
    }
    from schemas.artifacts import validate_artifact
    validate_artifact("edit_decisions", edit)
    edit_path = project / "artifacts/edit_decisions" / f"{name}.json"
    edit_path.parent.mkdir(parents=True, exist_ok=True)
    edit_path.write_text(json.dumps(edit, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    result = VideoCompose().execute({
        "operation": "render", "output_path": str(output), "edit_decisions": edit,
        "asset_manifest": _json(project / "artifacts/asset_manifest.json"),
        "mute_audio": True,
    })
    (project / "artifacts" / f"tool-result-{name}.json").write_text(
        json.dumps({"success": result.success, "error": result.error,
                    "duration_seconds": result.duration_seconds, "data": result.data},
                   ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
    if not result.success:
        raise RuntimeError(result.error)
    print(f"rendered {name}: {output} ({plan['totalFrames']} frames at 30 fps)")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["validate", "render"])
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--plan", required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.action == "render":
        if args.output is None:
            parser.error("render requires --output")
        render(args.project, args.plan, args.output)
    else:
        manifest, plan = validate(args.project, args.plan)
        print(f"validated {args.plan}: {len(plan['shots'])} shots, {plan['totalFrames']} frames, {len(manifest['assets'])} bounded assets")


if __name__ == "__main__":
    main()
