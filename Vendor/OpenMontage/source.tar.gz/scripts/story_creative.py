#!/usr/bin/env python3
"""Local plugin installation/Agent exchange. Does not run an autonomous creative model."""
import argparse
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from tools.tool_registry import registry

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=['capabilities', 'prepare', 'complete'])
    parser.add_argument('--task-root', type=Path, required=True)
    parser.add_argument('--request-id')
    parser.add_argument('--plan', help='workspace-relative plan, only for complete')
    args = parser.parse_args()
    registry.discover()
    result = registry._tools['story_creative_exchange'].execute(dict(operation=args.operation,
        task_root=str(args.task_root.absolute()), request_id=args.request_id, plan=args.plan))
    print(json.dumps(dict(success=result.success, data=result.data, error=result.error), ensure_ascii=False))
    return 0 if result.success else 2

if __name__ == '__main__':
    raise SystemExit(main())
