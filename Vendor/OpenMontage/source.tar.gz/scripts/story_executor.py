#!/usr/bin/env python3
"""Run the local ImageAll Story Executor task-protocol v1 companion."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
import uuid
from pathlib import Path
from typing import Any

REPOSITORY_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPOSITORY_ROOT))

from lib.story_task_executor import (  # noqa: E402
    EXECUTOR_VERSION,
    PROTOCOL_VERSION,
    StoryTaskExecutor,
    _atomic_json,
    _read_json,
    _utc_now,
    daemon_loop,
    executor_process_running,
    readiness_report,
)


def _emit(value: dict[str, Any]) -> None:
    print(json.dumps(value, ensure_ascii=False), flush=True)


def _root(value: Path) -> Path:
    return value.resolve()


def command_check(args: argparse.Namespace) -> int:
    report = readiness_report(_root(args.task_root))
    _emit(report)
    return 0 if report["ready"] else 2


def command_start(args: argparse.Namespace) -> int:
    root = _root(args.task_root)
    if executor_process_running(root):
        _emit({"success": False, "code": "EXECUTOR_ALREADY_RUNNING", "taskRoot": str(root)})
        return 6
    executor = StoryTaskExecutor(root)
    executor.ensure_layout()
    if not args.detach:
        return daemon_loop(root, poll_interval=args.poll_interval)
    stdout_path = executor.executor_dir / "daemon.stdout.log"
    stderr_path = executor.executor_dir / "daemon.stderr.log"
    with stdout_path.open("a", encoding="utf-8") as stdout_handle, stderr_path.open(
        "a", encoding="utf-8"
    ) as stderr_handle:
        process = subprocess.Popen(
            [
                sys.executable,
                str(Path(__file__).resolve()),
                "_daemon",
                "--task-root",
                str(root),
                "--poll-interval",
                str(args.poll_interval),
            ],
            cwd=REPOSITORY_ROOT,
            stdout=stdout_handle,
            stderr=stderr_handle,
            text=True,
            start_new_session=True,
        )
    deadline = time.monotonic() + 8
    while time.monotonic() < deadline:
        if executor_process_running(root):
            _emit(
                {
                    "success": True,
                    "state": "started",
                    "executorVersion": EXECUTOR_VERSION,
                    "taskRoot": str(root),
                    "pid": process.pid,
                }
            )
            return 0
        if process.poll() is not None:
            break
        time.sleep(0.1)
    _emit(
        {
            "success": False,
            "code": "EXECUTOR_START_FAILED",
            "taskRoot": str(root),
            "pid": process.pid,
        }
    )
    return 6


def command_status(args: argparse.Namespace) -> int:
    root = _root(args.task_root)
    executor = StoryTaskExecutor(root)
    summary = executor.summary()
    heartbeat_path = root / "executor/heartbeat.json"
    if heartbeat_path.is_file():
        try:
            summary["heartbeat"] = _read_json(heartbeat_path)
        except (OSError, ValueError, json.JSONDecodeError):
            summary["heartbeat"] = None
    _emit(summary)
    return 0


def command_stop(args: argparse.Namespace) -> int:
    root = _root(args.task_root)
    if not executor_process_running(root):
        _emit({"success": True, "state": "already_stopped", "taskRoot": str(root)})
        return 0
    request = {
        "protocolVersion": PROTOCOL_VERSION,
        "requestID": uuid.uuid4().hex,
        "mode": args.mode,
        "requestedAt": _utc_now(),
        "activeTaskPolicy": (
            "finish the active task before exit"
            if args.mode == "finish-current"
            else "request targeted cancellation and wait for terminal state before exit"
        ),
    }
    _atomic_json(root / "executor/stop-request.json", request)
    if not args.wait:
        _emit(
            {
                "success": True,
                "state": "stop_requested",
                "mode": args.mode,
                "taskRoot": str(root),
            }
        )
        return 0
    deadline = time.monotonic() + args.wait_seconds
    while time.monotonic() < deadline:
        if not executor_process_running(root):
            _emit(
                {
                    "success": True,
                    "state": "stopped",
                    "mode": args.mode,
                    "taskRoot": str(root),
                }
            )
            return 0
        time.sleep(0.2)
    _emit(
        {
            "success": False,
            "code": "EXECUTOR_STOP_PENDING",
            "mode": args.mode,
            "taskRoot": str(root),
        }
    )
    return 7


def command_run_once(args: argparse.Namespace) -> int:
    return daemon_loop(_root(args.task_root), poll_interval=args.poll_interval, once=True)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subcommands = parser.add_subparsers(dest="command", required=True)

    check = subcommands.add_parser("check", help="Print machine-readable local readiness")
    check.add_argument("--task-root", required=True, type=Path)
    check.set_defaults(handler=command_check)

    start = subcommands.add_parser("start", help="Start the one-task local executor")
    start.add_argument("--task-root", required=True, type=Path)
    start.add_argument("--detach", action="store_true", help="Run as an isolated local daemon")
    start.add_argument("--poll-interval", type=float, default=0.5)
    start.set_defaults(handler=command_start)

    status = subcommands.add_parser("status", help="Read executor and task status")
    status.add_argument("--task-root", required=True, type=Path)
    status.set_defaults(handler=command_status)

    stop = subcommands.add_parser("stop", help="Stop accepting work and handle the active task explicitly")
    stop.add_argument("--task-root", required=True, type=Path)
    stop.add_argument(
        "--mode",
        choices=("finish-current", "cancel-current"),
        default="finish-current",
    )
    stop.add_argument("--wait", action="store_true", help="Wait for the executor to exit")
    stop.add_argument("--wait-seconds", type=float, default=120)
    stop.set_defaults(handler=command_stop)

    run_once = subcommands.add_parser("run-once", help="Reconcile exactly one local executor tick")
    run_once.add_argument("--task-root", required=True, type=Path)
    run_once.add_argument("--poll-interval", type=float, default=0.1)
    run_once.set_defaults(handler=command_run_once)

    daemon = subcommands.add_parser("_daemon", help=argparse.SUPPRESS)
    daemon.add_argument("--task-root", required=True, type=Path)
    daemon.add_argument("--poll-interval", type=float, default=0.5)
    daemon.set_defaults(handler=command_start_daemon)
    return parser


def command_start_daemon(args: argparse.Namespace) -> int:
    return daemon_loop(_root(args.task_root), poll_interval=args.poll_interval)


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return int(args.handler(args))


if __name__ == "__main__":
    raise SystemExit(main())
