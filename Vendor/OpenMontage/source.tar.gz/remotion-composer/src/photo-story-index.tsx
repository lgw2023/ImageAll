import React from "react";
import {Composition, registerRoot} from "remotion";
import {
  PhotoStory,
  calculatePhotoStoryMetadata,
  defaultPhotoStoryProps,
} from "./PhotoStory";

const PhotoStoryRoot: React.FC = () => (
  <Composition
    id="PhotoStory"
    component={PhotoStory}
    durationInFrames={defaultPhotoStoryProps.story_render.totalFrames}
    fps={defaultPhotoStoryProps.story_render.fps}
    width={defaultPhotoStoryProps.story_render.width}
    height={defaultPhotoStoryProps.story_render.height}
    defaultProps={defaultPhotoStoryProps}
    calculateMetadata={calculatePhotoStoryMetadata}
  />
);

registerRoot(PhotoStoryRoot);
