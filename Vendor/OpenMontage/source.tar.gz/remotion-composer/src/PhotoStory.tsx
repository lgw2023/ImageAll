import React from "react";
import {Audio} from "@remotion/media";
import {
  AbsoluteFill,
  CalculateMetadataFunction,
  Easing,
  Img,
  Sequence,
  interpolate,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import {resolveAsset} from "./lib/resolveAsset";

type StoryCaption = {
  body?: string;
  timeText?: string;
  locationText?: string;
};

type StorySafeArea = {
  x: number;
  y: number;
  width: number;
  height: number;
};

type StoryFit = {
  mode: "contain" | "cover";
  allowCrop: boolean;
  safeArea?: StorySafeArea;
};

type StoryMotion = {
  type: "static" | "subtle-push" | "pan-left" | "pan-right";
  startScale?: number;
  endScale?: number;
  distanceRatio?: number;
};

type StoryTransition = {
  type: "cut" | "fade";
  durationFrames: number;
};

export type PhotoStoryShot = {
  id: string;
  chapterID: string;
  chapterTitle: string;
  kind: "title" | "chapter-title" | "photo" | "outro";
  assetID?: string;
  src?: string;
  startFrame: number;
  durationFrames: number;
  title?: string;
  caption?: StoryCaption;
  fit?: StoryFit;
  motion?: StoryMotion;
  transitionIn: StoryTransition;
};

type StoryBackground = {
  color: string;
  mode: "solid" | "blurred-photo";
  blurPixels?: number;
  dimOpacity?: number;
};

type StoryTemplate = {
  name: "family-photo-story";
  version: "0.1";
  title?: string;
  subtitle?: string;
  closingText?: string;
  fontFamily?: string;
  textColor?: string;
  accentColor?: string;
  safeMarginRatio?: number;
};

type StoryAudio = {
  assetID: string;
  src: string;
  offsetFrame: number;
  volume: number;
  fadeInFrames: number;
  fadeOutFrames: number;
  loop?: boolean;
};

export type StoryRenderData = {
  schemaVersion: "0.1";
  width: number;
  height: number;
  fps: 30;
  totalFrames: number;
  background: StoryBackground;
  template: StoryTemplate;
  shots: PhotoStoryShot[];
  audio?: StoryAudio;
};

export type PhotoStoryProps = {
  story_render: StoryRenderData;
};

const defaultStory: StoryRenderData = {
  schemaVersion: "0.1",
  width: 1920,
  height: 1080,
  fps: 30,
  totalFrames: 180,
  background: {color: "#111827", mode: "solid"},
  template: {
    name: "family-photo-story",
    version: "0.1",
    title: "Photo Story",
    fontFamily: "Hiragino Sans GB",
    textColor: "#FFFFFF",
    accentColor: "#F2C879",
    safeMarginRatio: 0.07,
  },
  shots: [
    {
      id: "default-title",
      chapterID: "default",
      chapterTitle: "Default",
      kind: "title",
      startFrame: 0,
      durationFrames: 180,
      title: "Photo Story",
      transitionIn: {type: "cut", durationFrames: 0},
    },
  ],
};

export const defaultPhotoStoryProps: PhotoStoryProps = {
  story_render: defaultStory,
};

export const calculatePhotoStoryMetadata: CalculateMetadataFunction<PhotoStoryProps> = async ({
  props,
}) => {
  const story = props.story_render ?? defaultStory;
  return {
    width: story.width,
    height: story.height,
    fps: story.fps,
    durationInFrames: story.totalFrames,
    defaultOutName: `photo-story-${story.width}x${story.height}.mp4`,
  };
};

const clamp = (value: number, min: number, max: number) =>
  Math.min(max, Math.max(min, value));

const fadeOpacity = (
  frame: number,
  durationInFrames: number,
  fadeInFrames: number,
  fadeOutFrames: number,
) => {
  const fadeIn = fadeInFrames > 0
    ? interpolate(frame, [0, fadeInFrames], [0, 1], {
        extrapolateLeft: "clamp",
        extrapolateRight: "clamp",
        easing: Easing.inOut(Easing.quad),
      })
    : 1;
  const fadeOutStart = Math.max(0, durationInFrames - fadeOutFrames);
  const fadeOut = fadeOutFrames > 0
    ? interpolate(frame, [fadeOutStart, durationInFrames], [1, 0], {
        extrapolateLeft: "clamp",
        extrapolateRight: "clamp",
        easing: Easing.inOut(Easing.quad),
      })
    : 1;
  return Math.min(fadeIn, fadeOut);
};

const titleFontSize = (text: string, shortEdge: number, kind: PhotoStoryShot["kind"]) => {
  const base = kind === "chapter-title" ? shortEdge * 0.065 : shortEdge * 0.085;
  const lengthFactor = text.length > 30 ? 0.72 : text.length > 18 ? 0.84 : 1;
  return Math.round(clamp(base * lengthFactor, 42, 112));
};

const TitlePlate: React.FC<{
  shot: PhotoStoryShot;
  template: StoryTemplate;
  background: StoryBackground;
}> = ({shot, template, background}) => {
  const {width, height} = useVideoConfig();
  const shortEdge = Math.min(width, height);
  const margin = Math.round(shortEdge * (template.safeMarginRatio ?? 0.07));
  const text = shot.title || (shot.kind === "outro" ? template.closingText : template.title) || "";
  const secondary = shot.kind === "title"
    ? template.subtitle
    : shot.kind === "chapter-title" && shot.chapterTitle !== text
      ? shot.chapterTitle
      : undefined;
  return (
    <AbsoluteFill
      style={{
        background: `radial-gradient(circle at 50% 42%, ${template.accentColor ?? "#F2C879"}22, transparent 42%), ${background.color}`,
        color: template.textColor ?? "#FFFFFF",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: margin,
        boxSizing: "border-box",
        textAlign: "center",
      }}
    >
      <div style={{maxWidth: width - margin * 2}}>
        <div
          style={{
            fontSize: titleFontSize(text, shortEdge, shot.kind),
            fontWeight: 650,
            lineHeight: 1.22,
            letterSpacing: "0.025em",
            overflowWrap: "anywhere",
          }}
        >
          {text}
        </div>
        {secondary ? (
          <div
            style={{
              marginTop: Math.round(shortEdge * 0.028),
              color: `${template.textColor ?? "#FFFFFF"}CC`,
              fontSize: Math.round(clamp(shortEdge * 0.034, 28, 50)),
              lineHeight: 1.45,
              overflowWrap: "anywhere",
            }}
          >
            {secondary}
          </div>
        ) : null}
        <div
          style={{
            width: Math.round(shortEdge * 0.11),
            height: 3,
            margin: `${Math.round(shortEdge * 0.035)}px auto 0`,
            borderRadius: 3,
            background: template.accentColor ?? "#F2C879",
          }}
        />
      </div>
    </AbsoluteFill>
  );
};

const Caption: React.FC<{
  caption: StoryCaption;
  template: StoryTemplate;
}> = ({caption, template}) => {
  const {width, height} = useVideoConfig();
  const shortEdge = Math.min(width, height);
  const margin = Math.round(shortEdge * (template.safeMarginRatio ?? 0.07));
  const metadata = [caption.timeText, caption.locationText].filter(Boolean).join(" · ");
  if (!metadata && !caption.body) return null;
  return (
    <div
      style={{
        position: "absolute",
        left: margin,
        right: margin,
        bottom: margin,
        display: "flex",
        justifyContent: "center",
        pointerEvents: "none",
      }}
    >
      <div
        style={{
          maxWidth: width - margin * 2,
          padding: `${Math.round(shortEdge * 0.018)}px ${Math.round(shortEdge * 0.028)}px`,
          borderRadius: Math.round(shortEdge * 0.018),
          background: "rgba(7, 12, 20, 0.70)",
          boxShadow: "0 12px 44px rgba(0,0,0,0.28)",
          color: template.textColor ?? "#FFFFFF",
          textAlign: "center",
          backdropFilter: "blur(8px)",
        }}
      >
        {metadata ? (
          <div
            style={{
              color: template.accentColor ?? "#F2C879",
              fontSize: Math.round(clamp(shortEdge * 0.025, 24, 38)),
              lineHeight: 1.35,
              fontWeight: 600,
              overflowWrap: "anywhere",
            }}
          >
            {metadata}
          </div>
        ) : null}
        {caption.body ? (
          <div
            style={{
              marginTop: metadata ? Math.round(shortEdge * 0.009) : 0,
              fontSize: Math.round(clamp(shortEdge * 0.029, 26, 44)),
              lineHeight: 1.45,
              overflowWrap: "anywhere",
            }}
          >
            {caption.body}
          </div>
        ) : null}
      </div>
    </div>
  );
};

const PhotoPlate: React.FC<{
  shot: PhotoStoryShot;
  template: StoryTemplate;
  background: StoryBackground;
}> = ({shot, template, background}) => {
  const frame = useCurrentFrame();
  const {width, height, durationInFrames} = useVideoConfig();
  if (!shot.src || !shot.fit || !shot.motion) return null;

  const progress = interpolate(frame, [0, Math.max(1, durationInFrames - 1)], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: Easing.inOut(Easing.sin),
  });
  const motion = shot.motion;
  const startScale = motion.startScale ?? (motion.type === "subtle-push" ? 0.96 : 1);
  const endScale = motion.endScale ?? 1;
  const scale = interpolate(progress, [0, 1], [startScale, endScale]);
  const distance = (motion.distanceRatio ?? 0.04) * width;
  const translateX = motion.type === "pan-left"
    ? interpolate(progress, [0, 1], [distance, -distance])
    : motion.type === "pan-right"
      ? interpolate(progress, [0, 1], [-distance, distance])
      : 0;
  const safe = shot.fit.safeArea;
  const objectPosition = safe
    ? `${clamp((safe.x + safe.width / 2) * 100, 0, 100)}% ${clamp((safe.y + safe.height / 2) * 100, 0, 100)}%`
    : "50% 50%";
  const margin = Math.round(Math.min(width, height) * (template.safeMarginRatio ?? 0.07) * 0.45);

  return (
    <AbsoluteFill style={{background: background.color, overflow: "hidden"}}>
      {background.mode === "blurred-photo" ? (
        <>
          <Img
            src={resolveAsset(shot.src)}
            style={{
              position: "absolute",
              inset: -Math.max(24, background.blurPixels ?? 24),
              width: `calc(100% + ${Math.max(48, (background.blurPixels ?? 24) * 2)}px)`,
              height: `calc(100% + ${Math.max(48, (background.blurPixels ?? 24) * 2)}px)`,
              objectFit: "cover",
              objectPosition,
              filter: `blur(${background.blurPixels ?? 24}px) saturate(0.9)`,
              transform: "scale(1.04)",
              opacity: 0.92,
            }}
          />
          <AbsoluteFill style={{background: `rgba(0,0,0,${background.dimOpacity ?? 0.38})`}} />
        </>
      ) : null}
      <AbsoluteFill style={{padding: margin, boxSizing: "border-box"}}>
        <Img
          src={resolveAsset(shot.src)}
          style={{
            width: "100%",
            height: "100%",
            objectFit: shot.fit.mode,
            objectPosition,
            transform: `translateX(${translateX}px) scale(${scale})`,
            transformOrigin: objectPosition,
            filter: "drop-shadow(0 18px 54px rgba(0,0,0,0.32))",
          }}
        />
      </AbsoluteFill>
      {shot.caption ? <Caption caption={shot.caption} template={template} /> : null}
    </AbsoluteFill>
  );
};

const StoryShot: React.FC<{
  shot: PhotoStoryShot;
  template: StoryTemplate;
  background: StoryBackground;
  fadeOutFrames: number;
}> = ({shot, template, background, fadeOutFrames}) => {
  const frame = useCurrentFrame();
  const opacity = fadeOpacity(
    frame,
    shot.durationFrames,
    shot.transitionIn.type === "fade" ? shot.transitionIn.durationFrames : 0,
    fadeOutFrames,
  );
  return (
    <AbsoluteFill style={{opacity}}>
      {shot.kind === "photo" ? (
        <PhotoPlate shot={shot} template={template} background={background} />
      ) : (
        <TitlePlate shot={shot} template={template} background={background} />
      )}
    </AbsoluteFill>
  );
};

export const PhotoStory: React.FC<PhotoStoryProps> = ({story_render}) => {
  const story = story_render ?? defaultStory;
  const {fps} = useVideoConfig();
  const fontFamily = `${story.template.fontFamily ?? "Hiragino Sans GB"}, "Heiti SC", sans-serif`;
  return (
    <AbsoluteFill style={{background: story.background.color, fontFamily}}>
      {story.shots.map((shot, index) => {
        const next = story.shots[index + 1];
        const fadeOutFrames = next?.transitionIn.type === "fade"
          ? next.transitionIn.durationFrames
          : 0;
        return (
          <Sequence
            key={shot.id}
            from={shot.startFrame}
            durationInFrames={shot.durationFrames}
            premountFor={fps}
          >
            <StoryShot
              shot={shot}
              template={story.template}
              background={story.background}
              fadeOutFrames={fadeOutFrames}
            />
          </Sequence>
        );
      })}
      {story.audio ? (
        <Sequence
          from={story.audio.offsetFrame}
          durationInFrames={Math.max(1, story.totalFrames - story.audio.offsetFrame)}
          premountFor={fps}
        >
          <Audio
            src={resolveAsset(story.audio.src)}
            loop={story.audio.loop ?? false}
            loopVolumeCurveBehavior="extend"
            volume={(audioFrame) => {
              const available = Math.max(1, story.totalFrames - story.audio!.offsetFrame);
              const fadeIn = story.audio!.fadeInFrames > 0
                ? interpolate(audioFrame, [0, story.audio!.fadeInFrames], [0, 1], {
                    extrapolateLeft: "clamp",
                    extrapolateRight: "clamp",
                  })
                : 1;
              const fadeOutStart = Math.max(0, available - story.audio!.fadeOutFrames);
              const fadeOut = story.audio!.fadeOutFrames > 0
                ? interpolate(audioFrame, [fadeOutStart, available], [1, 0], {
                    extrapolateLeft: "clamp",
                    extrapolateRight: "clamp",
                  })
                : 1;
              return story.audio!.volume * Math.min(fadeIn, fadeOut);
            }}
          />
        </Sequence>
      ) : null}
    </AbsoluteFill>
  );
};
