import React,{useEffect,useState} from 'react';
import {AbsoluteFill,Composition,Img,Sequence,interpolate,registerRoot,staticFile,useCurrentFrame,Easing,delayRender,continueRender,cancelRender} from 'remotion';
let fontPromise:Promise<FontFace>|undefined;
const useCursiveFont=()=>{
 const [handle]=useState(()=>delayRender('Load local cursive font'));
 useEffect(()=>{
  if(!fontPromise){const face=new FontFace('SailimuBrush',`url(${staticFile('fonts/MaShanZheng-Regular.ttf')})`);fontPromise=face.load().then(f=>{document.fonts.add(f);return f;});}
  fontPromise.then(()=>continueRender(handle)).catch(cancelRender);
 },[handle]);
};
type Shot={src:string;index:number;startFrame:number;durationFrames:number;caption:string;treatment:string;width:number;height:number};
type Poem={start:number;duration:number;text:string;ink:boolean};
type Props={shots:Shot[];totalFrames:number;poems:Poem[];fontSize:number;bottomPercent:number};
const Frame:React.FC<{shot:Shot}>=({shot:s})=>{
 const f=useCurrentFrame(); const t=interpolate(f,[0,Math.max(1,s.durationFrames-1)],[0,1],{extrapolateRight:'clamp',easing:Easing.inOut(Easing.sin)});
 const intimate=s.treatment==='intimate'; const landscape=s.treatment==='landscape';
 const fade=interpolate(f,[0,Math.max(1,Math.min(5,s.durationFrames-1))],[0,1],{extrapolateRight:'clamp'});
 const zoom=landscape?1.005+t*0.015:1;
 const light=s.index===0?Math.sin(t*Math.PI)*0.13:0;
 return <AbsoluteFill style={{backgroundColor:intimate?'#ede8df':'#123246',overflow:'hidden'}}>
  {!intimate&&<Img src={staticFile(s.src)} style={{position:'absolute',width:'100%',height:'100%',objectFit:'cover',filter:'blur(36px) brightness(0.72)',transform:'scale(1.12)'}}/>}
  <AbsoluteFill style={{opacity:fade,transform:`scale(${zoom}) translateY(${landscape?0:(0.5-t)*8}px)`}}>
   <Img src={staticFile(s.src)} style={{position:'absolute',left:intimate?44:0,top:intimate?84:0,width:intimate?992:1080,height:intimate?1710:1920,objectFit:'contain',filter:'saturate(0.97) contrast(0.985)',boxShadow:intimate?'0 12px 32px #15263630':undefined}}/>
  </AbsoluteFill>
  {light>0&&<AbsoluteFill style={{background:'linear-gradient(120deg, transparent 22%, #ffdfae 48%, transparent 72%)',opacity:light,transform:`translateX(${(t-.5)*400}px)`,mixBlendMode:'screen'}}/>}

 </AbsoluteFill>;
};
const PoeticLine:React.FC<{poem:Poem;shots:Shot[];fontSize:number;bottomPercent:number}>=({poem:p,shots,fontSize,bottomPercent})=>{
 const f=useCurrentFrame();
 const current=shots.find(s=>f+p.start>=s.startFrame&&f+p.start<s.startFrame+s.durationFrames)!;
 const intimate=current.treatment==='intimate';
 // object-fit:contain measured image rectangle, including original shot motion.
 const box={x:intimate?44:0,y:intimate?84:0,w:intimate?992:1080,h:intimate?1710:1920};
 const scale=Math.min(box.w/current.width,box.h/current.height);
 const imageHeight=current.height*scale;
 const imageWidth=current.width*scale;
 const imageTop=box.y+(box.h-imageHeight)/2;
 const imageBottom=imageTop+imageHeight;
 const local=f+p.start-current.startFrame;
 const t=interpolate(local,[0,Math.max(1,current.durationFrames-1)],[0,1],{extrapolateRight:'clamp',easing:Easing.inOut(Easing.sin)});
 const landscape=current.treatment==='landscape';
 const zoom=landscape?1.005+t*0.015:1;
 const shift=landscape?0:(0.5-t)*8;
 const textBottomY=960+(imageBottom-imageHeight*bottomPercent/100+shift-960)*zoom;
 const bottom=1920-textBottomY;
 const fade=Math.max(1,Math.min(12,Math.floor((p.duration-1)/2)));
 const opacity=p.duration<3?0.88:Math.min(1,f/fade,(p.duration-1-f)/fade)*.88;
 return <AbsoluteFill style={{pointerEvents:'none'}}>
  <div style={{position:'absolute',left:box.x+(box.w-imageWidth)/2,right:box.x+(box.w-imageWidth)/2,bottom:1920-imageBottom,height:Math.min(210,imageHeight*.25),background:'linear-gradient(transparent,rgba(6,21,30,0.20))',opacity}}/>
  <div style={{position:'absolute',left:box.x+(box.w-imageWidth)/2+imageWidth*.05,right:box.x+(box.w-imageWidth)/2+imageWidth*.05,bottom,textAlign:'center',fontFamily:'SailimuBrush',fontWeight:400,fontSize:Math.min(fontSize,imageWidth/Math.max(4,p.text.length)*.85,imageHeight*.12),letterSpacing:3,lineHeight:1.5,color:'#fff9ec',textShadow:'-1px 0 2px rgba(48,48,48,0.72), 1px 0 2px rgba(48,48,48,0.72), 0 -1px 2px rgba(48,48,48,0.72), 0 1px 2px rgba(48,48,48,0.72), 0 0 5px rgba(48,48,48,0.55), 0 2px 8px rgba(32,32,32,0.45)',opacity}}>{p.text}</div>
 </AbsoluteFill>;
};
const Film:React.FC<Props>=({shots,poems=[],fontSize=46,bottomPercent=6})=>{useCursiveFont();return <AbsoluteFill>
 {shots.map(s=><Sequence key={s.index} from={s.startFrame} durationInFrames={s.durationFrames} premountFor={15}><Frame shot={s}/></Sequence>)}
 {poems.map((p,i)=><Sequence key={`poem-${i}`} from={p.start} durationInFrames={p.duration}><PoeticLine poem={p} shots={shots} fontSize={fontSize} bottomPercent={bottomPercent}/></Sequence>)}
</AbsoluteFill>;};
const Root=()=> <Composition id="PhotoPoem" component={Film} width={1080} height={1920} fps={30} durationInFrames={1575} defaultProps={{shots:[],totalFrames:1575,poems:[],fontSize:46,bottomPercent:6}} calculateMetadata={({props})=>({durationInFrames:props.totalFrames})}/>;
registerRoot(Root);
