"""Trusted, data-only ImageAll template rendering; no user supplied code execution."""
from __future__ import annotations
import copy
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STYLE_ROOT = ROOT / 'templates/photo-styles'
IDS = ('brief-title-dissolve', 'in-photo-handwritten-poem')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix('.pending')
    temp.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True))
    temp.replace(path)


def safe(root, relative):
    root = Path(root)
    path = root / relative
    if Path(relative).is_absolute() or '..' in Path(relative).parts:
        raise ValueError('UNSAFE_PATH')
    if root.resolve() != root or any(p.is_symlink() for p in [path, *path.parents]):
        raise ValueError('SYMLINK_REFUSED')
    path.resolve().relative_to(root)
    return path


def implementation_hash():
    files = [Path(__file__), STYLE_ROOT/'poem.tsx', STYLE_ROOT/'fonts/MaShanZheng-Regular.ttf', ROOT/'lib/story_render_adapter.py']
    return hashlib.sha256(''.join(sha(p) for p in files).encode()).hexdigest()


def capabilities(root):
    import importlib.util
    ready = (ROOT/'remotion-composer/node_modules/remotion').is_dir() and all(shutil.which(x) for x in ['ffmpeg','ffprobe','npx']) and importlib.util.find_spec('fontTools') is not None and (STYLE_ROOT/'fonts/MaShanZheng-Regular.ttf').is_file()
    try: digest=implementation_hash()
    except OSError: digest=None;ready=False
    value = dict(protocolVersion='1.0', implementations={i: digest for i in IDS} if digest else {}, ready=bool(ready),
                 detail='' if ready else 'Remotion 或 FFmpeg 尚未安装。', updatedAtMs=int(time.time()*1000))
    write(safe(root, 'templates/capabilities.json'), value)


def validate_request(directory):
    raw = safe(directory, 'request.json').read_bytes()
    if len(raw) > 2_000_000: raise ValueError('OVERSIZE_REQUEST')
    req = json.loads(raw)
    if json.loads(safe(directory, 'complete.json').read_text())['requestSHA256'] != hashlib.sha256(raw).hexdigest():
        raise ValueError('REQUEST_HASH_MISMATCH')
    template = req['style']['template']
    if req['protocolVersion'] != '1.0' or req['requestID'] != directory.name or template['implementation'] not in IDS or template['version'] != '1.0.0':
        raise ValueError('UNSUPPORTED_TEMPLATE_VERSION')
    if req['implementationSHA256'] != implementation_hash(): raise ValueError('IMPLEMENTATION_CHANGED: 请重新提交模板制作。')
    for key, lo, hi in [('titleFrames',1,90), ('cardFrames',10,60), ('fontSize',24,64), ('bottomPercent',3,20)]:
        if type(template[key]) is not int or not lo <= template[key] <= hi: raise ValueError('INVALID_TEMPLATE_PARAMETER')
    n = len(req['photoFrames'])
    if not 1 <= n <= 100 or len(req['style']['lines']) != n or len(req['photoIDs']) != n: raise ValueError('INVALID_PHOTO_COUNT')
    if any(type(f) is not int or not 1 <= f <= 1800 for f in req['photoFrames']): raise ValueError('INVALID_DURATION')
    if any(not isinstance(x,str) or len(x)>80 for x in req['style']['lines']): raise ValueError('INVALID_CAPTION')
    source = safe(directory, 'package/story.json')
    if sha(source) != req['packageSHA256']: raise ValueError('PACKAGE_CHANGED')
    document=json.loads(source.read_text())
    for asset in document['assets']:
        safe(directory, 'package/'+asset['relativePath'])
    from lib.story_render_adapter import validate_story_package
    package = validate_story_package(source)
    if any(i not in package.asset_paths for i in req['photoIDs']): raise ValueError('UNKNOWN_PHOTO')
    return req, package


def short_cards(req, package, directory):
    data = copy.deepcopy(package.data)
    source_photos = {s['assetID']:s for _,s in package.shots if s['kind']=='photo'}
    params = req['style']['template']
    shots = []
    cursor = 0
    previous_line = None
    card_index = 0
    def append(shot, transition):
        nonlocal cursor
        shot['transitionIn'] = {'type':'fade' if transition else 'cut', 'durationFrames':transition}
        shot['sequenceIndex'] = len(shots)
        shot['shotID'] = 'template-shot-'+str(len(shots))
        shot['startFrame'] = max(0,cursor-transition)
        cursor = shot['startFrame']+shot['durationFrames']
        shots.append(shot)
    def card(text, kind, duration):
        shot = copy.deepcopy(source_photos[req['photoIDs'][0]])
        for k in ['assetID','caption','fit','motion']: shot.pop(k,None)
        shot.update(kind=kind,title=text,durationFrames=duration)
        append(shot,min(7,duration//3,shots[-1]['durationFrames']//3) if shots else 0)
    title = req.get('title') or data['export']['template'].get('title') or ''
    data['export']['template']['title']=title
    if title: card(title,'title',params['titleFrames'])
    for i, (asset, frames, text) in enumerate(zip(req['photoIDs'],req['photoFrames'],req['style']['lines'])):
        if text.strip() and text != previous_line:
            card(text,'chapter-title',params['cardFrames']+card_index%2)
            card_index += 1
        shot = copy.deepcopy(source_photos[asset]); shot['durationFrames']=frames
        transition = min(9,frames//3,shots[-1]['durationFrames']-shots[-1]['transitionIn']['durationFrames']) if shots and shots[-1]['kind']!='photo' else min(14,frames//3,shots[-1]['durationFrames']//3) if shots else 0
        append(shot,transition)
        previous_line = text
    chapter = copy.deepcopy(data['chapters'][0]);chapter.update(sequenceIndex=0,shots=shots)
    data['chapters']=[chapter];data['export']['totalFrames']=cursor
    if data.get('audio'):
        for key in ['fadeInFrames','fadeOutFrames']: data['audio'][key]=min(cursor,data['audio'][key])
    data['projectRevision']='sha256:'+hashlib.sha256(json.dumps(data,sort_keys=True).encode()).hexdigest()
    output = directory/'short-package';output.mkdir()
    shutil.copytree(package.package_root/'assets',output/'assets')
    write(output/'story.json',data)
    from lib.story_render_adapter import validate_story_package,prepare_story_run,render_story_run
    prepared = prepare_story_run(validate_story_package(output/'story.json'), projects_root=directory/'runs')
    render_story_run(prepared.project_dir)
    shutil.copyfile(prepared.project_dir/'renders/story-1080x1920.mp4',directory/'final.mp4')
    return cursor


def poem_props(req, package):
    from PIL import Image
    shots=[]; poems=[];cursor=0
    for i,(asset,frames,text) in enumerate(zip(req['photoIDs'],req['photoFrames'],req['style']['lines'])):
        with Image.open(package.asset_paths[asset]) as image: width,height=image.size
        shots.append(dict(src='assets/'+package.asset_paths[asset].name,index=i,startFrame=cursor,durationFrames=frames,
                          caption='',width=width,height=height,treatment='intimate' if req['style']['template']['closingFrame'] and i==len(req['photoIDs'])-1 else 'landscape'))
        if text.strip():
            if poems and poems[-1]['text']==text and poems[-1]['start']+poems[-1]['duration']==cursor: poems[-1]['duration']+=frames
            else: poems.append(dict(start=cursor,duration=frames,text=text,ink=False))
        cursor+=frames
    return dict(shots=shots,poems=poems,totalFrames=cursor,fontSize=req['style']['template']['fontSize'],bottomPercent=req['style']['template']['bottomPercent'])


def render_poem(req,package,directory):
    from fontTools.ttLib import TTFont
    font = STYLE_ROOT/'fonts/MaShanZheng-Regular.ttf'
    with TTFont(font) as f: cmap=f.getBestCmap()
    if any(ord(c) not in cmap for line in req['style']['lines'] for c in line if not c.isspace()): raise ValueError('字体缺少文案中的字形，请修改文字。')
    public=directory/'public';shutil.copytree(package.package_root/'assets',public/'assets');shutil.copytree(STYLE_ROOT/'fonts',public/'fonts')
    props=poem_props(req,package);write(directory/'props.json',props)
    shutil.copyfile(STYLE_ROOT/'poem.tsx',directory/'index.tsx')
    (directory/'art-direction.md').write_text('Approved reusable photo poem template. Ivory readable brush text within the actual photo, soft dark gray edges. Preserve user order and holds. Local only.')
    ed=dict(version='1.0',render_runtime='remotion',composition_mode='atelier',renderer_family='photo-story',cuts=[],bespoke=dict(entry=str(directory/'index.tsx'),composition_id='PhotoPoem',props_path=str(directory/'props.json'),public_dir=str(public),art_direction=str(directory/'art-direction.md'),crf=18,concurrency=4))
    write(directory/'artifacts/edit_decisions.json',ed)
    from tools.video.video_compose import VideoCompose
    result=VideoCompose().execute(dict(operation='render',edit_decisions=ed,output_path=str(directory/'silent.mp4'),mute_audio=True))
    if not result.success: raise RuntimeError(result.error)
    if package.data.get('audio'):
        audio=package.data['audio'];source=package.asset_paths[audio['assetID']]
        duration=props['totalFrames']/30
        fadein=min(duration,audio['fadeInFrames']/30);fadeout=min(duration,audio['fadeOutFrames']/30)
        subprocess.run(['ffmpeg','-v','error','-i',str(directory/'silent.mp4'),'-stream_loop','-1','-i',str(source),'-map','0:v','-map','1:a','-c:v','copy','-c:a','aac','-af',f"volume={audio['volume']},afade=t=in:d={fadein},afade=t=out:st={max(0,duration-fadeout)}:d={fadeout}",'-t',str(duration),str(directory/'final.mp4')],check=True)
    else: shutil.copyfile(directory/'silent.mp4',directory/'final.mp4')
    return props['totalFrames']


def run(directory):
    directory=Path(directory).absolute()
    req,package=validate_request(directory)
    base=dict(requestID=req['requestID'],requestSHA256=sha(directory/'request.json'),implementationSHA256=req['implementationSHA256'])
    write(directory/'result.json',dict(base,status='rendering',detail='正在本地渲染…'))
    try:
        frames=short_cards(req,package,directory) if req['style']['template']['implementation']==IDS[0] else render_poem(req,package,directory)
        info=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-select_streams','v:0','-show_entries','stream=width,height,nb_read_frames,r_frame_rate','-of','json',str(directory/'final.mp4')]))['streams'][0]
        if (info['width'],info['height'],int(info['nb_read_frames']),info['r_frame_rate']) != (1080,1920,frames,'30/1'): raise ValueError('MEDIA_MISMATCH')
        subprocess.run(['ffmpeg','-v','error','-xerror','-i',str(directory/'final.mp4'),'-f','null','-'],check=True,capture_output=True)
        write(directory/'result.json',dict(base,status='succeeded',detail='制作完成，成片已校验。',frames=frames,outputSHA256=sha(directory/'final.mp4')))
    except Exception as exc:
        write(directory/'result.json',dict(base,status='failed',detail='制作失败：'+str(exc)[:400]))
        raise


class TemplateWorker:
    def __init__(self,root): self.root=Path(root);self.process=None;self.last=0;self.directory=None
    def tick(self,accept=True):
        if time.monotonic()-self.last>5:
            capabilities(self.root);self.last=time.monotonic()
        if self.process is not None:
            if self.process.poll() is None: return True
            if self.process.returncode != 0 and self.directory is not None:
                directory=self.directory
                req=json.loads(safe(directory,'request.json').read_text())
                existing=directory/'result.json'
                if not existing.exists() or json.loads(existing.read_text()).get('status')=='rendering':
                    write(existing,dict(requestID=directory.name,requestSHA256=sha(directory/'request.json'),implementationSHA256=req['implementationSHA256'],status='failed',detail='本地制作进程异常结束，请重新提交。'))
            self.process=None
        if not accept: return False
        requests=safe(self.root,'templates/requests');requests.mkdir(parents=True,exist_ok=True)
        for directory in sorted(requests.iterdir()):
            if not directory.name.startswith('template-') or directory.is_symlink() or not directory.is_dir(): continue
            if (directory/'result.json').exists():
                result=json.loads(safe(directory,'result.json').read_text())
                if result.get('status')=='rendering':
                    try:
                        pid=json.loads(safe(directory,'worker.json').read_text())['pid']
                        os.kill(pid,0)
                        return True
                    except (OSError,KeyError,ValueError):
                        result.update(status='failed',detail='制作进程已中断，请重新提交。')
                        write(directory/'result.json',result)
                continue
            if not (directory/'complete.json').exists(): continue
            try: req,_=validate_request(directory)
            except Exception:
                # Invalid submissions never execute. Preserve evidence and let the App report rejection.
                try:
                    req=json.loads(safe(directory,'request.json').read_text())
                    write(directory/'result.json',dict(requestID=directory.name,requestSHA256=sha(directory/'request.json'),implementationSHA256=req.get('implementationSHA256',''),status='failed',detail='模板提交校验失败，请检查版本并重新提交。'))
                except Exception: pass
                continue
            log=(directory/'worker.log').open('w')
            self.process=subprocess.Popen([sys.executable,str(ROOT/'scripts/story_templates.py'),str(directory)],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
            log.close();self.directory=directory
            write(directory/'worker.json',dict(pid=self.process.pid))
            return True
        return False
