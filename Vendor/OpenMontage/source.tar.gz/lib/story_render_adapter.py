"""Deterministic StoryRenderPackage v0.1 validation and artifact conversion.

This module deliberately does not make creative decisions. It consumes an
already-authored story timeline, verifies the package boundary, copies inputs
into a run-scoped workspace, and emits canonical OpenMontage artifacts for the
Remotion photo-story composition.
"""

from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import shutil
import signal
import subprocess
import sys
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any

import jsonschema
from PIL import Image, UnidentifiedImageError

from schemas.artifacts import validate_artifact


REPOSITORY_ROOT = Path(__file__).resolve().parent.parent
STORY_PACKAGE_SCHEMA = (
    REPOSITORY_ROOT
    / "schemas"
    / "integrations"
    / "story_render_package_v0_1.schema.json"
)
SUPPORTED_IMAGE_TYPES = {
    "image/jpeg": {".jpg", ".jpeg"},
    "image/png": {".png"},
}
SUPPORTED_AUDIO_TYPES = {
    "audio/wav": {".wav"},
    "audio/mpeg": {".mp3"},
    "audio/mp4": {".m4a", ".mp4"},
}
ALL_MEDIA_TYPES = {**SUPPORTED_IMAGE_TYPES, **SUPPORTED_AUDIO_TYPES}


@dataclass(frozen=True)
class ValidationIssue:
    code: str
    message: str
    json_pointer: str = ""
    asset_id: str | None = None
    shot_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "code": self.code,
            "message": self.message,
        }
        if self.json_pointer:
            result["jsonPointer"] = self.json_pointer
        if self.asset_id:
            result["assetID"] = self.asset_id
        if self.shot_id:
            result["shotID"] = self.shot_id
        return result


class StoryPackageValidationError(ValueError):
    """Raised when a StoryRenderPackage cannot be safely consumed."""

    def __init__(self, issues: list[ValidationIssue]):
        self.issues = issues
        super().__init__("; ".join(f"{item.code}: {item.message}" for item in issues))


@dataclass(frozen=True)
class ValidatedStoryPackage:
    package_path: Path
    package_root: Path
    data: dict[str, Any]
    asset_paths: dict[str, Path]
    warnings: tuple[ValidationIssue, ...] = field(default_factory=tuple)

    @property
    def shots(self) -> list[tuple[dict[str, Any], dict[str, Any]]]:
        flattened: list[tuple[dict[str, Any], dict[str, Any]]] = []
        for chapter in sorted(self.data["chapters"], key=lambda item: item["sequenceIndex"]):
            for shot in sorted(chapter["shots"], key=lambda item: item["sequenceIndex"]):
                flattened.append((chapter, shot))
        return flattened


@dataclass(frozen=True)
class PreparedStoryRun:
    project_id: str
    project_dir: Path
    package: ValidatedStoryPackage
    asset_manifest: dict[str, Any]
    edit_decisions: dict[str, Any]
    copied_assets: dict[str, Path]


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _json_pointer(parts: Any) -> str:
    escaped = [str(part).replace("~", "~0").replace("/", "~1") for part in parts]
    return "/" + "/".join(escaped) if escaped else ""


def _load_schema() -> dict[str, Any]:
    return json.loads(STORY_PACKAGE_SCHEMA.read_text(encoding="utf-8"))


def _safe_asset_path(package_root: Path, relative_path: str) -> Path:
    """Resolve a package-relative path without permitting escape or URLs."""
    if "\\" in relative_path:
        raise ValueError("backslashes are not allowed; package paths use POSIX separators")
    pure = PurePosixPath(relative_path)
    if pure.is_absolute() or ".." in pure.parts:
        raise ValueError("path must stay below the package root")
    if re.match(r"^[A-Za-z][A-Za-z0-9+.-]*:", relative_path):
        raise ValueError("remote URLs and URI schemes are not allowed")

    root = package_root.resolve(strict=True)
    candidate = package_root.joinpath(*pure.parts)
    resolved = candidate.resolve(strict=True)
    try:
        resolved.relative_to(root)
    except ValueError as exc:
        raise ValueError("path or symlink resolves outside the package root") from exc
    if not resolved.is_file():
        raise ValueError("asset path does not resolve to a regular file")
    return resolved


def _validate_image(path: Path, media_type: str) -> str | None:
    try:
        with Image.open(path) as image:
            detected = (image.format or "").upper()
            orientation = image.getexif().get(274, 1)
            if orientation not in (None, 1):
                return "image orientation is not normalized (EXIF orientation must be 1)"
            expected = "JPEG" if media_type == "image/jpeg" else "PNG"
            if detected != expected:
                return f"declared {media_type} but decoder detected {detected or 'unknown'}"
        # Pillow requires verify() immediately after open(). Metadata reads such
        # as getexif() may advance PNG parsing state, so use a second read-only
        # handle for the integrity pass.
        with Image.open(path) as image:
            image.verify()
    except (UnidentifiedImageError, OSError, ValueError, RuntimeError) as exc:
        return f"image cannot be decoded: {type(exc).__name__}"
    return None


def _validate_audio(path: Path) -> str | None:
    try:
        result = subprocess.run(
            [
                "ffprobe",
                "-v",
                "error",
                "-select_streams",
                "a:0",
                "-show_entries",
                "stream=codec_type",
                "-of",
                "default=nw=1:nk=1",
                str(path),
            ],
            capture_output=True,
            text=True,
            timeout=20,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return f"audio verification unavailable: {type(exc).__name__}"
    if result.returncode != 0 or result.stdout.strip() != "audio":
        return "file does not contain a decodable audio stream"
    return None


def _schema_issues(data: Any) -> list[ValidationIssue]:
    validator = jsonschema.Draft202012Validator(_load_schema())
    issues: list[ValidationIssue] = []
    for error in sorted(validator.iter_errors(data), key=lambda item: list(item.absolute_path)):
        issues.append(
            ValidationIssue(
                code="SCHEMA_INVALID",
                message=error.message,
                json_pointer=_json_pointer(error.absolute_path),
            )
        )
    return issues


def validate_story_package(
    package_path: str | Path,
    *,
    verify_assets: bool = True,
) -> ValidatedStoryPackage:
    """Validate a StoryRenderPackage and return resolved, read-only inputs.

    Unknown versions, invalid timelines, missing assets, hash mismatches,
    unsupported formats, absolute/remote paths, traversal, and escaping symlinks
    fail closed. Unsafe crop/motion requests are accepted only with an explicit
    warning because conversion deterministically degrades them to contain/static.
    """
    package_file = Path(package_path)
    issues: list[ValidationIssue] = []
    warnings: list[ValidationIssue] = []

    try:
        raw = package_file.read_text(encoding="utf-8")
        data = json.loads(raw)
    except FileNotFoundError:
        raise StoryPackageValidationError(
            [ValidationIssue("PACKAGE_NOT_FOUND", "package JSON file does not exist")]
        )
    except UnicodeDecodeError:
        raise StoryPackageValidationError(
            [ValidationIssue("PACKAGE_NOT_UTF8", "package JSON must be UTF-8")]
        )
    except json.JSONDecodeError as exc:
        raise StoryPackageValidationError(
            [ValidationIssue("PACKAGE_JSON_INVALID", f"invalid JSON at line {exc.lineno}, column {exc.colno}")]
        )

    if not isinstance(data, dict):
        raise StoryPackageValidationError(
            [ValidationIssue("SCHEMA_INVALID", "package root must be a JSON object")]
        )

    issues.extend(_schema_issues(data))
    if issues:
        raise StoryPackageValidationError(issues)

    package_root = package_file.parent
    asset_paths: dict[str, Path] = {}
    asset_records: dict[str, dict[str, Any]] = {}
    for index, asset in enumerate(data["assets"]):
        asset_id = asset["assetID"]
        pointer = f"/assets/{index}"
        if asset_id in asset_records:
            issues.append(
                ValidationIssue(
                    "DUPLICATE_ASSET_ID",
                    "assetID must be unique",
                    f"{pointer}/assetID",
                    asset_id=asset_id,
                )
            )
            continue
        asset_records[asset_id] = asset

        media_type = asset["mediaType"]
        suffix = Path(asset["relativePath"]).suffix.lower()
        if suffix not in ALL_MEDIA_TYPES[media_type]:
            issues.append(
                ValidationIssue(
                    "MEDIA_EXTENSION_MISMATCH",
                    f"extension {suffix or '(none)'} is not supported for {media_type}",
                    f"{pointer}/relativePath",
                    asset_id=asset_id,
                )
            )
            continue
        try:
            resolved = _safe_asset_path(package_root, asset["relativePath"])
        except FileNotFoundError:
            issues.append(
                ValidationIssue(
                    "ASSET_NOT_FOUND",
                    "asset file does not exist below the package root",
                    f"{pointer}/relativePath",
                    asset_id=asset_id,
                )
            )
            continue
        except (OSError, ValueError) as exc:
            issues.append(
                ValidationIssue(
                    "ASSET_PATH_UNSAFE",
                    str(exc),
                    f"{pointer}/relativePath",
                    asset_id=asset_id,
                )
            )
            continue
        asset_paths[asset_id] = resolved

        if verify_assets:
            actual_hash = _sha256(resolved)
            if actual_hash != asset["renderFileSHA256"]:
                issues.append(
                    ValidationIssue(
                        "ASSET_HASH_MISMATCH",
                        "render file checksum does not match renderFileSHA256",
                        f"{pointer}/renderFileSHA256",
                        asset_id=asset_id,
                    )
                )
            decode_error = (
                _validate_image(resolved, media_type)
                if media_type in SUPPORTED_IMAGE_TYPES
                else _validate_audio(resolved)
            )
            if decode_error:
                issues.append(
                    ValidationIssue(
                        "ASSET_DECODE_FAILED",
                        decode_error,
                        f"{pointer}/relativePath",
                        asset_id=asset_id,
                    )
                )

    chapters = sorted(data["chapters"], key=lambda item: item["sequenceIndex"])
    chapter_indexes = [chapter["sequenceIndex"] for chapter in chapters]
    if chapter_indexes != list(range(len(chapters))):
        issues.append(
            ValidationIssue(
                "CHAPTER_SEQUENCE_INVALID",
                "chapter sequenceIndex values must be unique and contiguous from 0",
                "/chapters",
            )
        )

    chapter_ids: set[str] = set()
    shot_ids: set[str] = set()
    flattened: list[tuple[dict[str, Any], dict[str, Any], str]] = []
    for chapter_index, chapter in enumerate(chapters):
        if chapter["chapterID"] in chapter_ids:
            issues.append(
                ValidationIssue(
                    "DUPLICATE_CHAPTER_ID",
                    "chapterID must be unique even when a source chapter recurs",
                    f"/chapters/{chapter_index}/chapterID",
                )
            )
        chapter_ids.add(chapter["chapterID"])

        shots = sorted(chapter["shots"], key=lambda item: item["sequenceIndex"])
        indexes = [shot["sequenceIndex"] for shot in shots]
        if indexes != list(range(len(shots))):
            issues.append(
                ValidationIssue(
                    "SHOT_SEQUENCE_INVALID",
                    "shot sequenceIndex values must be unique and contiguous from 0 within a chapter",
                    f"/chapters/{chapter_index}/shots",
                )
            )
        for shot_index, shot in enumerate(shots):
            pointer = f"/chapters/{chapter_index}/shots/{shot_index}"
            shot_id = shot["shotID"]
            if shot_id in shot_ids:
                issues.append(
                    ValidationIssue(
                        "DUPLICATE_SHOT_ID",
                        "shotID must be unique across the package",
                        f"{pointer}/shotID",
                        shot_id=shot_id,
                    )
                )
            shot_ids.add(shot_id)
            flattened.append((chapter, shot, pointer))

            if shot["kind"] == "photo":
                asset_id = shot["assetID"]
                asset = asset_records.get(asset_id)
                if asset is None:
                    issues.append(
                        ValidationIssue(
                            "SHOT_ASSET_MISSING",
                            "photo shot references an unknown assetID",
                            f"{pointer}/assetID",
                            asset_id=asset_id,
                            shot_id=shot_id,
                        )
                    )
                elif asset["mediaType"] not in SUPPORTED_IMAGE_TYPES:
                    issues.append(
                        ValidationIssue(
                            "SHOT_ASSET_NOT_IMAGE",
                            "photo shot must reference a normalized JPEG or PNG asset",
                            f"{pointer}/assetID",
                            asset_id=asset_id,
                            shot_id=shot_id,
                        )
                    )

                fit = shot["fit"]
                motion_type = shot["motion"]["type"]
                crop_safe = bool(fit.get("allowCrop") and fit.get("safeArea"))
                if fit["mode"] == "cover" and not crop_safe:
                    warnings.append(
                        ValidationIssue(
                            "UNSAFE_CROP_DEGRADED",
                            "cover was requested without allowCrop plus safeArea; renderer will use contain",
                            f"{pointer}/fit",
                            shot_id=shot_id,
                        )
                    )
                if motion_type in {"pan-left", "pan-right"} and not crop_safe:
                    warnings.append(
                        ValidationIssue(
                            "UNSAFE_MOTION_DEGRADED",
                            "pan was requested without allowCrop plus safeArea; renderer will use static motion",
                            f"{pointer}/motion",
                            shot_id=shot_id,
                        )
                    )
                safe_area = fit.get("safeArea")
                if safe_area and (
                    safe_area["x"] + safe_area["width"] > 1
                    or safe_area["y"] + safe_area["height"] > 1
                ):
                    issues.append(
                        ValidationIssue(
                            "SAFE_AREA_OUT_OF_BOUNDS",
                            "safeArea must remain inside normalized image coordinates",
                            f"{pointer}/fit/safeArea",
                            shot_id=shot_id,
                        )
                    )

    if flattened:
        first_shot = flattened[0][1]
        if first_shot["startFrame"] != 0:
            issues.append(
                ValidationIssue(
                    "TIMELINE_START_INVALID",
                    "the first shot must start at frame 0",
                    f"{flattened[0][2]}/startFrame",
                    shot_id=first_shot["shotID"],
                )
            )
        if first_shot["transitionIn"]["durationFrames"] != 0:
            issues.append(
                ValidationIssue(
                    "FIRST_TRANSITION_INVALID",
                    "the first shot transitionIn duration must be 0",
                    f"{flattened[0][2]}/transitionIn/durationFrames",
                    shot_id=first_shot["shotID"],
                )
            )

        previous = first_shot
        for _chapter, shot, pointer in flattened[1:]:
            overlap = shot["transitionIn"]["durationFrames"]
            expected_start = previous["startFrame"] + previous["durationFrames"] - overlap
            if shot["startFrame"] != expected_start:
                issues.append(
                    ValidationIssue(
                        "TIMELINE_DISCONTINUITY",
                        f"startFrame must be {expected_start} so transition overlap is exact",
                        f"{pointer}/startFrame",
                        shot_id=shot["shotID"],
                    )
                )
            if overlap > min(previous["durationFrames"], shot["durationFrames"]):
                issues.append(
                    ValidationIssue(
                        "TRANSITION_TOO_LONG",
                        "transition overlap cannot exceed either adjacent shot duration",
                        f"{pointer}/transitionIn/durationFrames",
                        shot_id=shot["shotID"],
                    )
                )
            if shot["transitionIn"]["type"] == "cut" and overlap != 0:
                issues.append(
                    ValidationIssue(
                        "CUT_OVERLAP_INVALID",
                        "cut transitions must have durationFrames 0",
                        f"{pointer}/transitionIn/durationFrames",
                        shot_id=shot["shotID"],
                    )
                )
            if shot["transitionIn"]["type"] == "fade" and overlap <= 0:
                issues.append(
                    ValidationIssue(
                        "FADE_OVERLAP_INVALID",
                        "fade transitions require a positive durationFrames overlap",
                        f"{pointer}/transitionIn/durationFrames",
                        shot_id=shot["shotID"],
                    )
                )
            previous = shot

        actual_total = max(
            shot["startFrame"] + shot["durationFrames"] for _chapter, shot, _pointer in flattened
        )
        if actual_total != data["export"]["totalFrames"]:
            issues.append(
                ValidationIssue(
                    "TOTAL_FRAMES_MISMATCH",
                    f"export.totalFrames must equal the final exclusive frame {actual_total}",
                    "/export/totalFrames",
                )
            )

    audio = data.get("audio")
    if audio:
        asset = asset_records.get(audio["assetID"])
        if asset is None:
            issues.append(
                ValidationIssue(
                    "AUDIO_ASSET_MISSING",
                    "audio references an unknown assetID",
                    "/audio/assetID",
                    asset_id=audio["assetID"],
                )
            )
        elif asset["mediaType"] not in SUPPORTED_AUDIO_TYPES:
            issues.append(
                ValidationIssue(
                    "AUDIO_ASSET_NOT_AUDIO",
                    "audio must reference a supported local audio asset",
                    "/audio/assetID",
                    asset_id=audio["assetID"],
                )
            )
        available_audio_frames = data["export"]["totalFrames"] - audio["offsetFrame"]
        if available_audio_frames <= 0:
            issues.append(
                ValidationIssue(
                    "AUDIO_OFFSET_OUT_OF_RANGE",
                    "audio offsetFrame must be before export.totalFrames",
                    "/audio/offsetFrame",
                    asset_id=audio["assetID"],
                )
            )
        if audio["fadeInFrames"] + audio["fadeOutFrames"] > max(0, available_audio_frames):
            issues.append(
                ValidationIssue(
                    "AUDIO_FADES_TOO_LONG",
                    "combined audio fades cannot exceed the frames available after offsetFrame",
                    "/audio",
                    asset_id=audio["assetID"],
                )
            )

    if issues:
        raise StoryPackageValidationError(issues)
    return ValidatedStoryPackage(
        package_path=package_file.resolve(),
        package_root=package_root.resolve(),
        data=data,
        asset_paths=asset_paths,
        warnings=tuple(warnings),
    )


def validation_report(package_path: str | Path, *, verify_assets: bool = True) -> dict[str, Any]:
    """Return a stable machine-readable validation report without absolute paths."""
    try:
        validated = validate_story_package(package_path, verify_assets=verify_assets)
    except StoryPackageValidationError as exc:
        return {
            "version": "0.1",
            "valid": False,
            "errors": [issue.to_dict() for issue in exc.issues],
            "warnings": [],
        }
    data = validated.data
    return {
        "version": "0.1",
        "valid": True,
        "projectID": data["projectID"],
        "projectRevision": data["projectRevision"],
        "assetCount": len(data["assets"]),
        "shotCount": len(validated.shots),
        "totalFrames": data["export"]["totalFrames"],
        "fps": data["export"]["fps"],
        "durationSeconds": data["export"]["totalFrames"] / data["export"]["fps"],
        "warnings": [warning.to_dict() for warning in validated.warnings],
        "errors": [],
    }


def _safe_slug(value: str) -> str:
    slug = re.sub(r"[^A-Za-z0-9._-]+", "-", value).strip("-._").lower()
    return (slug or "story")[:80]


def _atomic_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def _artifact_path(path: Path) -> str:
    try:
        return path.resolve().relative_to(REPOSITORY_ROOT.resolve()).as_posix()
    except ValueError:
        return path.resolve().as_posix()


def _command_version(command: list[str]) -> str | None:
    try:
        result = subprocess.run(
            command,
            cwd=REPOSITORY_ROOT,
            capture_output=True,
            text=True,
            timeout=20,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    output = (result.stdout or result.stderr).strip()
    return output.splitlines()[0] if result.returncode == 0 and output else None


def _git_runtime_state() -> dict[str, Any]:
    commit = _command_version(["git", "rev-parse", "HEAD"])
    status = subprocess.run(
        ["git", "status", "--porcelain"],
        cwd=REPOSITORY_ROOT,
        capture_output=True,
        text=True,
        timeout=20,
        check=False,
    )
    return {
        "commit": commit,
        "worktreeDirty": status.returncode != 0 or bool(status.stdout.strip()),
    }


def _runtime_environment_report() -> dict[str, Any]:
    git_state = _git_runtime_state()
    remotion_package = REPOSITORY_ROOT / "remotion-composer/node_modules/remotion/package.json"
    remotion_version = None
    if remotion_package.is_file():
        try:
            remotion_version = json.loads(remotion_package.read_text(encoding="utf-8")).get("version")
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            remotion_version = None
    return {
        "version": "0.1",
        "openMontageCommit": git_state["commit"],
        "openMontageWorktreeDirty": git_state["worktreeDirty"],
        "platform": platform.platform(),
        "machine": platform.machine(),
        "python": sys.version.split()[0],
        "node": _command_version(["node", "--version"]),
        "ffmpeg": _command_version(["ffmpeg", "-version"]),
        "ffprobe": _command_version(["ffprobe", "-version"]),
        "remotion": remotion_version,
        "logicalCPUCount": os.cpu_count(),
        "renderRuntime": "remotion",
        "renderConcurrency": "Remotion runtime default; not explicitly pinned",
        "networkRequired": False,
        "schemaSHA256": _sha256(STORY_PACKAGE_SCHEMA),
    }


def _normalise_photo_presentation(shot: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    fit = dict(shot["fit"])
    motion = dict(shot["motion"])
    crop_safe = bool(fit.get("allowCrop") and fit.get("safeArea"))
    if fit["mode"] == "cover" and not crop_safe:
        fit = {"mode": "contain", "allowCrop": False}
    if motion["type"] in {"pan-left", "pan-right"} and not crop_safe:
        motion = {"type": "static"}
    return fit, motion


def _build_artifacts(
    validated: ValidatedStoryPackage,
    project_dir: Path,
    copied_assets: dict[str, Path],
) -> tuple[dict[str, Any], dict[str, Any]]:
    data = validated.data
    first_scene_by_asset: dict[str, str] = {}
    for _chapter, shot in validated.shots:
        if shot.get("assetID"):
            first_scene_by_asset.setdefault(shot["assetID"], shot["shotID"])
    if data.get("audio"):
        first_scene_by_asset.setdefault(data["audio"]["assetID"], "story-audio")

    manifest_assets: list[dict[str, Any]] = []
    for asset in data["assets"]:
        asset_id = asset["assetID"]
        media_type = asset["mediaType"]
        manifest_assets.append(
            {
                "id": asset_id,
                "type": "image" if media_type.startswith("image/") else "music",
                "path": _artifact_path(copied_assets[asset_id]),
                "source_tool": "story_render_adapter",
                "scene_id": first_scene_by_asset.get(asset_id, "package-asset"),
                "format": media_type,
                "subtype": "upstream-authored-local",
                "generation_summary": "Copied byte-for-byte from a validated StoryRenderPackage input.",
                "provider": "local-package",
                "license": "upstream-provided; distribution status not asserted by OpenMontage",
                "sha256": _sha256(copied_assets[asset_id]),
                "source_content_version": asset["sourceContentVersion"],
            }
        )
    asset_manifest = {
        "version": "1.0",
        "assets": manifest_assets,
        "total_cost_usd": 0,
        "metadata": {
            "storyRenderSchemaVersion": data["schemaVersion"],
            "projectID": data["projectID"],
            "projectRevision": data["projectRevision"],
            "inputPackageSHA256": _sha256(validated.package_path),
        },
    }

    fps = data["export"]["fps"]
    cuts: list[dict[str, Any]] = []
    normalised_shots: list[dict[str, Any]] = []
    for global_sequence_index, (chapter, shot) in enumerate(validated.shots):
        transition = shot["transitionIn"]
        source = shot.get("assetID", "")
        cut: dict[str, Any] = {
            "id": shot["shotID"],
            "source": source,
            "in_seconds": shot["startFrame"] / fps,
            "out_seconds": (shot["startFrame"] + shot["durationFrames"]) / fps,
            "layer": "primary",
            "transition_in": transition["type"],
            "transition_duration": transition["durationFrames"] / fps,
            "reason": f"Preserve upstream shot {shot['trace']['originalShotID']} in chapter {chapter['chapterID']}",
        }
        if shot["kind"] == "photo":
            fit, motion = _normalise_photo_presentation(shot)
            cut["transform"] = {
                "scale": 1.0,
                "position": "center",
                "animation": motion["type"],
            }
        cuts.append(cut)

        normalised: dict[str, Any] = {
            "id": shot["shotID"],
            "chapterID": chapter["chapterID"],
            "chapterTitle": chapter["title"],
            "globalSequenceIndex": global_sequence_index,
            "chapterSequenceIndex": shot["sequenceIndex"],
            "kind": shot["kind"],
            "startFrame": shot["startFrame"],
            "durationFrames": shot["durationFrames"],
            "transitionIn": transition,
            "trace": shot["trace"],
        }
        for optional in ("title", "caption"):
            if optional in shot:
                normalised[optional] = shot[optional]
        if shot["kind"] == "photo":
            fit, motion = _normalise_photo_presentation(shot)
            normalised.update(
                {
                    "assetID": source,
                    "src": _artifact_path(copied_assets[source]),
                    "fit": fit,
                    "motion": motion,
                }
            )
        normalised_shots.append(normalised)

    story_render: dict[str, Any] = {
        "schemaVersion": "0.1",
        "width": data["export"]["width"],
        "height": data["export"]["height"],
        "fps": fps,
        "totalFrames": data["export"]["totalFrames"],
        "background": data["export"]["background"],
        "template": data["export"]["template"],
        "chapters": [
            {
                "chapterID": chapter["chapterID"],
                "sequenceIndex": chapter["sequenceIndex"],
                "title": chapter["title"],
                "trace": chapter["trace"],
                "shotIDs": [
                    shot["shotID"]
                    for shot in sorted(chapter["shots"], key=lambda item: item["sequenceIndex"])
                ],
            }
            for chapter in sorted(data["chapters"], key=lambda item: item["sequenceIndex"])
        ],
        "shots": normalised_shots,
    }
    if data.get("audio"):
        audio = data["audio"]
        story_render["audio"] = {
            **audio,
            "src": _artifact_path(copied_assets[audio["assetID"]]),
        }

    edit_decisions = {
        "version": "1.0",
        "cuts": cuts,
        "render_runtime": "remotion",
        "renderer_family": "photo-story",
        "composition_mode": "templated",
        "story_render": story_render,
        "metadata": {
            "proposal_render_runtime": "remotion",
            "target_duration_seconds": data["export"]["totalFrames"] / fps,
            "compose_target": {
                "width": data["export"]["width"],
                "height": data["export"]["height"],
                "fit": "contain",
            },
            "storyRenderProjectID": data["projectID"],
            "storyRenderProjectRevision": data["projectRevision"],
            "storyRenderSchemaSHA256": _sha256(STORY_PACKAGE_SCHEMA),
            "approvalPolicy": "Objective pre-authorized deterministic local adapter renders only",
        },
    }
    validate_artifact("asset_manifest", asset_manifest)
    validate_artifact("edit_decisions", edit_decisions)
    return asset_manifest, edit_decisions


_MISSING = object()


def _json_differences(
    expected: Any,
    actual: Any,
    *,
    pointer: str = "",
) -> list[dict[str, Any]]:
    """Return stable, JSON-serializable semantic differences."""
    differences: list[dict[str, Any]] = []
    if isinstance(expected, dict) and isinstance(actual, dict):
        for key in sorted(set(expected) | set(actual)):
            child_pointer = f"{pointer}/{key.replace('~', '~0').replace('/', '~1')}"
            expected_value = expected.get(key, _MISSING)
            actual_value = actual.get(key, _MISSING)
            if expected_value is _MISSING or actual_value is _MISSING:
                differences.append(
                    {
                        "jsonPointer": child_pointer,
                        "expected": "<missing>" if expected_value is _MISSING else expected_value,
                        "actual": "<missing>" if actual_value is _MISSING else actual_value,
                    }
                )
            else:
                differences.extend(
                    _json_differences(expected_value, actual_value, pointer=child_pointer)
                )
        return differences
    if isinstance(expected, list) and isinstance(actual, list):
        for index in range(max(len(expected), len(actual))):
            child_pointer = f"{pointer}/{index}"
            expected_value = expected[index] if index < len(expected) else _MISSING
            actual_value = actual[index] if index < len(actual) else _MISSING
            if expected_value is _MISSING or actual_value is _MISSING:
                differences.append(
                    {
                        "jsonPointer": child_pointer,
                        "expected": "<missing>" if expected_value is _MISSING else expected_value,
                        "actual": "<missing>" if actual_value is _MISSING else actual_value,
                    }
                )
            else:
                differences.extend(
                    _json_differences(expected_value, actual_value, pointer=child_pointer)
                )
        return differences
    if expected != actual:
        differences.append({"jsonPointer": pointer or "/", "expected": expected, "actual": actual})
    return differences


def _expected_consistency_projection(validated: ValidatedStoryPackage) -> dict[str, Any]:
    data = validated.data
    shots: list[dict[str, Any]] = []
    for global_sequence_index, (chapter, shot) in enumerate(validated.shots):
        projected: dict[str, Any] = {
            "id": shot["shotID"],
            "chapterID": chapter["chapterID"],
            "chapterTitle": chapter["title"],
            "globalSequenceIndex": global_sequence_index,
            "chapterSequenceIndex": shot["sequenceIndex"],
            "kind": shot["kind"],
            "startFrame": shot["startFrame"],
            "durationFrames": shot["durationFrames"],
            "transitionIn": shot["transitionIn"],
            "trace": shot["trace"],
        }
        for optional in ("title", "caption"):
            if optional in shot:
                projected[optional] = shot[optional]
        if shot["kind"] == "photo":
            projected.update(
                {
                    "assetID": shot["assetID"],
                    "fit": shot["fit"],
                    "motion": shot["motion"],
                }
            )
        shots.append(projected)
    return {
        "identity": {
            "schemaVersion": data["schemaVersion"],
            "projectID": data["projectID"],
            "projectRevision": data["projectRevision"],
        },
        "export": data["export"],
        "assets": [
            {
                "assetID": asset["assetID"],
                "mediaType": asset["mediaType"],
                "sourceContentVersion": asset["sourceContentVersion"],
                "renderFileSHA256": asset["renderFileSHA256"],
            }
            for asset in data["assets"]
        ],
        "chapters": [
            {
                "chapterID": chapter["chapterID"],
                "sequenceIndex": chapter["sequenceIndex"],
                "title": chapter["title"],
                "trace": chapter["trace"],
                "shotIDs": [
                    shot["shotID"]
                    for shot in sorted(chapter["shots"], key=lambda item: item["sequenceIndex"])
                ],
            }
            for chapter in sorted(data["chapters"], key=lambda item: item["sequenceIndex"])
        ],
        "shots": shots,
        "audio": data.get("audio"),
    }


def _actual_consistency_projection(
    asset_manifest: dict[str, Any],
    edit_decisions: dict[str, Any],
) -> dict[str, Any]:
    story = edit_decisions["story_render"]
    shots = []
    for shot in story["shots"]:
        shots.append({key: value for key, value in shot.items() if key != "src"})
    audio = story.get("audio")
    if audio is not None:
        audio = {key: value for key, value in audio.items() if key != "src"}
    return {
        "identity": {
            "schemaVersion": story["schemaVersion"],
            "projectID": edit_decisions["metadata"].get("storyRenderProjectID"),
            "projectRevision": edit_decisions["metadata"].get("storyRenderProjectRevision"),
        },
        "export": {
            "width": story["width"],
            "height": story["height"],
            "fps": story["fps"],
            "totalFrames": story["totalFrames"],
            "background": story["background"],
            "template": story["template"],
        },
        "assets": [
            {
                "assetID": asset["id"],
                "mediaType": asset.get("format"),
                "sourceContentVersion": asset.get("source_content_version"),
                "renderFileSHA256": asset.get("sha256"),
            }
            for asset in asset_manifest["assets"]
        ],
        "chapters": story.get("chapters", []),
        "shots": shots,
        "audio": audio,
    }


def build_story_consistency_report(
    validated: ValidatedStoryPackage,
    asset_manifest: dict[str, Any],
    edit_decisions: dict[str, Any],
    copied_assets: dict[str, Path],
) -> dict[str, Any]:
    """Compare a validated package with the exact task-local production artifacts."""
    expected = _expected_consistency_projection(validated)
    actual = _actual_consistency_projection(asset_manifest, edit_decisions)
    differences: list[dict[str, Any]] = []
    checks: list[dict[str, Any]] = []
    for section in ("identity", "export", "assets", "chapters", "shots", "audio"):
        section_differences = _json_differences(
            expected[section],
            actual[section],
            pointer=f"/{section}",
        )
        differences.extend(section_differences)
        checks.append(
            {
                "name": f"{section}_preserved",
                "passed": not section_differences,
                "differenceCount": len(section_differences),
            }
        )

    copied_asset_failures: list[dict[str, Any]] = []
    expected_assets = {asset["assetID"]: asset for asset in validated.data["assets"]}
    for asset_id, path in copied_assets.items():
        expected_hash = expected_assets[asset_id]["renderFileSHA256"]
        actual_hash = _sha256(path)
        if actual_hash != expected_hash:
            copied_asset_failures.append(
                {
                    "assetID": asset_id,
                    "expectedSHA256": expected_hash,
                    "actualSHA256": actual_hash,
                }
            )
    checks.append(
        {
            "name": "copied_asset_bytes_preserved",
            "passed": not copied_asset_failures,
            "failures": copied_asset_failures,
        }
    )
    source_hash = _sha256(validated.package_path)
    recorded_source_hash = asset_manifest.get("metadata", {}).get("inputPackageSHA256")
    checks.append(
        {
            "name": "source_package_hash_recorded",
            "passed": source_hash == recorded_source_hash,
            "expected": source_hash,
            "actual": recorded_source_hash,
        }
    )
    schema_hash = _sha256(STORY_PACKAGE_SCHEMA)
    recorded_schema_hash = edit_decisions.get("metadata", {}).get("storyRenderSchemaSHA256")
    checks.append(
        {
            "name": "schema_hash_recorded",
            "passed": schema_hash == recorded_schema_hash,
            "expected": schema_hash,
            "actual": recorded_schema_hash,
        }
    )
    passed = all(check["passed"] for check in checks)
    return {
        "version": "0.1",
        "status": "pass" if passed else "fail",
        "projectID": validated.data["projectID"],
        "projectRevision": validated.data["projectRevision"],
        "inputPackageSHA256": source_hash,
        "schemaSHA256": schema_hash,
        "checks": checks,
        "differences": differences,
        "warnings": [warning.to_dict() for warning in validated.warnings],
    }


def _resolve_task_asset_path(project_dir: Path, value: str) -> Path:
    path = Path(value)
    resolved = path.resolve() if path.is_absolute() else (REPOSITORY_ROOT / path).resolve()
    try:
        resolved.relative_to(project_dir.resolve())
    except ValueError as exc:
        raise ValueError("task-local asset path escapes the prepared run directory") from exc
    return resolved


def verify_prepared_story_run_consistency(
    project_dir: str | Path,
    *,
    external_package_path: str | Path | None = None,
    warnings: tuple[ValidationIssue, ...] | None = None,
) -> dict[str, Any]:
    """Recompute input-to-artifact consistency from a prepared run snapshot."""
    task_dir = Path(project_dir).resolve()
    original_path = task_dir / "artifacts" / "source_package.original.json"
    semantic_path = task_dir / "artifacts" / "source_package.json"
    manifest_path = task_dir / "artifacts" / "asset_manifest.json"
    edit_path = task_dir / "artifacts" / "edit_decisions.json"
    for required in (original_path, semantic_path, manifest_path, edit_path):
        if not required.is_file():
            raise FileNotFoundError(f"prepared run is missing {required.name}")

    original_data = json.loads(original_path.read_text(encoding="utf-8"))
    semantic_data = _read_json(semantic_path)
    asset_manifest = _read_json(manifest_path)
    edit_decisions = _read_json(edit_path)
    copied_assets = {
        asset["id"]: _resolve_task_asset_path(task_dir, asset["path"])
        for asset in asset_manifest["assets"]
    }
    validated = ValidatedStoryPackage(
        package_path=original_path,
        package_root=task_dir,
        data=semantic_data,
        asset_paths=copied_assets,
        warnings=warnings or (),
    )
    report = build_story_consistency_report(
        validated,
        asset_manifest,
        edit_decisions,
        copied_assets,
    )
    semantic_check = {
        "name": "source_snapshot_semantics_preserved",
        "passed": original_data == semantic_data,
        "differenceCount": len(
            _json_differences(original_data, semantic_data, pointer="/sourcePackage")
        ),
    }
    report["checks"].append(semantic_check)
    if not semantic_check["passed"]:
        report["differences"].extend(
            _json_differences(original_data, semantic_data, pointer="/sourcePackage")
        )
    if external_package_path is not None:
        external_path = Path(external_package_path).resolve()
        external_hash = _sha256(external_path)
        snapshot_hash = _sha256(original_path)
        report["checks"].append(
            {
                "name": "external_input_snapshot_preserved",
                "passed": external_hash == snapshot_hash,
                "expected": external_hash,
                "actual": snapshot_hash,
            }
        )
    if warnings is None:
        existing_path = task_dir / "reports" / "consistency_report.json"
        if existing_path.is_file():
            report["warnings"] = _read_json(existing_path).get("warnings", [])
    report["status"] = "pass" if all(check["passed"] for check in report["checks"]) else "fail"
    _atomic_json(task_dir / "reports" / "consistency_report.json", report)
    return report


def prepare_story_run(
    validated: ValidatedStoryPackage,
    *,
    projects_root: str | Path | None = None,
    run_suffix: str | None = None,
) -> PreparedStoryRun:
    """Copy validated inputs into a unique task directory and emit artifacts."""
    root = Path(projects_root) if projects_root else REPOSITORY_ROOT / "projects"
    data = validated.data
    suffix = run_suffix or uuid.uuid4().hex[:10]
    project_id = f"{_safe_slug(data['projectID'])}-r{_safe_slug(data['projectRevision'])}-{_safe_slug(suffix)}"
    project_dir = root / project_id
    if project_dir.exists():
        raise FileExistsError(f"run directory already exists for project id {project_id}")

    for relative in (
        "artifacts",
        "assets/input",
        "assets/audio",
        "renders",
        "reports/frames",
        "control",
    ):
        (project_dir / relative).mkdir(parents=True, exist_ok=False if relative == "artifacts" else True)

    environment = _runtime_environment_report()
    marker = {
        "version": "1.0",
        "project_id": project_id,
        "title": data["export"]["template"].get("title") or data["projectID"],
        "pipeline_type": "imageall-story-render",
        "workflow_kind": "deterministic_adapter",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "source_project_id": data["projectID"],
        "source_project_revision": data["projectRevision"],
        "openmontage_commit": environment["openMontageCommit"],
        "openmontage_worktree_dirty": environment["openMontageWorktreeDirty"],
    }
    _atomic_json(project_dir / "project.json", marker)
    _atomic_json(project_dir / "reports" / "environment.json", environment)

    copied_assets: dict[str, Path] = {}
    for asset in data["assets"]:
        asset_id = asset["assetID"]
        source = validated.asset_paths[asset_id]
        destination_root = project_dir / (
            "assets/input" if asset["mediaType"].startswith("image/") else "assets/audio"
        )
        id_digest = hashlib.sha256(asset_id.encode("utf-8")).hexdigest()[:8]
        destination = destination_root / f"{_safe_slug(asset_id)}-{id_digest}{source.suffix.lower()}"
        shutil.copy2(source, destination)
        if _sha256(destination) != asset["renderFileSHA256"]:
            raise IOError(f"copied asset failed integrity verification: {asset_id}")
        copied_assets[asset_id] = destination

    asset_manifest, edit_decisions = _build_artifacts(validated, project_dir, copied_assets)
    _atomic_json(project_dir / "artifacts" / "asset_manifest.json", asset_manifest)
    _atomic_json(project_dir / "artifacts" / "edit_decisions.json", edit_decisions)
    _atomic_json(project_dir / "artifacts" / "source_package.json", data)
    shutil.copy2(validated.package_path, project_dir / "artifacts" / "source_package.original.json")
    verify_prepared_story_run_consistency(
        project_dir,
        external_package_path=validated.package_path,
        warnings=validated.warnings,
    )
    _atomic_json(
        project_dir / "reports" / "validation_report.json",
        validation_report(validated.package_path),
    )
    _atomic_json(
        project_dir / "status.json",
        {
            "version": "0.1",
            "state": "prepared",
            "stage": "preparation",
            "progress": 0.3,
            "projectID": project_id,
            "updatedAt": datetime.now(timezone.utc).isoformat(),
            "errors": [],
        },
    )
    return PreparedStoryRun(
        project_id=project_id,
        project_dir=project_dir,
        package=validated,
        asset_manifest=asset_manifest,
        edit_decisions=edit_decisions,
        copied_assets=copied_assets,
    )


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _redact_runtime_error(message: str, project_dir: Path) -> str:
    redacted = message.replace(str(project_dir.resolve()), "<task>")
    redacted = redacted.replace(str(REPOSITORY_ROOT.resolve()), "<repository>")
    return redacted


def _write_status(
    project_dir: Path,
    *,
    state: str,
    stage: str,
    progress: float,
    error_code: str | None = None,
    message: str | None = None,
) -> dict[str, Any]:
    status: dict[str, Any] = {
        "version": "0.1",
        "state": state,
        "stage": stage,
        "progress": round(max(0, min(1, progress)), 3),
        "projectID": project_dir.name,
        "updatedAt": datetime.now(timezone.utc).isoformat(),
        "errors": [],
    }
    if error_code:
        status["errors"].append(
            {
                "code": error_code,
                "stage": stage,
                "message": message or error_code,
            }
        )
    _atomic_json(project_dir / "status.json", status)
    event = {key: value for key, value in status.items() if key != "errors"}
    if status["errors"]:
        event["error"] = status["errors"][0]
    with (project_dir / "events.jsonl").open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event, ensure_ascii=False) + "\n")
    return status


def _parse_rate(rate: str | None) -> float:
    if not rate or rate in {"0/0", "N/A"}:
        return 0.0
    numerator, separator, denominator = rate.partition("/")
    try:
        return float(numerator) / float(denominator) if separator else float(numerator)
    except (TypeError, ValueError, ZeroDivisionError):
        return 0.0


def _probe_media(path: Path) -> dict[str, Any]:
    probe = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-count_frames",
            "-show_streams",
            "-show_format",
            "-of",
            "json",
            str(path),
        ],
        capture_output=True,
        text=True,
        timeout=60,
        check=False,
    )
    if probe.returncode != 0:
        raise RuntimeError("ffprobe could not read the pending render")
    return json.loads(probe.stdout)


def _mean_audio_volume_db(path: Path, *, start_seconds: float, duration_seconds: float) -> float | None:
    """Measure a short audio window without decoding it into a temporary file."""
    result = subprocess.run(
        [
            "ffmpeg",
            "-hide_banner",
            "-nostats",
            "-ss",
            f"{max(0, start_seconds):.6f}",
            "-t",
            f"{max(0.05, duration_seconds):.6f}",
            "-i",
            str(path),
            "-vn",
            "-af",
            "volumedetect",
            "-f",
            "null",
            "-",
        ],
        capture_output=True,
        text=True,
        timeout=60,
        check=False,
    )
    if result.returncode != 0:
        return None
    match = re.search(r"mean_volume:\s*(-?(?:\d+(?:\.\d+)?|inf))\s*dB", result.stderr)
    if not match or match.group(1) == "-inf":
        return None
    return float(match.group(1))


def _extract_representative_frames(
    video_path: Path,
    report_dir: Path,
    story_render: dict[str, Any],
) -> list[dict[str, Any]]:
    frame_requests: list[tuple[str, int]] = []
    shots = story_render["shots"]
    for shot in shots:
        frame_requests.append((f"{shot['id']}-mid", shot["startFrame"] + shot["durationFrames"] // 2))
        if shot["transitionIn"]["durationFrames"] > 0:
            frame_requests.append(
                (
                    f"{shot['id']}-transition-mid",
                    shot["startFrame"] + shot["transitionIn"]["durationFrames"] // 2,
                )
            )
    unique: list[tuple[str, int]] = []
    seen_frames: set[int] = set()
    for label, frame in frame_requests:
        frame = max(0, min(story_render["totalFrames"] - 1, frame))
        if frame not in seen_frames:
            unique.append((label, frame))
            seen_frames.add(frame)
    if len(unique) > 16:
        step = (len(unique) - 1) / 15
        unique = [unique[round(index * step)] for index in range(16)]

    report_dir.mkdir(parents=True, exist_ok=True)
    captures: list[dict[str, Any]] = []
    for index, (label, frame) in enumerate(unique):
        safe_label = _safe_slug(label)
        output = report_dir / f"{index:02d}-f{frame:05d}-{safe_label}.png"
        result = subprocess.run(
            [
                "ffmpeg",
                "-v",
                "error",
                "-i",
                str(video_path),
                "-vf",
                f"select=eq(n\\,{frame})",
                "-frames:v",
                "1",
                "-y",
                str(output),
            ],
            capture_output=True,
            timeout=60,
            check=False,
        )
        if result.returncode != 0 or not output.is_file():
            continue
        with Image.open(output) as image:
            luminance = image.convert("L").resize((160, 90))
            values = list(luminance.getdata())
            black_ratio = sum(1 for value in values if value < 8) / len(values)
        captures.append(
            {
                "label": label,
                "frame": frame,
                "path": _artifact_path(output),
                "nearBlackPixelRatio": round(black_ratio, 5),
            }
        )
    return captures


def _verify_render(
    pending_path: Path,
    project_dir: Path,
    edit_decisions: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, Any]]:
    story = edit_decisions["story_render"]
    expected_frames = story["totalFrames"]
    expected_fps = story["fps"]
    expected_duration = expected_frames / expected_fps
    probe = _probe_media(pending_path)
    video = next((stream for stream in probe.get("streams", []) if stream.get("codec_type") == "video"), None)
    audio = next((stream for stream in probe.get("streams", []) if stream.get("codec_type") == "audio"), None)
    if not video:
        raise RuntimeError("render has no video stream")

    actual_frames_raw = video.get("nb_read_frames") or video.get("nb_frames")
    try:
        actual_frames = int(actual_frames_raw)
    except (TypeError, ValueError):
        actual_frames = -1
    actual_fps = _parse_rate(video.get("avg_frame_rate") or video.get("r_frame_rate"))
    actual_duration = float(video.get("duration") or probe.get("format", {}).get("duration") or 0)

    checks = [
        {
            "name": "full_decode",
            "passed": False,
            "expected": "ffmpeg decode completes without errors",
        },
        {
            "name": "dimensions",
            "passed": (video.get("width"), video.get("height")) == (story["width"], story["height"]),
            "expected": f"{story['width']}x{story['height']}",
            "actual": f"{video.get('width')}x{video.get('height')}",
        },
        {
            "name": "frame_rate",
            "passed": abs(actual_fps - expected_fps) < 0.001,
            "expected": expected_fps,
            "actual": actual_fps,
        },
        {
            "name": "frame_count",
            "passed": actual_frames == expected_frames,
            "expected": expected_frames,
            "actual": actual_frames,
        },
        {
            "name": "duration",
            "passed": abs(actual_duration - expected_duration) <= max(0.05, 1 / expected_fps),
            "expected": expected_duration,
            "actual": actual_duration,
            "toleranceSeconds": max(0.05, 1 / expected_fps),
        },
        {
            "name": "audio_presence",
            "passed": bool(audio) == bool(story.get("audio")),
            "expected": bool(story.get("audio")),
            "actual": bool(audio),
        },
    ]
    if audio and story.get("audio"):
        audio_duration = float(audio.get("duration") or probe.get("format", {}).get("duration") or 0)
        duration_tolerance = max(0.1, 2 / expected_fps)
        checks.append(
            {
                "name": "audio_duration",
                "passed": abs(audio_duration - expected_duration) <= duration_tolerance,
                "expected": expected_duration,
                "actual": audio_duration,
                "toleranceSeconds": duration_tolerance,
            }
        )
        audio_contract = story["audio"]
        fade_in_seconds = audio_contract["fadeInFrames"] / expected_fps
        fade_out_seconds = audio_contract["fadeOutFrames"] / expected_fps
        sample_seconds = min(0.5, max(0.2, expected_duration / 20))
        middle_start = min(
            max(fade_in_seconds + 1, expected_duration / 2),
            max(0, expected_duration - fade_out_seconds - sample_seconds - 1),
        )
        volumes = {
            "startMeanDb": _mean_audio_volume_db(
                pending_path,
                start_seconds=0,
                duration_seconds=sample_seconds,
            ),
            "middleMeanDb": _mean_audio_volume_db(
                pending_path,
                start_seconds=middle_start,
                duration_seconds=sample_seconds,
            ),
            "endMeanDb": _mean_audio_volume_db(
                pending_path,
                start_seconds=max(0, expected_duration - sample_seconds),
                duration_seconds=max(0.05, sample_seconds - 0.05),
            ),
        }
        fade_checks: list[bool] = []
        if audio_contract["fadeInFrames"] > 0:
            fade_checks.append(
                volumes["startMeanDb"] is not None
                and volumes["middleMeanDb"] is not None
                and volumes["startMeanDb"] <= volumes["middleMeanDb"] - 3
            )
        if audio_contract["fadeOutFrames"] > 0:
            fade_checks.append(
                volumes["endMeanDb"] is not None
                and volumes["middleMeanDb"] is not None
                and volumes["endMeanDb"] <= volumes["middleMeanDb"] - 3
            )
        checks.append(
            {
                "name": "audio_fade_shape",
                "passed": all(fade_checks),
                "expected": "requested fade edges are at least 3 dB quieter than the steady middle",
                "actual": volumes,
                "fadeInFrames": audio_contract["fadeInFrames"],
                "fadeOutFrames": audio_contract["fadeOutFrames"],
            }
        )
    decode = subprocess.run(
        ["ffmpeg", "-v", "error", "-i", str(pending_path), "-f", "null", "-"],
        capture_output=True,
        timeout=max(120, int(expected_duration * 5)),
        check=False,
    )
    checks[0]["passed"] = decode.returncode == 0

    captures = _extract_representative_frames(
        pending_path,
        project_dir / "reports" / "frames",
        story,
    )
    black_frames = [capture for capture in captures if capture["nearBlackPixelRatio"] > 0.985]
    checks.append(
        {
            "name": "representative_frames_not_near_black",
            "passed": not black_frames,
            "sampleCount": len(captures),
            "flaggedFrames": [capture["frame"] for capture in black_frames],
        }
    )
    verification = {
        "version": "0.1",
        "status": "pass" if all(check["passed"] for check in checks) else "fail",
        "checks": checks,
        "representativeFrames": captures,
        "notes": [
            "Frame count is authoritative; container duration is checked with a one-frame-or-50ms tolerance.",
            "Representative-frame checks detect near-black output but do not replace human review of text, crop safety, or visual rhythm.",
            "Synthetic fixtures do not establish acceptance with private ImageAll photos.",
        ],
    }
    media = {
        "videoCodec": video.get("codec_name"),
        "audioCodec": audio.get("codec_name") if audio else None,
        "width": video.get("width"),
        "height": video.get("height"),
        "fps": actual_fps,
        "frames": actual_frames,
        "durationSeconds": actual_duration,
        "fileSizeBytes": pending_path.stat().st_size,
    }
    return verification, media


def render_story_run(project_dir: str | Path) -> dict[str, Any]:
    """Render one prepared run through the approved Remotion path.

    The output remains hidden under a pending filename until full decode and
    media-contract verification pass. Failure never replaces an existing final
    file and only removes the pending file created by this invocation.
    """
    from tools.video.video_compose import VideoCompose

    task_dir = Path(project_dir).resolve()
    try:
        consistency = verify_prepared_story_run_consistency(task_dir)
    except (FileNotFoundError, ValueError, json.JSONDecodeError, KeyError) as exc:
        _write_status(
            task_dir,
            state="failed",
            stage="preparation",
            progress=0.3,
            error_code="INTEROP_CONSISTENCY_REPORT_FAILED",
            message=f"consistency verification could not run: {type(exc).__name__}",
        )
        raise RuntimeError("INTEROP_CONSISTENCY_REPORT_FAILED") from exc
    if consistency.get("status") != "pass":
        _write_status(
            task_dir,
            state="failed",
            stage="preparation",
            progress=0.3,
            error_code="INTEROP_CONSISTENCY_FAILED",
            message="input package and adapted production artifacts differ",
        )
        raise RuntimeError("INTEROP_CONSISTENCY_FAILED")
    edit_path = task_dir / "artifacts" / "edit_decisions.json"
    manifest_path = task_dir / "artifacts" / "asset_manifest.json"
    if not edit_path.is_file() or not manifest_path.is_file():
        raise FileNotFoundError("prepared run is missing required artifacts")
    edit_decisions = _read_json(edit_path)
    asset_manifest = _read_json(manifest_path)
    validate_artifact("edit_decisions", edit_decisions)
    validate_artifact("asset_manifest", asset_manifest)

    tool = VideoCompose()
    if not tool.get_info()["render_engines"].get("remotion"):
        _write_status(
            task_dir,
            state="failed",
            stage="rendering",
            progress=0.35,
            error_code="REMOTION_UNAVAILABLE",
            message="Remotion is not available; no renderer substitution was attempted",
        )
        raise RuntimeError("Remotion is unavailable; run npm ci in remotion-composer")

    story = edit_decisions["story_render"]
    final_path = task_dir / "renders" / f"story-{story['width']}x{story['height']}.mp4"
    if final_path.exists():
        raise FileExistsError("successful output already exists for this unique task directory")
    pending_path = task_dir / "renders" / f".pending-{uuid.uuid4().hex}.mp4"
    started = time.monotonic()
    _write_status(task_dir, state="running", stage="rendering", progress=0.4)
    try:
        result = tool.execute(
            {
                "operation": "render",
                "edit_decisions": edit_decisions,
                "asset_manifest": asset_manifest,
                "proposal_packet": {"production_plan": {"render_runtime": "remotion"}},
                "output_path": str(pending_path),
                "project_dir": str(task_dir),
                "remotion_timeout_ms": 120000,
                "mute_audio": not bool(story.get("audio")),
            }
        )
        if not result.success:
            raise RuntimeError(_redact_runtime_error(result.error or "Remotion render failed", task_dir))
        _write_status(task_dir, state="running", stage="audio_processing", progress=0.82)
        _write_status(task_dir, state="running", stage="verification", progress=0.88)
        verification, media = _verify_render(pending_path, task_dir, edit_decisions)
        _atomic_json(task_dir / "reports" / "media_verification.json", verification)
        if verification["status"] != "pass":
            failed = [check["name"] for check in verification["checks"] if not check["passed"]]
            raise RuntimeError(f"render verification failed: {', '.join(failed)}")

        pending_path.replace(final_path)
        final_review = result.data.get("final_review") if result.data else None
        if isinstance(final_review, dict):
            _atomic_json(task_dir / "reports" / "final_review.json", final_review)
        elapsed = round(time.monotonic() - started, 3)
        environment = _read_json(task_dir / "reports" / "environment.json")
        render_report = {
            "version": "1.0",
            "outputs": [
                {
                    "path": _artifact_path(final_path),
                    "format": "mp4",
                    "codec": media["videoCodec"] or "unknown",
                    "audio_codec": media["audioCodec"] or "none",
                    "resolution": f"{media['width']}x{media['height']}",
                    "fps": media["fps"],
                    "duration_seconds": media["durationSeconds"],
                    "file_size_bytes": media["fileSizeBytes"],
                    "platform_target": "landscape" if story["width"] >= story["height"] else "portrait",
                }
            ],
            "render_time_seconds": elapsed,
            "warnings": [],
            "verification_notes": verification["notes"],
            "render_grammar": "photo-story",
            "final_review_ref": _artifact_path(task_dir / "reports" / "final_review.json") if final_review else "",
            "metadata": {
                "storyRenderSchemaVersion": story["schemaVersion"],
                "storyRenderSchemaSHA256": environment["schemaSHA256"],
                "storyRenderProjectID": consistency["projectID"],
                "storyRenderProjectRevision": consistency["projectRevision"],
                "inputPackageSHA256": consistency["inputPackageSHA256"],
                "openMontageCommit": environment["openMontageCommit"],
                "openMontageWorktreeDirty": environment["openMontageWorktreeDirty"],
                "renderRuntime": environment["renderRuntime"],
                "renderConcurrency": environment["renderConcurrency"],
                "expectedFrames": story["totalFrames"],
                "actualFrames": media["frames"],
                "consistencyReportRef": _artifact_path(task_dir / "reports" / "consistency_report.json"),
                "environmentRef": _artifact_path(task_dir / "reports" / "environment.json"),
                "mediaVerificationRef": _artifact_path(task_dir / "reports" / "media_verification.json"),
            },
        }
        validate_artifact("render_report", render_report)
        _atomic_json(task_dir / "artifacts" / "render_report.json", render_report)
        status = _write_status(task_dir, state="succeeded", stage="verification", progress=1)
        return {
            "success": True,
            "projectID": task_dir.name,
            "status": status,
            "output": _artifact_path(final_path),
            "renderReport": _artifact_path(task_dir / "artifacts" / "render_report.json"),
            "verificationReport": _artifact_path(task_dir / "reports" / "media_verification.json"),
        }
    except BaseException as exc:
        if pending_path.exists():
            pending_path.unlink()
        if isinstance(exc, (KeyboardInterrupt, SystemExit)):
            _write_status(
                task_dir,
                state="cancelled",
                stage="rendering",
                progress=0.4,
                error_code="RENDER_CANCELLED",
                message="render was cancelled; pending output was removed",
            )
            raise
        message = _redact_runtime_error(str(exc), task_dir)
        _write_status(
            task_dir,
            state="failed",
            stage="verification" if (task_dir / "reports" / "media_verification.json").exists() else "rendering",
            progress=0.9 if (task_dir / "reports" / "media_verification.json").exists() else 0.4,
            error_code="RENDER_FAILED",
            message=message,
        )
        raise


def inspect_story_run(project_dir: str | Path) -> dict[str, Any]:
    task_dir = Path(project_dir)
    status_path = task_dir / "status.json"
    if not status_path.is_file():
        raise FileNotFoundError("task status does not exist")
    result: dict[str, Any] = {
        "projectID": task_dir.name,
        "status": _read_json(status_path),
    }
    for key, relative in (
        ("environment", "reports/environment.json"),
        ("validationReport", "reports/validation_report.json"),
        ("consistencyReport", "reports/consistency_report.json"),
        ("renderReport", "artifacts/render_report.json"),
        ("verificationReport", "reports/media_verification.json"),
    ):
        path = task_dir / relative
        if path.is_file():
            result[key] = _read_json(path)
    return result


def install_worker_signal_handlers(project_dir: str | Path) -> None:
    """Ensure TERM/INT mark only this run cancelled before worker exit."""
    task_dir = Path(project_dir)

    def handle_cancel(_signum: int, _frame: Any) -> None:
        _write_status(
            task_dir,
            state="cancelled",
            stage="rendering",
            progress=0.4,
            error_code="RENDER_CANCELLED",
            message="render was cancelled; no successful output was published",
        )
        raise SystemExit(130)

    signal.signal(signal.SIGTERM, handle_cancel)
    signal.signal(signal.SIGINT, handle_cancel)
