"""Bounded local exchange. Persistence/validation only; creative intelligence stays with Agent skills."""
from __future__ import annotations
import contextlib
import fcntl
import hashlib
import json
import re
import shutil
import uuid
from pathlib import Path
import jsonschema
from lib.checkpoint import init_project, write_checkpoint, validate_checkpoint

VERSION = '1.1.0'
SCHEMA = Path(__file__).resolve().parents[1] / 'schemas/integrations/creative_plugin_v1.schema.json'

class CreativeError(ValueError):
    pass

def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def encode(value: dict) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()

def safe(root: Path, relative: str) -> Path:
    if root.is_symlink() or root.absolute() != root.resolve():
        raise CreativeError('UNSAFE_ROOT')
    part = Path(relative)
    if part.is_absolute() or '..' in part.parts:
        raise CreativeError('UNSAFE_PATH')
    current = root
    for component in part.parts:
        current = current / component
        if current.is_symlink():
            raise CreativeError('UNSAFE_PATH')
    if not current.resolve().is_relative_to(root.resolve()):
        raise CreativeError('UNSAFE_PATH')
    return current

def read(path: Path) -> dict:
    if not path.is_file() or path.stat().st_size > 2_000_000:
        raise CreativeError('MISSING_OR_OVERSIZE_DOCUMENT')
    return json.loads(path.read_bytes())

def write(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name('.' + path.name + '.' + uuid.uuid4().hex)
    temp.write_bytes(encode(value))
    temp.replace(path)

def validate(value: dict, kind: str) -> None:
    schema = json.loads(SCHEMA.read_text())
    try:
        jsonschema.validate(value, schema['$defs'][kind])
    except jsonschema.ValidationError as exc:
        # Do not echo private payloads or arbitrary remote content into public logs.
        raise CreativeError('INVALID_' + kind.upper()) from exc

def capabilities(root: Path) -> dict:
    value = dict(protocolVersion='1.1', profile='editable-story-v1', pluginID='openmontage',
                 pluginVersion=VERSION, planningMode='agent-assisted', automaticPlanning=False,
                 renderProtocol='1.1', renderPackage='0.1', externalSendAllowed=False)
    validate(value, 'capabilities')
    write(safe(root, 'creative/capabilities.json'), value)
    return value

def request_dir(root: Path, request_id: str) -> Path:
    if not re.fullmatch(r'creative-[a-f0-9-]{36}', request_id):
        raise CreativeError('INVALID_REQUEST_ID')
    return safe(root, 'creative/requests/' + request_id)

@contextlib.contextmanager
def lock(directory: Path):
    # Lock only our control file; App's cancellation marker is checked again at publish.
    with safe(directory, '.plugin.lock').open('a') as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        yield

def load_request(root: Path, request_id: str) -> tuple[Path, dict, str, dict]:
    directory = request_dir(root, request_id)
    if safe(directory, 'cancel.json').exists():
        raise CreativeError('CANCELLED')
    request_path = safe(directory, 'request.json')
    request = read(request_path)
    validate(request, 'request')
    request_hash = digest(request_path.read_bytes())
    if read(safe(directory, 'complete.json')).get('requestSHA256') != request_hash:
        raise CreativeError('REQUEST_HASH_MISMATCH')
    if request['requestID'] != request_id:
        raise CreativeError('REQUEST_ID_MISMATCH')
    story_path = safe(directory, 'package/story.json')
    story = read(story_path)
    if digest(story_path.read_bytes()) != request['storySHA256']:
        raise CreativeError('SOURCE_CHANGED')
    if story.get('schemaVersion') != '0.1' or story.get('projectID') != request['projectID']:
        raise CreativeError('INCOMPATIBLE_PACKAGE')
    assets = story['assets']
    by_id = {a['assetID']: a for a in assets}
    facts = {f['assetID']: f for f in request['facts']}
    if len(by_id) != len(assets) or len(facts) != len(request['facts']):
        raise CreativeError('DUPLICATE_ID')
    if set(facts) != {a['assetID'] for a in assets if a['mediaType'].startswith('image/')}:
        raise CreativeError('SCOPE_MISMATCH')
    for asset in assets:
        path = safe(directory, 'package/' + asset['relativePath'])
        if not path.is_file() or digest(path.read_bytes()) != asset['renderFileSHA256']:
            raise CreativeError('SOURCE_CHANGED')
        if asset['assetID'] in facts:
            fact = facts[asset['assetID']]
            if (fact['sha256'] != asset['renderFileSHA256'] or
                    fact['contentVersion'] != asset['sourceContentVersion']):
                raise CreativeError('FACT_SOURCE_MISMATCH')
    shots = request['shots']
    if len({s['shotID'] for s in shots}) != len(shots) or any(s['assetID'] not in facts for s in shots):
        raise CreativeError('INVALID_SHOT_REFERENCES')
    return directory, request, request_hash, story

def prepare(root: Path, request_id: str) -> dict:
    directory, request, request_hash, story = load_request(root, request_id)
    with lock(directory):
        workspace = safe(directory, 'workspace')
        bound = safe(directory, 'workspace/artifacts/creative-request-binding.json')
        if bound.exists():
            if read(bound).get('requestSHA256') != request_hash:
                raise CreativeError('REQUEST_CHANGED')
            ready_path = safe(directory, 'ready.json')
            if ready_path.exists():
                ready = read(ready_path)
                plan_path = safe(directory, 'plan.json')
                if ready.get('requestSHA256') != request_hash or digest(plan_path.read_bytes()) != ready.get('planSHA256'):
                    raise CreativeError('PLAN_HASH_MISMATCH')
                validate_plan(request, request_hash, read(plan_path))
                return dict(state='ready', workspace=str(workspace), resumed=True)
            return dict(state='awaiting_agent', workspace=str(workspace), resumed=True)
        workspace = init_project('workspace', title=request['title'], pipeline_type='private-photo-atelier', pipeline_dir=directory)
        # Only listed, normalized package media; no source path or library access.
        public = safe(directory, 'workspace/public/assets')
        public.mkdir(parents=True, exist_ok=True)
        sources = []
        inventory = []
        for asset in story['assets']:
            source = safe(directory, 'package/' + asset['relativePath'])
            target = safe(directory, 'workspace/public/' + asset['relativePath'])
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            if digest(target.read_bytes()) != asset['renderFileSHA256']:
                raise CreativeError('COPY_HASH_MISMATCH')
            inventory.append(dict(id=asset['assetID'], type='image' if asset['mediaType'].startswith('image/') else 'audio',
                                  path='public/' + asset['relativePath'], source_tool='imageall-export',
                                  scene_id='bounded-candidate', sha256=asset['renderFileSHA256'],
                                  source_content_version=asset['sourceContentVersion']))
            sources.append(dict(assetID=asset['assetID'], relativePath='public/' + asset['relativePath'],
                                sha256=asset['renderFileSHA256'], sourceContentVersion=asset['sourceContentVersion']))
        write(safe(directory, 'workspace/artifacts/asset_manifest.json'), dict(version='1.0', assets=inventory))
        write(safe(directory, 'workspace/artifacts/creative-request.json'), request)
        write(safe(directory, 'workspace/artifacts/creative-request-binding.json'), dict(requestSHA256=request_hash))
        safe(directory, 'workspace/CREATIVE_TASK.md').write_text(
            '# App 创作请求\n\n按 private-photo-atelier 阶段技能完成 idea、scene_plan、assets、edit；使用原生 checkpoint/decision_log。\n'
            '此请求 externalSendAllowed=false，禁止调用托管模型或发送图片；不继承 phase6 云授权。\n'
            '只读当前 public 下已登记的规范化素材。不要访问图库或原图。事实以 artifacts/creative-request.json 为准。\n'
            '协议 1.1 必须保留 shots 的全部成员和当前顺序，日期未知不得推断，锁定编辑继续保留。\n'
            '先读意图和用户约束，再作导演判断。返回 editable-story-v1 的 plan.json；此 profile 尚不支持任意 Atelier 视觉脚本。\n'
            '不得以模板拼装宣称自动创作。超出 profile 的方案请报告 UNSUPPORTED_PROFILE，而不是删掉创意参数。\n'
            '每个已完成 checkpoint 的 metadata.creativeRequestSHA256 必须绑定本请求。原生阶段产物保留完整判断。\n'
            'App 应用并编辑后重新冻结 v0.1 包，交现有 Remotion 执行器。当前编辑 checkpoint 不代表成片或用户通过。\n', encoding='utf-8')
        write_checkpoint(directory, 'workspace', 'idea', 'in_progress', {}, pipeline_type='private-photo-atelier',
                         metadata=dict(creativeRequestSHA256=request_hash, planningMode='agent-assisted', externalSendAllowed=False))
        return dict(state='awaiting_agent', workspace=str(workspace), resumed=False)

def validate_plan(request: dict, request_hash: str, plan: dict) -> None:
    validate(plan, 'plan')
    if plan['requestID'] != request['requestID'] or plan['requestSHA256'] != request_hash:
        raise CreativeError('REQUEST_ID_MISMATCH')
    if plan['protocolVersion'] != request['protocolVersion']:
        raise CreativeError('PROTOCOL_VERSION_MISMATCH')
    source = {s['shotID']: s for s in request['shots']}
    facts = {f['assetID']: f for f in request['facts']}
    chapters = [c['chapterID'] for c in plan['chapters']]
    ids = [s['shotID'] for s in plan['shots']]
    if len(set(ids)) != len(ids) or len(set(chapters)) != len(chapters):
        raise CreativeError('DUPLICATE_ID')
    preserve_order = request["protocolVersion"] == "1.1"
    if preserve_order and ids != [s["shotID"] for s in request["shots"]]:
        raise CreativeError("USER_ORDER_CONFLICT")
    chronology = []
    visited = []
    for shot in plan['shots']:
        original = source.get(shot['shotID'])
        if not original or shot['assetID'] != original['assetID'] or shot['chapterID'] not in chapters:
            raise CreativeError('OUT_OF_SCOPE')
        fact = facts[shot['assetID']]
        if not preserve_order:
            if fact.get('captureTimeMs') is None:
                raise CreativeError('UNKNOWN_TIME')
            chronology.append(fact['captureTimeMs'])
        allowed = {shot['assetID'] + '.captureTimeMs'} if fact.get('captureTimeMs') is not None else set()
        if fact.get('placeName') is not None:
            allowed.add(shot['assetID'] + '.placeName')
        if not set(shot['factRefs']) <= allowed:
            raise CreativeError('UNSUPPORTED_FACT')
        if original['locked'] or original['userEdited']:
            if any(shot[k] != original[k] for k in ['caption', 'durationFrames', 'chapterID']):
                raise CreativeError('USER_CONSTRAINT_CONFLICT')
        if not visited or visited[-1] != shot['chapterID']:
            visited.append(shot['chapterID'])
    if chronology != sorted(chronology) or visited != chapters:
        raise CreativeError('TIMELINE_CONFLICT')
    if any(s['shotID'] not in ids for s in source.values() if s['locked'] or s['userEdited']):
        raise CreativeError('USER_CONSTRAINT_CONFLICT')

def complete(root: Path, request_id: str, plan_relative: str) -> dict:
    directory, request, request_hash, _ = load_request(root, request_id)
    with lock(directory):
        plan_path = safe(directory, 'workspace/' + plan_relative)
        plan = read(plan_path)
        validate_plan(request, request_hash, plan)
        for stage in ['idea', 'scene_plan', 'assets', 'edit']:
            checkpoint = read(safe(directory, f'workspace/checkpoint_{stage}.json'))
            validate_checkpoint(checkpoint)
            if (checkpoint['status'] != 'completed' or checkpoint.get('pipeline_type') != 'private-photo-atelier' or
                    checkpoint.get('metadata', {}).get('creativeRequestSHA256') != request_hash):
                raise CreativeError('AGENT_STAGE_INCOMPLETE')
        # Confirm input bytes again immediately before atomic publication.
        _, _, current_hash, _ = load_request(root, request_id)
        if current_hash != request_hash:
            raise CreativeError('REQUEST_CHANGED')
        plan_bytes = encode(plan)
        plan_hash = digest(plan_bytes)
        ready_path = safe(directory, 'ready.json')
        if ready_path.exists():
            if read(ready_path) != dict(requestSHA256=request_hash, planSHA256=plan_hash):
                raise CreativeError('RESULT_ALREADY_EXISTS')
            if digest(safe(directory, 'plan.json').read_bytes()) != plan_hash:
                raise CreativeError('PLAN_HASH_MISMATCH')
            return dict(state='ready', idempotent=True, planSHA256=plan_hash)
        write(safe(directory, 'plan.json'), plan)
        write(ready_path, dict(requestSHA256=request_hash, planSHA256=plan_hash))
        return dict(state='ready', idempotent=False, planSHA256=plan_hash)
