"""Deterministic file exchange for ImageAll Atelier projects.

The Agent owns creative decisions and native pipeline checkpoints. This module
only validates a bounded request, freezes its complete local project, and
renders an immutable revision through the registered VideoCompose tool.
"""
from __future__ import annotations

import hashlib
import fcntl
import json
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

import jsonschema

from lib.checkpoint import init_project, validate_checkpoint, write_checkpoint

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = json.loads((ROOT / "schemas/integrations/atelier_project_v1.schema.json").read_text())
PROFILE = "atelier-project-v1"
VERSION = "2.1"
ALLOWED_SUFFIXES = {".ts", ".tsx", ".js", ".jsx", ".css", ".json", ".md", ".jpg", ".jpeg", ".png", ".webp", ".woff", ".woff2", ".ttf", ".otf"}
RENDER_IMPORTS = {"react", "remotion", "@remotion/transitions"}


class AtelierExchangeError(ValueError):
    pass


def canonical(value: dict) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode()


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _document(value: dict, kind: str) -> None:
    try:
        jsonschema.validate(value, {"$defs": SCHEMA["$defs"], **SCHEMA["$defs"][kind]})
    except jsonschema.ValidationError as exc:
        raise AtelierExchangeError("INVALID_" + kind.upper()) from exc


def _read(path: Path) -> dict:
    if path.is_symlink() or not path.is_file() or path.stat().st_size > 2_000_000:
        raise AtelierExchangeError("MISSING_OR_UNSAFE_DOCUMENT")
    value = json.loads(path.read_bytes())
    if not isinstance(value, dict):
        raise AtelierExchangeError("INVALID_DOCUMENT")
    return value


def _write_once(path: Path, value: dict) -> None:
    data = canonical(value)
    if path.exists():
        if path.is_symlink() or path.read_bytes() != data:
            raise AtelierExchangeError("IMMUTABLE_RESULT_CONFLICT")
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(prefix=".exchange-", dir=path.parent, delete=False) as stream:
        stream.write(data)
        temp = Path(stream.name)
    try:
        os.link(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def safe(base: Path, relative: str) -> Path:
    if not relative or "\\" in relative or Path(relative).is_absolute() or any(p in {".", "..", ""} for p in relative.split("/")):
        raise AtelierExchangeError("UNSAFE_PATH")
    if base.is_symlink() or base.resolve() != base.absolute():
        raise AtelierExchangeError("UNSAFE_ROOT")
    path = base
    for part in relative.split("/"):
        path = path / part
        if path.is_symlink():
            raise AtelierExchangeError("UNSAFE_PATH")
    if not path.resolve().is_relative_to(base.resolve()):
        raise AtelierExchangeError("UNSAFE_PATH")
    return path


def request_dir(task_root: Path, request_id: str) -> Path:
    if not re.fullmatch(r"atelier-[a-f0-9-]{36}", request_id):
        raise AtelierExchangeError("INVALID_REQUEST_ID")
    return safe(task_root, "creative/atelier-requests/" + request_id)


def scope_digest(assets: list[dict]) -> str:
    lines = [f"{a['assetID']}|{a['contentVersion']}|{a['sha256']}\n" for a in sorted(assets, key=lambda x: x["assetID"])]
    return sha("".join(lines).encode())


def capabilities(task_root: Path) -> dict:
    value = dict(protocolVersion=VERSION, profile=PROFILE, pluginID="openmontage",
                 pluginVersion="2.1.0", planningMode="agent-assisted",
                 automaticPlanning=False, renderRuntime="remotion", compositionMode="atelier")
    _document(value, "capabilities")
    # Capability advertisements are mutable; requests and results remain immutable.
    from lib.story_creative_plugin import write
    write(safe(task_root, "creative/atelier-capabilities.json"), value)
    return value


def load_request(task_root: Path, request_id: str) -> tuple[Path, dict, str]:
    directory = request_dir(task_root, request_id)
    if safe(directory, "cancel.json").exists():
        raise AtelierExchangeError("CANCELLED")
    request_path = safe(directory, "request.json")
    request = _read(request_path)
    _document(request, "request")
    request_hash = file_sha(request_path)
    if request["requestID"] != request_id or _read(safe(directory, "complete.json")) != {"requestSHA256": request_hash}:
        raise AtelierExchangeError("REQUEST_HASH_MISMATCH")
    assets = request["assets"]
    if request["protocolVersion"] == "2.0" and len(assets) > 26:
        raise AtelierExchangeError("INVALID_REQUEST")
    ids = [a["assetID"] for a in assets]
    if len(set(ids)) != len(ids) or scope_digest(assets) != request["scopeDigestSHA256"]:
        raise AtelierExchangeError("SCOPE_MISMATCH")
    ids = set(ids)
    if request["protocolVersion"] == "2.1" and set(request["selectedAssetIDs"]) != ids:
        raise AtelierExchangeError("SCOPE_MISMATCH")
    for key in ("selectedAssetIDs", "lockedAssetIDs", "excludedAssetIDs"):
        if not set(request[key]) <= ids:
            raise AtelierExchangeError("OUT_OF_SCOPE")
    if set(request["lockedAssetIDs"]) & set(request["excludedAssetIDs"]):
        raise AtelierExchangeError("USER_CONSTRAINT_CONFLICT")
    locked = request["lockedShots"]
    if (len({s["assetID"] for s in locked}) != len(locked) or
            {s["assetID"] for s in locked} != set(request["lockedAssetIDs"]) or
            any(s["orderIndex"] >= len(request["selectedAssetIDs"]) or
                request["selectedAssetIDs"][s["orderIndex"]] != s["assetID"] for s in locked)):
        raise AtelierExchangeError("USER_CONSTRAINT_CONFLICT")
    for asset in assets:
        file = safe(directory, asset["relativePath"])
        if not file.is_file() or file_sha(file) != asset["sha256"]:
            raise AtelierExchangeError("SOURCE_CHANGED")
    return directory, request, request_hash


def prepare(task_root: Path, request_id: str) -> dict:
    directory, request, request_hash = load_request(task_root, request_id)
    workspace = safe(directory, "workspace")
    binding = safe(directory, "workspace/artifacts/atelier-request-binding.json")
    if binding.exists():
        if _read(binding).get("requestSHA256") != request_hash:
            raise AtelierExchangeError("REQUEST_CHANGED")
        _verify_workspace_assets(workspace, request)
        return {"state": "awaiting_agent", "workspace": str(workspace), "resumed": True}
    workspace = init_project("workspace", title=request["subject"], pipeline_type="private-photo-atelier", pipeline_dir=directory)
    public = safe(workspace, "public/assets")
    public.mkdir(parents=True, exist_ok=True)
    inventory = []
    for asset in request["assets"]:
        source = safe(directory, asset["relativePath"])
        target = safe(workspace, "public/" + asset["relativePath"])
        shutil.copyfile(source, target)
        if file_sha(target) != asset["sha256"]:
            raise AtelierExchangeError("COPY_HASH_MISMATCH")
        inventory.append(dict(id=asset["assetID"], type="image", path="public/" + asset["relativePath"],
                              source_tool="imageall-export", scene_id="bounded-candidate", sha256=asset["sha256"],
                              source_content_version=asset["contentVersion"]))
    (workspace / "artifacts/asset_manifest.json").write_bytes(canonical({"version": "1.0", "assets": inventory}))
    (workspace / "artifacts/atelier-request.json").write_bytes(canonical(request))
    binding.parent.mkdir(parents=True, exist_ok=True)
    binding.write_bytes(canonical({"requestSHA256": request_hash}))
    (workspace / "CREATIVE_TASK.md").write_text(
        "# ImageAll Atelier request\n\nRead artifacts/atelier-request.json and private-photo-atelier stage directors. "
        "Use only public/assets, honor locks/exclusions, and complete real idea, scene_plan, assets, edit checkpoints. "
        "The Agent authors index.tsx, local dependencies, props.json, art-direction.md and edit decisions. "
        "No external image send is authorized by this request; current Codex visual review has separate, bounded consent. "
        "Do not use another provider. Submit a complete frozen project through atelier_exchange freeze.\n", encoding="utf-8")
    write_checkpoint(directory, "workspace", "idea", "in_progress", {}, pipeline_type="private-photo-atelier",
                     metadata={"creativeRequestSHA256": request_hash, "planningMode": "agent-assisted"})
    return {"state": "awaiting_agent", "workspace": str(workspace), "resumed": False}


def _verify_workspace_assets(workspace: Path, request: dict) -> None:
    public = safe(workspace, "public/assets")
    expected = {"public/" + asset["relativePath"]: asset["sha256"] for asset in request["assets"]}
    actual = set()
    if not public.is_dir() or public.is_symlink():
        raise AtelierExchangeError("SOURCE_CHANGED")
    for path in public.rglob("*"):
        if path.is_symlink() or not path.is_file():
            raise AtelierExchangeError("UNSAFE_PATH")
        actual.add(path.relative_to(workspace).as_posix())
    if actual != set(expected):
        raise AtelierExchangeError("UNLISTED_OR_MISSING_ASSET")
    for relative, digest in expected.items():
        if file_sha(safe(workspace, relative)) != digest:
            raise AtelierExchangeError("SOURCE_CHANGED")
    manifest = _read(safe(workspace, "artifacts/asset_manifest.json"))
    listed = {item.get("path"): item for item in manifest.get("assets", [])}
    if len(listed) != len(expected) or set(listed) != set(expected):
        raise AtelierExchangeError("ASSET_MANIFEST_MISMATCH")
    for asset in request["assets"]:
        row = listed["public/" + asset["relativePath"]]
        if (row.get("id"), row.get("sha256"), row.get("source_content_version")) != (
                asset["assetID"], asset["sha256"], asset["contentVersion"]):
            raise AtelierExchangeError("ASSET_MANIFEST_MISMATCH")


def _files(project: Path) -> list[dict]:
    files = []
    for path in sorted(project.rglob("*")):
        relative = path.relative_to(project).as_posix()
        if path.is_symlink():
            raise AtelierExchangeError("SYMLINK_IN_PROJECT")
        if path.is_dir():
            if relative.split("/")[0] == "node_modules":
                raise AtelierExchangeError("UNSUPPORTED_PROJECT_DIRECTORY")
            if relative == "renders" and any(path.iterdir()):
                raise AtelierExchangeError("UNFROZEN_RENDER_IN_PROJECT")
            continue
        if path.suffix.lower() not in ALLOWED_SUFFIXES or path.stat().st_size > 100_000_000:
            raise AtelierExchangeError("UNSUPPORTED_PROJECT_FILE")
        if path.suffix.lower() in {".ts", ".tsx", ".js", ".jsx", ".css"}:
            content = path.read_text(encoding="utf-8")
            if re.search(r"https?://|file://|\brequire\s*\(|\bimport\s*\(|\bfetch\s*\(|\bXMLHttpRequest\b|\bWebSocket\b", content):
                raise AtelierExchangeError("REMOTE_OR_DYNAMIC_RESOURCE")
            if path.suffix.lower() == ".css" and re.search(r"@import\b|url\s*\(", content):
                raise AtelierExchangeError("UNLISTED_CSS_RESOURCE")
            modules = re.findall(r"\bfrom\s*['\"]([^'\"]+)['\"]", content)
            modules += re.findall(r"\bimport\s*['\"]([^'\"]+)['\"]", content)
            for module in modules:
                if module.startswith("."):
                    base = path.parent
                    if not any((base / (module + ext)).is_file() for ext in ("", ".ts", ".tsx", ".js", ".jsx", ".css")):
                        raise AtelierExchangeError("MISSING_LOCAL_IMPORT")
                elif module not in RENDER_IMPORTS:
                    raise AtelierExchangeError("UNSUPPORTED_IMPORT")
        files.append({"path": relative, "sizeBytes": path.stat().st_size, "sha256": file_sha(path)})
    return files


def freeze(task_root: Path, request_id: str, summary: dict) -> dict:
    directory, request, request_hash = load_request(task_root, request_id)
    workspace = safe(directory, "workspace")
    if _read(safe(workspace, "artifacts/atelier-request-binding.json"))["requestSHA256"] != request_hash:
        raise AtelierExchangeError("REQUEST_CHANGED")
    _verify_workspace_assets(workspace, request)
    for stage in ("idea", "scene_plan", "assets", "edit"):
        checkpoint = _read(safe(workspace, f"checkpoint_{stage}.json"))
        validate_checkpoint(checkpoint)
        if checkpoint["status"] != "completed" or checkpoint.get("metadata", {}).get("creativeRequestSHA256") != request_hash:
            raise AtelierExchangeError("AGENT_STAGE_INCOMPLETE")
    entry = summary["entryPoint"]
    props = summary["propsPath"]
    if not entry.endswith(".tsx") or not props.endswith(".json"):
        raise AtelierExchangeError("INVALID_RENDER_ENTRY")
    for required in (entry, props, "art-direction.md", "project.json", "artifacts/asset_manifest.json", "artifacts/brief.json", "artifacts/scene_plan.json", "artifacts/edit_decisions.json"):
        if not safe(workspace, required).is_file():
            raise AtelierExchangeError("INCOMPLETE_PROJECT")
    props_doc = _read(safe(workspace, props))
    if (props_doc.get("fps"), props_doc.get("width"), props_doc.get("height"), props_doc.get("totalFrames")) != (30, 1080, 1920, summary["totalFrames"]):
        raise AtelierExchangeError("INVALID_RENDER_SPEC")
    source_ids = {a["assetID"] for a in request["assets"]}
    used = set()
    ordered_assets = []
    seen_locked = []
    cursor = 0
    for shot in props_doc.get("shots", []):
        ids = shot.get("assetIDs", [])
        if not isinstance(ids, list) or not ids or len(ids) != len(set(ids)) or not set(ids) <= source_ids:
            raise AtelierExchangeError("OUT_OF_SCOPE")
        if (shot.get("startFrame") != cursor or not isinstance(shot.get("durationFrames"), int) or
                shot["durationFrames"] < 1 or shot.get("layout") not in {"single", "pair"} or
                len(ids) != (2 if shot["layout"] == "pair" else 1)):
            raise AtelierExchangeError("INVALID_TIMELINE")
        cursor += shot["durationFrames"]
        used.update(ids)
        ordered_assets.extend(ids)
        for locked_shot in request["lockedShots"]:
            if locked_shot["assetID"] in ids:
                if (shot.get("caption", "") != locked_shot["caption"] or
                        shot["durationFrames"] != locked_shot["durationFrames"] or
                        locked_shot["assetID"] in seen_locked):
                    raise AtelierExchangeError("USER_CONSTRAINT_CONFLICT")
                seen_locked.append(locked_shot["assetID"])
    if request["protocolVersion"] == "2.1" and ordered_assets != request["selectedAssetIDs"]:
        raise AtelierExchangeError("USER_ORDER_CONFLICT")
    if cursor != props_doc["totalFrames"]:
        raise AtelierExchangeError("INVALID_TIMELINE")
    if not set(request["lockedAssetIDs"]) <= used or used & set(request["excludedAssetIDs"]):
        raise AtelierExchangeError("USER_CONSTRAINT_CONFLICT")
    expected_locked_order = [s["assetID"] for s in sorted(request["lockedShots"], key=lambda x: x["orderIndex"])]
    if seen_locked != expected_locked_order:
        raise AtelierExchangeError("USER_CONSTRAINT_CONFLICT")
    if not 300 <= summary["totalFrames"] <= 5400:
        raise AtelierExchangeError("INVALID_RENDER_SPEC")
    runtime_lock = ROOT / "remotion-composer/package-lock.json"
    if not runtime_lock.is_file():
        raise AtelierExchangeError("MISSING_RUNTIME_LOCK")
    runtime_version = _read(runtime_lock)["packages"]["node_modules/remotion"]["version"]
    if summary["runtimeVersion"] != runtime_version:
        raise AtelierExchangeError("RUNTIME_VERSION_MISMATCH")
    frozen_lock = workspace / "runtime-package-lock.json"
    if not frozen_lock.exists():
        shutil.copyfile(runtime_lock, frozen_lock)
    elif file_sha(frozen_lock) != file_sha(runtime_lock):
        raise AtelierExchangeError("RUNTIME_CHANGED")
    files = _files(workspace)
    manifest_data = canonical({"files": files})
    revision = sha(manifest_data)
    proposed = dict(protocolVersion=request["protocolVersion"], profile=PROFILE, requestID=request_id,
                    requestSHA256=request_hash, scopeDigestSHA256=request["scopeDigestSHA256"],
                    projectRevision=revision, manifestSHA256=revision, entryPoint=entry,
                    propsPath=props, compositionID=summary["compositionID"], renderRuntime="remotion",
                    runtimeVersion=summary["runtimeVersion"], width=1080, height=1920,
                    fps=30, totalFrames=summary["totalFrames"], title=summary["title"],
                    summary=summary["summary"], files=files)
    _document(proposed, "proposal")
    revisions = safe(directory, "revisions")
    revisions.mkdir(exist_ok=True)
    destination = safe(directory, "revisions/" + revision)
    if destination.exists():
        verify_revision(directory, proposed)
    else:
        staging = revisions / ("." + revision + ".pending")
        if staging.exists():
            raise AtelierExchangeError("FROZEN_STAGE_CONFLICT")
        staging.mkdir()
        try:
            for item in files:
                target = safe(staging, item["path"])
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(safe(workspace, item["path"]), target)
            if _files(staging) != files:
                raise AtelierExchangeError("FROZEN_COPY_CHANGED")
            staging.rename(destination)
        except Exception:
            shutil.rmtree(staging)
            raise
    _write_once(safe(directory, "proposal.json"), proposed)
    _write_once(safe(directory, "ready.json"), {"requestSHA256": request_hash, "proposalSHA256": file_sha(safe(directory, "proposal.json"))})
    return proposed


def verify_revision(directory: Path, proposal: dict) -> Path:
    _document(proposal, "proposal")
    revision = safe(directory, "revisions/" + proposal["projectRevision"])
    if not revision.is_dir() or _files(revision) != proposal["files"]:
        raise AtelierExchangeError("FROZEN_PROJECT_CHANGED")
    if sha(canonical({"files": proposal["files"]})) != proposal["manifestSHA256"] or proposal["projectRevision"] != proposal["manifestSHA256"]:
        raise AtelierExchangeError("MANIFEST_HASH_MISMATCH")
    return revision


def _private_render_workspace(directory: Path, revision: Path, proposal: dict) -> Path:
    """Resolve Remotion modules without copying private source into the checkout."""
    runtime = safe(directory, "render-workspaces/" + proposal["projectRevision"])
    runtime.mkdir(parents=True, exist_ok=True)
    expected = {item["path"]: item["sha256"] for item in proposal["files"]
                if Path(item["path"]).suffix.lower() in {".ts", ".tsx", ".js", ".jsx", ".css"}}
    for relative, digest in expected.items():
        target = safe(runtime, relative)
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            shutil.copyfile(safe(revision, relative), target)
        if file_sha(target) != digest:
            raise AtelierExchangeError("RUNTIME_SOURCE_CHANGED")
    found = {path.relative_to(runtime).as_posix() for path in runtime.rglob("*")
             if path.is_file() and not path.is_symlink()}
    if any(path.is_symlink() and path != runtime / "node_modules" for path in runtime.rglob("*")):
        raise AtelierExchangeError("UNLISTED_RUNTIME_SYMLINK")
    if found != set(expected):
        raise AtelierExchangeError("UNLISTED_RUNTIME_SOURCE")
    modules = runtime / "node_modules"
    trusted = ROOT / "remotion-composer/node_modules"
    if not modules.exists() and not modules.is_symlink():
        modules.symlink_to(trusted, target_is_directory=True)
    if not modules.is_symlink() or modules.resolve() != trusted.resolve():
        raise AtelierExchangeError("RUNTIME_MODULES_CHANGED")
    return runtime


def _verified_media(output: Path, proposal: dict) -> int:
    try:
        probe = subprocess.run(["ffprobe", "-v", "error", "-count_frames", "-show_entries",
                                "stream=codec_type,width,height,r_frame_rate,nb_read_frames", "-of", "json", str(output)],
                               capture_output=True, text=True, check=True)
        streams = json.loads(probe.stdout)["streams"]
        video = [stream for stream in streams if stream.get("codec_type") == "video"]
        if len(video) != 1 or any(stream.get("codec_type") == "audio" for stream in streams):
            raise AtelierExchangeError("MEDIA_SPEC_MISMATCH")
        stream = video[0]
        frames = int(stream["nb_read_frames"])
        if (stream["width"], stream["height"], stream["r_frame_rate"], frames) != (
                1080, 1920, "30/1", proposal["totalFrames"]):
            raise AtelierExchangeError("MEDIA_SPEC_MISMATCH")
        subprocess.run(["ffmpeg", "-v", "error", "-i", str(output), "-f", "null", "-"],
                       capture_output=True, check=True)
        return frames
    except (OSError, KeyError, ValueError, IndexError, subprocess.CalledProcessError) as exc:
        raise AtelierExchangeError("MEDIA_VERIFY_FAILED") from exc


def render(task_root: Path, request_id: str) -> dict:
    directory = request_dir(task_root, request_id)
    lock = safe(directory, ".render.lock")
    with lock.open("a+b") as stream:
        fcntl.flock(stream, fcntl.LOCK_EX)
        return _render_locked(task_root, request_id)


def _render_locked(task_root: Path, request_id: str) -> dict:
    from tools.video.video_compose import VideoCompose

    directory, request, request_hash = load_request(task_root, request_id)
    proposal = _read(safe(directory, "proposal.json"))
    if proposal["protocolVersion"] != request["protocolVersion"] or proposal["requestSHA256"] != request_hash or proposal["scopeDigestSHA256"] != request["scopeDigestSHA256"]:
        raise AtelierExchangeError("STALE_PROPOSAL")
    revision = verify_revision(directory, proposal)
    if file_sha(safe(revision, "runtime-package-lock.json")) != file_sha(ROOT / "remotion-composer/package-lock.json"):
        raise AtelierExchangeError("RUNTIME_CHANGED")
    installed = ROOT / "remotion-composer/node_modules/remotion/package.json"
    if not installed.is_file() or _read(installed).get("version") != proposal["runtimeVersion"]:
        raise AtelierExchangeError("RUNTIME_VERSION_MISMATCH")
    render_request = _read(safe(directory, "render-request.json"))
    if render_request != {"requestSHA256": request_hash, "projectRevision": proposal["projectRevision"]}:
        raise AtelierExchangeError("RENDER_REQUEST_MISMATCH")
    result_path = safe(directory, "result.json")
    if result_path.exists():
        result = _read(result_path)
        if result["status"] == "succeeded" and file_sha(safe(directory, result["outputPath"])) == result["outputSHA256"]:
            return result
        raise AtelierExchangeError("RESULT_ALREADY_EXISTS")
    output_rel = "renders/" + proposal["projectRevision"] + ".mp4"
    output = safe(directory, output_rel)
    output.parent.mkdir(exist_ok=True)
    runtime = _private_render_workspace(directory, revision, proposal)
    if output.exists():
        # A process may have stopped after creating the MP4 but before writing
        # result.json. Keep a complete render; discard only an incomplete one.
        try:
            _verified_media(output, proposal)
        except AtelierExchangeError:
            output.unlink()
    if not output.exists():
        edit = dict(version="1.0", render_runtime="remotion", composition_mode="atelier", renderer_family="photo-story",
                cuts=[{"id": "atelier", "source": request["assets"][0]["assetID"], "in_seconds": 0,
                       "out_seconds": proposal["totalFrames"] / 30, "reason": "frozen Atelier project"}],
                bespoke={"entry": str(safe(runtime, proposal["entryPoint"])),
                         "composition_id": proposal["compositionID"],
                         "props_path": str(safe(revision, proposal["propsPath"])),
                         "public_dir": str(safe(revision, "public")),
                         "art_direction": str(safe(revision, "art-direction.md")),
                         "private_runtime_dir": str(runtime), "crf": 18, "concurrency": 4},
                metadata={"scopeDigestSHA256": request["scopeDigestSHA256"],
                          "projectRevision": proposal["projectRevision"]})
        from schemas.artifacts import validate_artifact
        validate_artifact("edit_decisions", edit)
        tool_result = VideoCompose().execute({"operation": "render", "output_path": str(output), "edit_decisions": edit,
                                          "asset_manifest": _read(safe(revision, "artifacts/asset_manifest.json")), "mute_audio": True})
        _private_render_workspace(directory, revision, proposal)
    else:
        tool_result = None  # Crash recovery: the existing output was fully decoded above.
    verify_revision(directory, proposal)
    if safe(directory, "cancel.json").exists():
        output.unlink(missing_ok=True)
        status, error = "cancelled", "CANCELLED"
    elif tool_result is not None and not tool_result.success:
        output.unlink(missing_ok=True)
        status, error = "failed", "RENDER_FAILED"
    else:
        status, error = "succeeded", None
    frames = None
    if status == "succeeded":
        try:
            frames = _verified_media(output, proposal)
        except AtelierExchangeError as exc:
            output.unlink(missing_ok=True)
            status, error = "failed", str(exc)
    if safe(directory, "cancel.json").exists():
        output.unlink(missing_ok=True)
        status, error, frames = "cancelled", "CANCELLED", None
    result = dict(protocolVersion=request["protocolVersion"], requestID=request_id, requestSHA256=request_hash,
                  projectRevision=proposal["projectRevision"], manifestSHA256=proposal["manifestSHA256"],
                  status=status, outputPath=output_rel if status == "succeeded" else None,
                  outputSHA256=file_sha(output) if status == "succeeded" else None,
                  width=1080 if status == "succeeded" else None,
                  height=1920 if status == "succeeded" else None, fps=30 if status == "succeeded" else None,
                  frames=frames if status == "succeeded" else None, errorCode=error)
    _document(result, "result")
    _write_once(result_path, result)
    return result
