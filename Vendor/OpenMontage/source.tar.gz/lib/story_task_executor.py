"""Filesystem companion executor for ImageAll story-render tasks.

The executor is intentionally thin: it validates task-protocol v1, delegates
rendering and targeted cancellation to the existing trusted story_render CLI,
and publishes an idempotent task-level status/result contract.
"""

from __future__ import annotations

import fcntl
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any

from jsonschema import Draft202012Validator

from lib.story_render_adapter import validation_report


REPOSITORY_ROOT = Path(__file__).resolve().parent.parent
PROTOCOL_SCHEMA_PATH = (
    REPOSITORY_ROOT / "schemas/integrations/story_executor_task_protocol_v1.schema.json"
)
PROTOCOL_LOCK_PATH = (
    REPOSITORY_ROOT / "schemas/integrations/story_executor_task_protocol_v1.lock.json"
)
STORY_SCHEMA_PATH = REPOSITORY_ROOT / "schemas/integrations/story_render_package_v0_1.schema.json"
STORY_SCHEMA_LOCK_PATH = (
    REPOSITORY_ROOT / "schemas/integrations/story_render_package_v0_1.lock.json"
)
ADAPTER_SCRIPT = REPOSITORY_ROOT / "scripts/story_render.py"

PROTOCOL_VERSION = "1.1"
EXECUTOR_VERSION = "1.1.0"
EXECUTOR_NAME = "openmontage-story-executor"
TASK_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
TERMINAL_STATES = {"succeeded", "failed", "cancelled", "rejected", "interrupted"}
STAGE_ORDER = {
    "intake": 0,
    "validation": 1,
    "preparation": 2,
    "rendering": 3,
    "audio_processing": 4,
    "verification": 5,
    "publication": 6,
    "terminal": 7,
}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON document must be an object: {path.name}")
    return value


def _atomic_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    temporary.replace(path)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _schema_and_validator() -> tuple[dict[str, Any], Draft202012Validator]:
    schema = _read_json(PROTOCOL_SCHEMA_PATH)
    Draft202012Validator.check_schema(schema)
    return schema, Draft202012Validator(schema)


_PROTOCOL_SCHEMA, _PROTOCOL_VALIDATOR = _schema_and_validator()


def _validate_protocol_document(value: dict[str, Any], document_type: str) -> None:
    if value.get("documentType") != document_type:
        raise ProtocolError("PROTOCOL_UNSUPPORTED", f"expected {document_type}")
    errors = sorted(_PROTOCOL_VALIDATOR.iter_errors(value), key=lambda item: list(item.path))
    if errors:
        raise ProtocolError("PROTOCOL_UNSUPPORTED", errors[0].message)


def _safe_relative_path(base: Path, relative: str) -> Path:
    if not isinstance(relative, str) or not relative or "\\" in relative:
        raise ProtocolError("MANIFEST_PATH_UNSAFE", "manifest path is not POSIX-relative")
    pure = PurePosixPath(relative)
    if pure.is_absolute() or any(part in {"", ".", ".."} for part in pure.parts):
        raise ProtocolError("MANIFEST_PATH_UNSAFE", "manifest path escapes submission")
    candidate = base.joinpath(*pure.parts)
    try:
        candidate.resolve(strict=False).relative_to(base.resolve())
    except ValueError as exc:
        raise ProtocolError("MANIFEST_PATH_UNSAFE", "manifest path escapes submission") from exc
    return candidate


def _task_root_relative(task_root: Path, path: Path) -> str:
    try:
        return path.resolve().relative_to(task_root.resolve()).as_posix()
    except ValueError as exc:
        raise ProtocolError("RESULT_VERIFICATION_FAILED", "path is outside the task root") from exc


def _resolve_adapter_artifact(adapter_dir: Path, value: str) -> Path:
    """Resolve adapter run-relative, repository-relative, or absolute output paths.

    The adapter reports an absolute path when its run is outside this checkout.
    All accepted notations must still resolve to a regular file in this exact
    adapter run, including after symlink resolution.
    """
    if not isinstance(value, str) or not value or "\\" in value:
        raise ProtocolError("RESULT_VERIFICATION_FAILED", "adapter artifact path is invalid")
    pure = PurePosixPath(value)
    if any(part in {"", ".", ".."} for part in pure.parts):
        raise ProtocolError("RESULT_VERIFICATION_FAILED", "adapter artifact path is unsafe")
    candidates = (
        [Path(value)]
        if pure.is_absolute()
        else [adapter_dir.joinpath(*pure.parts), REPOSITORY_ROOT.joinpath(*pure.parts)]
    )
    for candidate in candidates:
        resolved = candidate.resolve(strict=False)
        try:
            resolved.relative_to(adapter_dir.resolve())
        except ValueError:
            continue
        if resolved.is_file():
            return resolved
    raise ProtocolError("RESULT_VERIFICATION_FAILED", "verified output is missing")


class ProtocolError(ValueError):
    def __init__(
        self,
        code: str,
        message: str,
        *,
        retryable: bool = False,
        details_code: str | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.retryable = retryable
        self.details_code = details_code


@dataclass(frozen=True)
class VerifiedSubmission:
    task_dir: Path
    submission_dir: Path
    state_dir: Path
    task: dict[str, Any]
    completion: dict[str, Any]
    submission_digest: str
    package_path: Path
    story_package_sha256: str

    @property
    def task_id(self) -> str:
        return str(self.task["taskID"])

    @property
    def project_id(self) -> str:
        return str(self.task["projectID"])

    @property
    def project_revision(self) -> str:
        return str(self.task["projectRevision"])


def _actual_submission_files(submission_dir: Path) -> dict[str, Path]:
    actual: dict[str, Path] = {}
    for current, directory_names, file_names in os.walk(submission_dir, followlinks=False):
        current_path = Path(current)
        for directory_name in directory_names:
            directory = current_path / directory_name
            if directory.is_symlink():
                raise ProtocolError("MANIFEST_PATH_UNSAFE", "submission contains a symlink directory")
        for file_name in file_names:
            path = current_path / file_name
            if path.name == "complete.json" and path.parent == submission_dir:
                continue
            if path.is_symlink() or not path.is_file():
                raise ProtocolError("MANIFEST_PATH_UNSAFE", "submission contains a non-regular file")
            relative = path.relative_to(submission_dir).as_posix()
            actual[relative] = path
    return actual


def verify_submission(task_dir: str | Path) -> VerifiedSubmission | None:
    """Verify one atomic submission, returning None while it is incomplete."""
    task_path = Path(task_dir).resolve()
    if not TASK_ID_PATTERN.fullmatch(task_path.name):
        raise ProtocolError("TASK_METADATA_INVALID", "task directory name is not a valid taskID")
    submission_dir = task_path / "submission"
    completion_path = submission_dir / "complete.json"
    if not completion_path.is_file():
        return None

    try:
        completion = _read_json(completion_path)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        raise ProtocolError("COMPLETION_INVALID", "complete.json is not valid JSON") from exc
    if completion.get("protocolVersion") != PROTOCOL_VERSION:
        raise ProtocolError("PROTOCOL_UNSUPPORTED", "completion protocolVersion is not 1.1")
    if completion.get("documentType") != "story-task-completion":
        raise ProtocolError("COMPLETION_INVALID", "completion documentType is invalid")
    if completion.get("taskID") != task_path.name:
        raise ProtocolError("TASK_METADATA_INVALID", "completion taskID does not match directory")

    raw_entries = completion.get("files")
    if not isinstance(raw_entries, list):
        raise ProtocolError("COMPLETION_INVALID", "completion files must be an array")
    for raw_entry in raw_entries:
        if not isinstance(raw_entry, dict) or not isinstance(raw_entry.get("path"), str):
            raise ProtocolError("COMPLETION_INVALID", "completion file entry is invalid")
        _safe_relative_path(submission_dir, raw_entry["path"])
    try:
        _validate_protocol_document(completion, "story-task-completion")
    except ProtocolError as exc:
        if exc.code == "PROTOCOL_UNSUPPORTED":
            raise ProtocolError("COMPLETION_INVALID", exc.message) from exc
        raise

    registered: dict[str, dict[str, Any]] = {}
    for entry in raw_entries:
        relative = entry["path"]
        if relative == "complete.json" or relative in registered:
            raise ProtocolError("COMPLETION_INVALID", "completion has duplicate or self entry")
        registered[relative] = entry
    actual = _actual_submission_files(submission_dir)
    missing = sorted(set(registered) - set(actual))
    extra = sorted(set(actual) - set(registered))
    if missing:
        raise ProtocolError("MANIFEST_FILE_MISSING", f"registered file is missing: {missing[0]}")
    if extra:
        raise ProtocolError("MANIFEST_EXTRA_FILE", f"submission has unregistered file: {extra[0]}")

    manifest_lines: list[str] = []
    for relative in sorted(registered):
        entry = registered[relative]
        path = actual[relative]
        if path.stat().st_size != entry["sizeBytes"]:
            raise ProtocolError("MANIFEST_SIZE_MISMATCH", f"size mismatch: {relative}")
        digest = _sha256(path)
        if digest != entry["sha256"]:
            raise ProtocolError("MANIFEST_HASH_MISMATCH", f"hash mismatch: {relative}")
        manifest_lines.append(f"{digest}  {entry['sizeBytes']}  {relative}\n")
    manifest_digest = hashlib.sha256("".join(manifest_lines).encode("utf-8")).hexdigest()
    if manifest_digest != completion["manifestSHA256"]:
        raise ProtocolError("MANIFEST_DIGEST_MISMATCH", "completion manifest hash is invalid")

    task_json_path = submission_dir / "task.json"
    if "task.json" not in registered or not task_json_path.is_file():
        raise ProtocolError("TASK_METADATA_INVALID", "task.json is not registered")
    try:
        task = _read_json(task_json_path)
        _validate_protocol_document(task, "story-task")
    except ProtocolError as exc:
        raise ProtocolError("TASK_METADATA_INVALID", exc.message) from exc
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        raise ProtocolError("TASK_METADATA_INVALID", "task.json is not valid JSON") from exc
    if task["taskID"] != task_path.name:
        raise ProtocolError("TASK_METADATA_INVALID", "taskID does not match directory")
    if completion["producer"] != task["submittedBy"]:
        raise ProtocolError("TASK_METADATA_INVALID", "completion producer does not match task submitter")
    if (
        completion["projectID"] != task["projectID"]
        or completion["projectRevision"] != task["projectRevision"]
    ):
        raise ProtocolError("TASK_METADATA_INVALID", "completion project identity does not match task")
    if completion["storyPackage"] != task["storyPackage"]:
        raise ProtocolError("TASK_METADATA_INVALID", "completion storyPackage does not match task")

    advertised_schema_hash = task["storyPackage"]["schemaSHA256"]
    actual_schema_hash = _sha256(STORY_SCHEMA_PATH)
    if task["storyPackage"]["schemaVersion"] != "0.1":
        raise ProtocolError("STORY_SCHEMA_UNSUPPORTED", "only StoryRenderPackage 0.1 is supported")
    if advertised_schema_hash != actual_schema_hash:
        raise ProtocolError("STORY_SCHEMA_HASH_MISMATCH", "Story Schema hash does not match executor")

    entrypoint = task["storyPackage"]["entrypoint"]
    if entrypoint not in registered:
        raise ProtocolError("TASK_METADATA_INVALID", "story entrypoint is not registered")
    package_path = _safe_relative_path(submission_dir, entrypoint)
    try:
        story = _read_json(package_path)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        raise ProtocolError("STORY_PACKAGE_INVALID", "story entrypoint is not valid JSON") from exc
    if story.get("schemaVersion") != "0.1":
        raise ProtocolError("STORY_SCHEMA_UNSUPPORTED", "story package schemaVersion is not 0.1")
    if story.get("projectID") != task["projectID"] or story.get("projectRevision") != task["projectRevision"]:
        raise ProtocolError("TASK_METADATA_INVALID", "task project identity does not match story package")

    return VerifiedSubmission(
        task_dir=task_path,
        submission_dir=submission_dir,
        state_dir=task_path / "state",
        task=task,
        completion=completion,
        submission_digest=manifest_digest,
        package_path=package_path,
        story_package_sha256=_sha256(package_path),
    )


def readiness_report(task_root: str | Path | None = None) -> dict[str, Any]:
    checks: list[dict[str, Any]] = []

    def add(name: str, ready: bool, detail: str, install_hint: str | None = None) -> None:
        checks.append(
            {"name": name, "ready": ready, "detail": detail, "installHint": install_hint}
        )

    protocol_lock = _read_json(PROTOCOL_LOCK_PATH)
    protocol_hash = _sha256(PROTOCOL_SCHEMA_PATH)
    add(
        "task_protocol_schema",
        protocol_hash == protocol_lock["sha256"],
        f"v{PROTOCOL_VERSION} sha256:{protocol_hash}",
        None
        if protocol_hash == protocol_lock["sha256"]
        else "Restore the checked-in task protocol v1 Schema and lock file.",
    )
    story_lock = _read_json(STORY_SCHEMA_LOCK_PATH)
    story_hash = _sha256(STORY_SCHEMA_PATH)
    add(
        "story_package_schema",
        story_hash == story_lock["sha256"],
        f"v0.1 sha256:{story_hash}",
        None
        if story_hash == story_lock["sha256"]
        else "Restore the frozen StoryRenderPackage v0.1 Schema bytes.",
    )
    for command in ("ffmpeg", "ffprobe", "node"):
        location = shutil.which(command)
        add(
            command,
            bool(location),
            location or "not found",
            f"Install {command} before starting the executor." if not location else None,
        )
    remotion_package = REPOSITORY_ROOT / "remotion-composer/node_modules/remotion/package.json"
    if remotion_package.is_file():
        try:
            remotion_version = _read_json(remotion_package).get("version", "unknown")
            remotion_ready = True
        except (ValueError, json.JSONDecodeError):
            remotion_version = "invalid package metadata"
            remotion_ready = False
    else:
        remotion_version = "not installed"
        remotion_ready = False
    add(
        "remotion",
        remotion_ready,
        str(remotion_version),
        None
        if remotion_ready
        else "Run `cd remotion-composer && npm ci` outside task processing; the executor never installs dependencies.",
    )
    add(
        "story_render_adapter",
        ADAPTER_SCRIPT.is_file(),
        str(ADAPTER_SCRIPT),
        None
        if ADAPTER_SCRIPT.is_file()
        else "Restore scripts/story_render.py from the trusted OpenMontage checkout.",
    )
    if task_root is not None:
        root = Path(task_root).resolve()
        parent = root if root.exists() else root.parent
        add(
            "task_root",
            parent.exists() and os.access(parent, os.W_OK),
            str(root),
            None
            if parent.exists() and os.access(parent, os.W_OK)
            else "Choose an explicit local task root whose existing parent is writable.",
        )
    return {
        "protocolVersion": PROTOCOL_VERSION,
        "executorVersion": EXECUTOR_VERSION,
        "ready": all(item["ready"] for item in checks),
        "checks": checks,
    }


class StoryRenderAdapterBackend:
    """Trusted adapter CLI boundary used by the companion executor."""

    def launch(self, package_path: Path, output_root: Path, task_id: str) -> dict[str, Any]:
        output_root.mkdir(parents=True, exist_ok=True)
        command = [
            sys.executable,
            str(ADAPTER_SCRIPT),
            "render",
            str(package_path),
            "--run-suffix",
            task_id,
            "--output-root",
            str(output_root),
            "--detach",
        ]
        result = subprocess.run(
            command,
            cwd=REPOSITORY_ROOT,
            capture_output=True,
            text=True,
            timeout=180,
            check=False,
        )
        documents: list[dict[str, Any]] = []
        for line in result.stdout.splitlines():
            try:
                value = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict):
                documents.append(value)
        if result.returncode != 0:
            failure = next((item for item in reversed(documents) if item.get("code")), {})
            code = str(failure.get("code") or "PREPARATION_FAILED")
            raise ProtocolError(code, f"story adapter launch failed with exit {result.returncode}")
        prepared = next((item for item in documents if item.get("event") == "prepared"), None)
        started = next((item for item in documents if item.get("event") == "started"), None)
        if not prepared or not started:
            raise ProtocolError("PREPARATION_FAILED", "story adapter did not report prepared and started")
        adapter_dir = Path(str(prepared["projectDir"])).resolve()
        try:
            adapter_dir.relative_to(output_root.resolve())
        except ValueError as exc:
            raise ProtocolError("PREPARATION_FAILED", "adapter run escaped its output root") from exc
        return {
            "adapterProjectID": prepared["projectID"],
            "adapterProjectDir": str(adapter_dir),
            "workerPID": int(started["pid"]),
        }

    def cancel(self, adapter_dir: Path, output_root: Path) -> tuple[bool, str]:
        result = subprocess.run(
            [
                sys.executable,
                str(ADAPTER_SCRIPT),
                "cancel",
                str(adapter_dir),
                "--output-root",
                str(output_root),
            ],
            cwd=REPOSITORY_ROOT,
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
        payload: dict[str, Any] = {}
        for line in result.stdout.splitlines():
            try:
                candidate = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(candidate, dict):
                payload = candidate
        return result.returncode == 0 and payload.get("success") is True, str(
            payload.get("code") or payload.get("state") or "CANCEL_TARGET_UNCONFIRMED"
        )

    def status(self, adapter_dir: Path) -> dict[str, Any] | None:
        status_path = adapter_dir / "status.json"
        if not status_path.is_file():
            return None
        try:
            return _read_json(status_path)
        except (OSError, ValueError, json.JSONDecodeError):
            return None

    def worker_running(self, adapter_dir: Path) -> bool:
        worker_path = adapter_dir / "control/worker.json"
        if not worker_path.is_file():
            return False
        try:
            worker = _read_json(worker_path)
            pid = int(worker["pid"])
        except (OSError, ValueError, KeyError, json.JSONDecodeError):
            return False
        check = subprocess.run(
            ["ps", "-p", str(pid), "-o", "command="],
            capture_output=True,
            text=True,
            check=False,
        )
        return (
            check.returncode == 0
            and "story_render.py _worker" in check.stdout
            and str(adapter_dir.resolve()) in check.stdout
        )


class StoryTaskExecutor:
    def __init__(
        self,
        task_root: str | Path,
        *,
        backend: StoryRenderAdapterBackend | None = None,
        readiness: dict[str, Any] | None = None,
    ) -> None:
        self.task_root = Path(task_root).resolve()
        self.executor_dir = self.task_root / "executor"
        self.tasks_dir = self.task_root / "tasks"
        self.runs_dir = self.task_root / "runs"
        self.backend = backend or StoryRenderAdapterBackend()
        self.readiness = readiness or readiness_report(self.task_root)
        self.instance_id = ""

    def ensure_layout(self) -> None:
        self.executor_dir.mkdir(parents=True, exist_ok=True)
        self.tasks_dir.mkdir(parents=True, exist_ok=True)
        self.runs_dir.mkdir(parents=True, exist_ok=True)
        instance_path = self.executor_dir / "instance.json"
        write_instance = False
        if instance_path.is_file():
            try:
                instance_id = str(_read_json(instance_path)["instanceID"])
            except (OSError, ValueError, KeyError, json.JSONDecodeError):
                instance_id = uuid.uuid4().hex
                write_instance = True
        else:
            instance_id = uuid.uuid4().hex
            write_instance = True
        self.instance_id = instance_id
        if write_instance:
            _atomic_json(instance_path, {"instanceID": instance_id, "createdAt": _utc_now()})
        self.publish_capabilities()

    def publish_capabilities(self) -> dict[str, Any]:
        if not self.instance_id:
            instance_path = self.executor_dir / "instance.json"
            self.instance_id = (
                str(_read_json(instance_path)["instanceID"])
                if instance_path.is_file()
                else uuid.uuid4().hex
            )
        capabilities = {
            "documentType": "story-executor-capabilities",
            "protocolVersion": PROTOCOL_VERSION,
            "executorName": EXECUTOR_NAME,
            "executorVersion": EXECUTOR_VERSION,
            "instanceID": self.instance_id,
            "taskProtocolSchemaSHA256": _sha256(PROTOCOL_SCHEMA_PATH),
            "storyPackageSchemas": [{"version": "0.1", "sha256": _sha256(STORY_SCHEMA_PATH)}],
            "taskTypes": ["story-render"],
            "maxConcurrentTasks": 1,
            "features": {
                "cancellation": True,
                "restartRecovery": True,
                "atomicResultPublication": True,
                "remoteAPI": False,
            },
            "readiness": {
                "ready": bool(self.readiness["ready"]),
                "checks": self.readiness["checks"],
            },
            "generatedAt": _utc_now(),
        }
        _validate_protocol_document(capabilities, "story-executor-capabilities")
        _atomic_json(self.executor_dir / "capabilities.json", capabilities)
        return capabilities

    def _task_dirs(self) -> list[Path]:
        if not self.tasks_dir.is_dir():
            return []
        return sorted(
            (path for path in self.tasks_dir.iterdir() if path.is_dir()),
            key=lambda path: path.name,
        )

    def _last_event(self, task_dir: Path) -> dict[str, Any] | None:
        events_path = task_dir / "state/events.jsonl"
        if not events_path.is_file():
            return None
        last: dict[str, Any] | None = None
        for line in events_path.read_text(encoding="utf-8").splitlines():
            try:
                value = json.loads(line)
            except json.JSONDecodeError:
                continue
            if (
                isinstance(value, dict)
                and value.get("documentType") == "story-task-event"
                and isinstance(value.get("eventSequence"), int)
                and (last is None or value["eventSequence"] > last["eventSequence"])
            ):
                last = value
        return last

    def current_status(self, task_dir: Path) -> dict[str, Any] | None:
        status_path = task_dir / "state/status.json"
        status: dict[str, Any] | None = None
        if status_path.is_file():
            try:
                candidate = _read_json(status_path)
                if candidate.get("documentType") == "story-task-status":
                    status = candidate
            except (OSError, ValueError, json.JSONDecodeError):
                pass
        event = self._last_event(task_dir)
        if event and (status is None or event["eventSequence"] > status.get("eventSequence", 0)):
            status = {**event, "documentType": "story-task-status"}
            _validate_protocol_document(status, "story-task-status")
            _atomic_json(status_path, status)
        return status

    def _transition(
        self,
        submission: VerifiedSubmission,
        *,
        state: str,
        stage: str,
        progress: float,
        error: ProtocolError | None = None,
    ) -> dict[str, Any]:
        current = self.current_status(submission.task_dir)
        if current and current["state"] in TERMINAL_STATES:
            return current
        error_value = None
        if error:
            error_value = {
                "code": error.code,
                "stage": stage,
                "message": error.message.replace(str(self.task_root), "<task-root>"),
                "retryable": error.retryable,
            }
            if error.details_code:
                error_value["detailsCode"] = error.details_code
        terminal = state in TERMINAL_STATES
        effective_stage = "terminal" if terminal else stage
        effective_progress = round(max(0, min(1, progress)), 3)
        if current and not terminal and current["state"] not in TERMINAL_STATES:
            effective_progress = max(effective_progress, float(current["progress"]))
            if STAGE_ORDER.get(effective_stage, 0) < STAGE_ORDER.get(current["stage"], 0):
                effective_stage = str(current["stage"])
        if current:
            unchanged = (
                current["state"] == state
                and current["stage"] == effective_stage
                and current["progress"] == effective_progress
                and current.get("error") == error_value
            )
            if unchanged:
                return current
        sequence = (current.get("eventSequence", 0) if current else 0) + 1
        base = {
            "protocolVersion": PROTOCOL_VERSION,
            "taskID": submission.task_id,
            "projectID": submission.project_id,
            "projectRevision": submission.project_revision,
            "submissionDigestSHA256": submission.submission_digest,
            "eventSequence": sequence,
            "state": state,
            "stage": effective_stage,
            "progress": effective_progress,
            "terminal": terminal,
            "updatedAt": _utc_now(),
            "error": error_value,
        }
        event = {"documentType": "story-task-event", **base}
        status = {"documentType": "story-task-status", **base}
        _validate_protocol_document(event, "story-task-event")
        _validate_protocol_document(status, "story-task-status")
        submission.state_dir.mkdir(parents=True, exist_ok=True)
        event_bytes = (json.dumps(event, ensure_ascii=False) + "\n").encode("utf-8")
        descriptor = os.open(
            submission.state_dir / "events.jsonl",
            os.O_WRONLY | os.O_CREAT | os.O_APPEND,
            0o644,
        )
        try:
            os.write(descriptor, event_bytes)
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
        _atomic_json(submission.state_dir / "status.json", status)
        return status

    def _unverified_identity(self, task_dir: Path) -> VerifiedSubmission:
        task: dict[str, Any] = {}
        task_path = task_dir / "submission/task.json"
        if task_path.is_file():
            try:
                task = _read_json(task_path)
            except (OSError, ValueError, json.JSONDecodeError):
                task = {}
        task_id = task_dir.name if TASK_ID_PATTERN.fullmatch(task_dir.name) else "invalid-task"
        return VerifiedSubmission(
            task_dir=task_dir,
            submission_dir=task_dir / "submission",
            state_dir=task_dir / "state",
            task={
                "taskID": task_id,
                "projectID": str(task.get("projectID") or "unknown"),
                "projectRevision": str(task.get("projectRevision") or "unknown"),
            },
            completion={},
            submission_digest=(
                str(task.get("submissionDigestSHA256"))
                if re.fullmatch(r"[0-9a-f]{64}", str(task.get("submissionDigestSHA256", "")))
                else "0" * 64
            ),
            package_path=task_path,
            story_package_sha256="0" * 64,
        )

    def _reject_unverified(self, task_dir: Path, error: ProtocolError) -> None:
        if not TASK_ID_PATTERN.fullmatch(task_dir.name):
            _atomic_json(
                task_dir / "state/rejection.json",
                {"code": error.code, "message": error.message, "rejectedAt": _utc_now()},
            )
            return
        placeholder = self._unverified_identity(task_dir)
        self._transition(
            placeholder,
            state="rejected",
            stage="intake",
            progress=0,
            error=error,
        )

    def _receipt_conflict(self, submission: VerifiedSubmission) -> bool:
        receipt_path = submission.state_dir / "receipt.json"
        existing_digest: str | None = None
        if receipt_path.is_file():
            try:
                existing_digest = str(_read_json(receipt_path)["submissionDigestSHA256"])
            except (OSError, ValueError, KeyError, json.JSONDecodeError):
                existing_digest = None
        status = self.current_status(submission.task_dir)
        if status and status.get("submissionDigestSHA256") != submission.submission_digest:
            existing_digest = str(status.get("submissionDigestSHA256"))
        if existing_digest and existing_digest != submission.submission_digest:
            _atomic_json(
                submission.state_dir / "submission-conflict.json",
                {
                    "protocolVersion": PROTOCOL_VERSION,
                    "taskID": submission.task_id,
                    "code": "TASK_ID_CONTENT_CONFLICT",
                    "originalSubmissionDigestSHA256": existing_digest,
                    "observedSubmissionDigestSHA256": submission.submission_digest,
                    "observedAt": _utc_now(),
                },
            )
            return True
        return False

    def _ensure_receipt(self, submission: VerifiedSubmission) -> None:
        receipt_path = submission.state_dir / "receipt.json"
        if receipt_path.is_file():
            return
        _atomic_json(
            receipt_path,
            {
                "documentType": "story-task-receipt",
                "protocolVersion": PROTOCOL_VERSION,
                "taskID": submission.task_id,
                "projectID": submission.project_id,
                "projectRevision": submission.project_revision,
                "submissionDigestSHA256": submission.submission_digest,
                "storyPackageEntrypoint": submission.task["storyPackage"]["entrypoint"],
                "storyPackageSHA256": submission.story_package_sha256,
                "receivedAt": _utc_now(),
            },
        )

    def _submission_from_receipt(self, task_dir: Path) -> VerifiedSubmission | None:
        receipt_path = task_dir / "state/receipt.json"
        if not receipt_path.is_file():
            return None
        try:
            receipt = _read_json(receipt_path)
            task_id = str(receipt["taskID"])
            project_id = str(receipt["projectID"])
            project_revision = str(receipt["projectRevision"])
            submission_digest = str(receipt["submissionDigestSHA256"])
            story_digest = str(receipt["storyPackageSHA256"])
            entrypoint = str(receipt["storyPackageEntrypoint"])
        except (OSError, ValueError, KeyError, json.JSONDecodeError):
            return None
        if task_id != task_dir.name:
            return None
        package_path = task_dir / "submission" / entrypoint
        execution_path = task_dir / "state/execution.json"
        if execution_path.is_file():
            try:
                execution = _read_json(execution_path)
                adapter_dir = _safe_relative_path(
                    self.task_root, str(execution["adapterProjectDir"])
                )
                snapshot = adapter_dir / "artifacts/source_package.original.json"
                if snapshot.is_file():
                    package_path = snapshot
            except (OSError, ValueError, KeyError, json.JSONDecodeError, ProtocolError):
                pass
        return VerifiedSubmission(
            task_dir=task_dir,
            submission_dir=task_dir / "submission",
            state_dir=task_dir / "state",
            task={
                "taskID": task_id,
                "projectID": project_id,
                "projectRevision": project_revision,
                "storyPackage": {"entrypoint": entrypoint},
            },
            completion={},
            submission_digest=submission_digest,
            package_path=package_path,
            story_package_sha256=story_digest,
        )

    def _execution(self, submission: VerifiedSubmission) -> dict[str, Any] | None:
        path = submission.state_dir / "execution.json"
        if not path.is_file():
            return None
        try:
            return _read_json(path)
        except (OSError, ValueError, json.JSONDecodeError):
            return None

    def _execution_paths(
        self, submission: VerifiedSubmission, execution: dict[str, Any]
    ) -> tuple[Path, Path]:
        output_root = self.runs_dir / submission.task_id
        relative = str(execution["adapterProjectDir"])
        adapter_dir = _safe_relative_path(self.task_root, relative)
        try:
            adapter_dir.resolve().relative_to(output_root.resolve())
        except ValueError as exc:
            raise ProtocolError("EXECUTION_INTERRUPTED", "recorded adapter run escaped task run root") from exc
        return adapter_dir, output_root

    def _cancel_request(self, submission: VerifiedSubmission) -> dict[str, Any] | None:
        path = submission.task_dir / "requests/cancel.json"
        if not path.is_file():
            return None
        try:
            request = _read_json(path)
            _validate_protocol_document(request, "story-task-cancel")
            if request["taskID"] != submission.task_id:
                raise ProtocolError("CANCEL_REQUEST_INVALID", "cancel taskID does not match task")
            return request
        except (OSError, ValueError, json.JSONDecodeError, ProtocolError) as exc:
            error = exc if isinstance(exc, ProtocolError) else ProtocolError(
                "CANCEL_REQUEST_INVALID", "cancel request is not valid JSON"
            )
            _atomic_json(
                submission.state_dir / "cancel-response.json",
                {
                    "protocolVersion": PROTOCOL_VERSION,
                    "taskID": submission.task_id,
                    "status": "rejected",
                    "code": "CANCEL_REQUEST_INVALID",
                    "message": error.message,
                    "respondedAt": _utc_now(),
                },
            )
            return None

    def _ack_cancel(
        self,
        submission: VerifiedSubmission,
        request: dict[str, Any],
        status: str,
        code: str | None = None,
    ) -> None:
        response: dict[str, Any] = {
            "protocolVersion": PROTOCOL_VERSION,
            "taskID": submission.task_id,
            "requestID": request["requestID"],
            "status": status,
            "respondedAt": _utc_now(),
        }
        if code:
            response["code"] = code
        _atomic_json(submission.state_dir / "cancel-response.json", response)

    def _validate_story(self, submission: VerifiedSubmission) -> bool:
        self._transition(submission, state="validating", stage="validation", progress=0.08)
        report = validation_report(submission.package_path)
        _atomic_json(submission.state_dir / "validation.json", report)
        if report.get("valid") is not True:
            first = (report.get("errors") or [{}])[0]
            error = ProtocolError(
                "STORY_PACKAGE_INVALID",
                "existing StoryRenderPackage validator rejected the task input",
                details_code=str(first.get("code") or "SCHEMA_INVALID"),
            )
            self._transition(
                submission,
                state="rejected",
                stage="validation",
                progress=0.08,
                error=error,
            )
            return False
        if report.get("projectID") not in {None, submission.project_id}:
            error = ProtocolError("TASK_METADATA_INVALID", "validated projectID changed unexpectedly")
            self._transition(
                submission,
                state="rejected",
                stage="validation",
                progress=0.08,
                error=error,
            )
            return False
        self._transition(submission, state="queued", stage="preparation", progress=0.1)
        return True

    def _launch(self, submission: VerifiedSubmission) -> None:
        if not self.readiness["ready"]:
            self._transition(
                submission,
                state="failed",
                stage="preparation",
                progress=0.1,
                error=ProtocolError(
                    "EXECUTOR_NOT_READY",
                    "one or more required local dependencies are unavailable",
                    retryable=True,
                ),
            )
            return
        output_root = self.runs_dir / submission.task_id
        try:
            launched = self.backend.launch(submission.package_path, output_root, submission.task_id)
            adapter_dir = Path(str(launched["adapterProjectDir"])).resolve()
            adapter_relative = _task_root_relative(self.task_root, adapter_dir)
            execution = {
                "documentType": "story-task-execution",
                "protocolVersion": PROTOCOL_VERSION,
                "taskID": submission.task_id,
                "submissionDigestSHA256": submission.submission_digest,
                "adapterProjectID": launched["adapterProjectID"],
                "adapterProjectDir": adapter_relative,
                "workerPID": int(launched["workerPID"]),
                "launchedAt": _utc_now(),
            }
            _atomic_json(submission.state_dir / "execution.json", execution)
            self._transition(
                submission,
                state="running",
                stage="preparation",
                progress=0.3,
            )
        except ProtocolError as error:
            self._transition(
                submission,
                state="failed",
                stage="preparation",
                progress=0.1,
                error=error,
            )
        except (OSError, subprocess.SubprocessError, KeyError, ValueError) as exc:
            self._transition(
                submission,
                state="failed",
                stage="preparation",
                progress=0.1,
                error=ProtocolError("PREPARATION_FAILED", type(exc).__name__),
            )

    def _report_ref(self, path: Path) -> dict[str, Any]:
        if not path.is_file():
            raise ProtocolError("RESULT_VERIFICATION_FAILED", f"missing report: {path.name}")
        return {"path": _task_root_relative(self.task_root, path), "sha256": _sha256(path)}

    def _publish_success(
        self,
        submission: VerifiedSubmission,
        execution: dict[str, Any],
        adapter_dir: Path,
    ) -> None:
        validation_path = adapter_dir / "reports/validation_report.json"
        consistency_path = adapter_dir / "reports/consistency_report.json"
        verification_path = adapter_dir / "reports/media_verification.json"
        render_path = adapter_dir / "artifacts/render_report.json"
        try:
            validation = _read_json(validation_path)
            consistency = _read_json(consistency_path)
            verification = _read_json(verification_path)
            render_report = _read_json(render_path)
            if validation.get("valid") is not True:
                raise ProtocolError("RESULT_VERIFICATION_FAILED", "adapter validation did not pass")
            if consistency.get("status") != "pass":
                raise ProtocolError("RESULT_VERIFICATION_FAILED", "adapter consistency did not pass")
            if verification.get("status") != "pass" or not all(
                check.get("passed") is True for check in verification.get("checks", [])
            ):
                raise ProtocolError("RESULT_VERIFICATION_FAILED", "adapter media verification did not pass")
            output = render_report["outputs"][0]
            output_path = _resolve_adapter_artifact(adapter_dir, str(output["path"]))
            metadata = render_report.get("metadata", {})
            audio_codec = output.get("audio_codec")
            result = {
                "documentType": "story-task-result",
                "protocolVersion": PROTOCOL_VERSION,
                "taskID": submission.task_id,
                "projectID": submission.project_id,
                "projectRevision": submission.project_revision,
                "submissionDigestSHA256": submission.submission_digest,
                "adapterRunID": execution["adapterProjectID"],
                "storyPackageSHA256": submission.story_package_sha256,
                "output": {
                    "path": _task_root_relative(self.task_root, output_path),
                    "sha256": _sha256(output_path),
                    "sizeBytes": output_path.stat().st_size,
                },
                "media": {
                    "videoCodec": str(output.get("codec") or "unknown"),
                    "audioCodec": None if audio_codec in {None, "none"} else str(audio_codec),
                    "width": int(str(output["resolution"]).split("x", 1)[0]),
                    "height": int(str(output["resolution"]).split("x", 1)[1]),
                    "fps": float(output["fps"]),
                    "frames": int(metadata["actualFrames"]),
                    "durationSeconds": float(output["duration_seconds"]),
                    "verificationStatus": "pass",
                },
                "reports": {
                    "validation": self._report_ref(validation_path),
                    "consistency": self._report_ref(consistency_path),
                    "mediaVerification": self._report_ref(verification_path),
                    "render": self._report_ref(render_path),
                },
                "publishedAt": _utc_now(),
            }
            _validate_protocol_document(result, "story-task-result")
            _atomic_json(submission.state_dir / "result.json", result)
            self._transition(
                submission,
                state="succeeded",
                stage="publication",
                progress=1,
            )
        except ProtocolError as error:
            self._transition(
                submission,
                state="failed",
                stage="verification",
                progress=0.9,
                error=error,
            )
        except (OSError, ValueError, KeyError, IndexError, json.JSONDecodeError) as exc:
            self._transition(
                submission,
                state="failed",
                stage="verification",
                progress=0.9,
                error=ProtocolError("RESULT_VERIFICATION_FAILED", type(exc).__name__),
            )

    def _handle_cancel(
        self,
        submission: VerifiedSubmission,
        execution: dict[str, Any] | None,
    ) -> bool:
        request = self._cancel_request(submission)
        if not request:
            return False
        current = self.current_status(submission.task_dir)
        if current and current["state"] in TERMINAL_STATES:
            self._ack_cancel(submission, request, "too_late")
            return True
        if execution is None:
            self._ack_cancel(submission, request, "accepted")
            self._transition(
                submission,
                state="cancelled",
                stage="preparation",
                progress=current.get("progress", 0) if current else 0,
                error=ProtocolError("RENDER_CANCELLED", "task was cancelled before launch"),
            )
            return True
        response_path = submission.state_dir / "cancel-response.json"
        if response_path.is_file():
            try:
                response = _read_json(response_path)
                if response.get("requestID") == request["requestID"] and response.get("status") == "accepted":
                    return True
            except (OSError, ValueError, json.JSONDecodeError):
                pass
        adapter_dir, output_root = self._execution_paths(submission, execution)
        self._transition(
            submission,
            state="cancelling",
            stage="rendering",
            progress=current.get("progress", 0.4) if current else 0.4,
        )
        success, code = self.backend.cancel(adapter_dir, output_root)
        if success:
            self._ack_cancel(submission, request, "accepted")
        else:
            self._ack_cancel(submission, request, "target_unconfirmed", code)
        return True

    def _cancel_for_executor_stop(
        self,
        submission: VerifiedSubmission,
        execution: dict[str, Any],
    ) -> None:
        """Cancel the active trusted run without writing producer-owned requests/."""
        current = self.current_status(submission.task_dir)
        if current and current["state"] in TERMINAL_STATES:
            return
        response_path = submission.state_dir / "stop-cancel.json"
        if response_path.is_file():
            try:
                if _read_json(response_path).get("status") == "accepted":
                    return
            except (OSError, ValueError, json.JSONDecodeError):
                pass
        adapter_dir, output_root = self._execution_paths(submission, execution)
        self._transition(
            submission,
            state="cancelling",
            stage="rendering",
            progress=current.get("progress", 0.4) if current else 0.4,
        )
        success, code = self.backend.cancel(adapter_dir, output_root)
        _atomic_json(
            response_path,
            {
                "protocolVersion": PROTOCOL_VERSION,
                "taskID": submission.task_id,
                "reason": "executor stop --mode cancel-current",
                "status": "accepted" if success else "target_unconfirmed",
                "code": code,
                "respondedAt": _utc_now(),
            },
        )

    def _monitor(
        self,
        submission: VerifiedSubmission,
        execution: dict[str, Any],
    ) -> None:
        adapter_dir, _output_root = self._execution_paths(submission, execution)
        adapter_status = self.backend.status(adapter_dir)
        current = self.current_status(submission.task_dir)
        if current and current["state"] in TERMINAL_STATES:
            return
        if adapter_status:
            adapter_state = adapter_status.get("state")
            if adapter_state == "succeeded":
                self._publish_success(submission, execution, adapter_dir)
                return
            if adapter_state == "cancelled":
                error_item = (adapter_status.get("errors") or [{}])[0]
                self._transition(
                    submission,
                    state="cancelled",
                    stage=str(adapter_status.get("stage") or "rendering"),
                    progress=float(adapter_status.get("progress") or 0.4),
                    error=ProtocolError(
                        str(error_item.get("code") or "RENDER_CANCELLED"),
                        str(error_item.get("message") or "adapter confirmed cancellation"),
                    ),
                )
                return
            if adapter_state == "failed":
                error_item = (adapter_status.get("errors") or [{}])[0]
                self._transition(
                    submission,
                    state="failed",
                    stage=str(adapter_status.get("stage") or "rendering"),
                    progress=float(adapter_status.get("progress") or 0.4),
                    error=ProtocolError(
                        str(error_item.get("code") or "RENDER_FAILED"),
                        str(error_item.get("message") or "adapter reported failure"),
                    ),
                )
                return
        self._handle_cancel(submission, execution)
        current = self.current_status(submission.task_dir)
        if current and current["state"] in TERMINAL_STATES:
            return
        if adapter_status and adapter_status.get("state") in {"prepared", "running"}:
            stage = str(adapter_status.get("stage") or "rendering")
            if stage not in {"preparation", "rendering", "audio_processing", "verification"}:
                stage = "rendering"
            state = "cancelling" if current and current["state"] == "cancelling" else "running"
            self._transition(
                submission,
                state=state,
                stage=stage,
                progress=float(adapter_status.get("progress") or 0.4),
            )
        if not self.backend.worker_running(adapter_dir):
            latest = self.backend.status(adapter_dir)
            if latest and latest.get("state") in {"succeeded", "failed", "cancelled"}:
                self._monitor(submission, execution)
                return
            self._transition(
                submission,
                state="interrupted",
                stage="rendering",
                progress=(current.get("progress", 0.4) if current else 0.4),
                error=ProtocolError(
                    "EXECUTION_INTERRUPTED",
                    "trusted adapter worker is not running and no terminal result is confirmed",
                    retryable=True,
                ),
            )

    def _verified_task(self, task_dir: Path) -> VerifiedSubmission | None:
        try:
            submission = verify_submission(task_dir)
        except ProtocolError as error:
            status = self.current_status(task_dir)
            receipt_path = task_dir / "state/receipt.json"
            if status and receipt_path.is_file():
                try:
                    original_digest = str(_read_json(receipt_path)["submissionDigestSHA256"])
                except (OSError, ValueError, KeyError, json.JSONDecodeError):
                    original_digest = str(status["submissionDigestSHA256"])
                _atomic_json(
                    task_dir / "state/submission-conflict.json",
                    {
                        "protocolVersion": PROTOCOL_VERSION,
                        "taskID": task_dir.name,
                        "code": "TASK_ID_CONTENT_CONFLICT",
                        "originalSubmissionDigestSHA256": original_digest,
                        "observedSubmissionDigestSHA256": None,
                        "observedErrorCode": error.code,
                        "observedAt": _utc_now(),
                    },
                )
                return None
            self._reject_unverified(task_dir, error)
            return None
        if submission is None:
            return None
        if self._receipt_conflict(submission):
            return None
        self._ensure_receipt(submission)
        return submission

    def active_task_id(self) -> str | None:
        for task_dir in self._task_dirs():
            status = self.current_status(task_dir)
            if status and status["state"] in {"running", "cancelling"}:
                return task_dir.name
        return None

    def process_once(self, *, accept_new: bool = True, cancel_active: bool = False) -> str | None:
        """Reconcile one executor tick and return the active task ID, if any."""
        if not self.instance_id:
            self.ensure_layout()
        for task_dir in self._task_dirs():
            status = self.current_status(task_dir)
            if not status or status["state"] not in {"running", "cancelling"}:
                continue
            submission = self._verified_task(task_dir)
            if not submission:
                submission = self._submission_from_receipt(task_dir)
                if not submission:
                    continue
            execution = self._execution(submission)
            if execution is None:
                self._transition(
                    submission,
                    state="interrupted",
                    stage="rendering",
                    progress=float(status.get("progress", 0.4)),
                    error=ProtocolError(
                        "EXECUTION_INTERRUPTED",
                        "task has no trusted execution record after restart",
                        retryable=True,
                    ),
                )
                continue
            if cancel_active:
                self._cancel_for_executor_stop(submission, execution)
            self._monitor(submission, execution)
            latest = self.current_status(task_dir)
            if latest and latest["state"] in {"running", "cancelling"}:
                return submission.task_id

        if not accept_new:
            return None
        for task_dir in self._task_dirs():
            submission = self._verified_task(task_dir)
            if not submission:
                continue
            status = self.current_status(task_dir)
            if status and status["state"] in TERMINAL_STATES:
                self._handle_cancel(submission, self._execution(submission))
                continue
            if status is None:
                self._transition(
                    submission,
                    state="accepted",
                    stage="intake",
                    progress=0.02,
                )
                status = self.current_status(task_dir)
            if self._handle_cancel(submission, self._execution(submission)):
                latest = self.current_status(task_dir)
                if latest and latest["state"] in TERMINAL_STATES:
                    continue
            if status and status["state"] in {"accepted", "validating"}:
                if not self._validate_story(submission):
                    continue
                status = self.current_status(task_dir)
            if status and status["state"] == "queued":
                self._launch(submission)
                latest = self.current_status(task_dir)
                if latest and latest["state"] in {"running", "cancelling"}:
                    return submission.task_id
        return self.active_task_id()

    def summary(self) -> dict[str, Any]:
        counts: dict[str, int] = {}
        task_summaries: list[dict[str, Any]] = []
        for task_dir in self._task_dirs():
            status = self.current_status(task_dir)
            if not status:
                continue
            counts[status["state"]] = counts.get(status["state"], 0) + 1
            task_summaries.append(
                {
                    "taskID": task_dir.name,
                    "state": status["state"],
                    "stage": status["stage"],
                    "progress": status["progress"],
                    "terminal": status["terminal"],
                    "updatedAt": status["updatedAt"],
                }
            )
        return {
            "protocolVersion": PROTOCOL_VERSION,
            "executorVersion": EXECUTOR_VERSION,
            "taskRoot": str(self.task_root),
            "running": executor_process_running(self.task_root),
            "activeTaskID": self.active_task_id(),
            "counts": counts,
            "tasks": task_summaries,
        }


def _write_heartbeat(
    executor: StoryTaskExecutor,
    *,
    sequence: int,
    availability: str,
    active_task_id: str | None,
    started_at: str,
) -> dict[str, Any]:
    heartbeat = {
        "documentType": "story-executor-heartbeat",
        "protocolVersion": PROTOCOL_VERSION,
        "executorVersion": EXECUTOR_VERSION,
        "instanceID": executor.instance_id,
        "pid": os.getpid(),
        "sequence": sequence,
        "availability": availability,
        "activeTaskID": active_task_id,
        "startedAt": started_at,
        "updatedAt": _utc_now(),
    }
    _validate_protocol_document(heartbeat, "story-executor-heartbeat")
    _atomic_json(executor.executor_dir / "heartbeat.json", heartbeat)
    return heartbeat


def executor_process_running(task_root: str | Path) -> bool:
    root = Path(task_root).resolve()
    runtime_path = root / "executor/runtime.json"
    if not runtime_path.is_file():
        return False
    try:
        runtime = _read_json(runtime_path)
        pid = int(runtime["pid"])
    except (OSError, ValueError, KeyError, json.JSONDecodeError):
        return False
    check = subprocess.run(
        ["ps", "-p", str(pid), "-o", "command="],
        capture_output=True,
        text=True,
        check=False,
    )
    return (
        check.returncode == 0
        and "story_executor.py _daemon" in check.stdout
        and str(root) in check.stdout
    )


def daemon_loop(
    task_root: str | Path,
    *,
    poll_interval: float = 0.5,
    once: bool = False,
) -> int:
    executor = StoryTaskExecutor(task_root)
    executor.ensure_layout()
    lock_path = executor.executor_dir / "executor.lock"
    lock_handle = lock_path.open("a+")
    try:
        fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        return 6
    stop_request_path = executor.executor_dir / "stop-request.json"
    if stop_request_path.exists():
        stop_request_path.unlink()
    started_at = _utc_now()
    runtime = {
        "protocolVersion": PROTOCOL_VERSION,
        "executorVersion": EXECUTOR_VERSION,
        "instanceID": executor.instance_id,
        "pid": os.getpid(),
        "taskRoot": str(executor.task_root),
        "running": True,
        "startedAt": started_at,
    }
    _atomic_json(executor.executor_dir / "runtime.json", runtime)
    drain_mode: str | None = None

    def request_finish(_signum: int, _frame: Any) -> None:
        nonlocal drain_mode
        drain_mode = "finish-current"

    signal.signal(signal.SIGTERM, request_finish)
    signal.signal(signal.SIGINT, request_finish)
    from lib.story_style_templates import TemplateWorker
    templates = TemplateWorker(executor.task_root)
    sequence = 0
    try:
        while True:
            if stop_request_path.is_file():
                try:
                    request = _read_json(stop_request_path)
                    drain_mode = str(request.get("mode") or "finish-current")
                except (OSError, ValueError, json.JSONDecodeError):
                    drain_mode = "finish-current"
            active = executor.process_once(
                accept_new=drain_mode is None and templates.process is None,
                cancel_active=drain_mode == "cancel-current",
            )
            template_active = templates.tick(accept=drain_mode is None and active is None)
            sequence += 1
            if drain_mode:
                availability = "draining"
            elif not executor.readiness["ready"]:
                availability = "degraded"
            else:
                availability = "busy" if active else "ready"
            _write_heartbeat(
                executor,
                sequence=sequence,
                availability=availability,
                active_task_id=active,
                started_at=started_at,
            )
            if once or (drain_mode and active is None and not template_active):
                break
            time.sleep(max(0.1, poll_interval))
    finally:
        runtime["running"] = False
        runtime["stoppedAt"] = _utc_now()
        _atomic_json(executor.executor_dir / "runtime.json", runtime)
        sequence += 1
        _write_heartbeat(
            executor,
            sequence=sequence,
            availability="stopped",
            active_task_id=None,
            started_at=started_at,
        )
        fcntl.flock(lock_handle.fileno(), fcntl.LOCK_UN)
        lock_handle.close()
    return 0
